REPLICATION PACKAGE
Sustainable economy and finance research: trends, journals, and a place for JDSE
Arief Anshory Yusuf, Universitas Padjadjaran
Bank Indonesia Institute workshop on the Journal of Digital and Sustainable Economy and Finance (JDSE), Bandung, 15 October 2026
Slides: https://anshory1972.github.io/dataslide/jdse-sustainable-research.html


1. WHAT THIS PACKAGE DOES

This package contains the data, the code and the instructions to produce every figure and table in the slides.
It does not produce the HTML slide page itself.

You can work at two levels:

  a) Figures only. Run code/make_figures.py. It reads the data files in data/ and writes every chart as an SVG
     file and every table as a CSV file into figures/. It needs no internet.

  b) Full replication. Run the download scripts, then the analysis scripts, then make_figures.py.
     The download step needs internet access and an OpenAlex API key. One script also needs a Scopus API key.


2. FOLDERS

  README.txt          this file
  code/               Python scripts (download, analysis, figures)
  data/               downloaded data and computed results (JSON)
  data/works/         one record per paper, from OpenAlex (gzip-compressed JSON lines). S = six sustainable
                      topics, D = five digital topics, one file per year. A .done file marks a finished
                      year; fetch_works.py skips it. Delete the .done files to download again.
  data/inputs/        two published journal lists used as inputs
  figures/            the output of make_figures.py (SVG charts, CSV tables, index.txt)

figures/index.txt lists each figure title and the files that belong to it.
File names follow the figure numbers in the slides, for example fig11_chart1.svg is the first chart of Figure 11.
table_filters_table1.csv is the table on the slide "Four journal filters".


3. DATA SOURCES

  OpenAlex (https://openalex.org), API, downloaded 14 October 2026. Licence: CC0.
      Papers, topics, keywords, journals, author countries, institutions, open-access status, citations.

  Scopus Source List, September 2026 (Elsevier). File data/inputs/ext_list_Sep_2026.xlsx.
      Downloaded from:
      https://downloads.ctfassets.net/o78em1y1w4i4/7xtaTxNiNcWRTeZkV86eNy/e6b17b29beaf8d18175591a4e8dee0bf/ext_list_Sep_2026.xlsx
      Used to decide whether a journal is in Scopus and whether Scopus has discontinued it.

  SCImago Journal Rank 2025. File data/inputs/scimagojr 2025.csv (semicolon-separated).
      Downloaded from https://www.scimagojr.com/journalrank.php (export of all journals).
      Used for the best quartile (Q1 to Q4) of each journal.

  Scopus Search API (Elsevier), 14 October 2026. Yearly paper counts for one keyword query.
      Used only as a cross-check of growth (data/scopus_counts.json).

OpenAlex changes over time. A new download will give numbers that differ a little from the slides.
The data in this package reproduce the slides exactly.


4. REQUIREMENTS

  Python 3.11 or later (tested with Python 3.13).
  Extra packages:  networkx (3.x; tested with 3.7)   openpyxl   Pillow
      pip install networkx openpyxl Pillow

  API keys (only for the download step), set as environment variables:
      OPENALEX_API_KEY   free key from https://openalex.org
      SCOPUS_API_KEY     Elsevier developer key from https://dev.elsevier.com (only for fetch_scopus_counts.py)

  Windows example:   set OPENALEX_API_KEY=your_key
  Linux/macOS:       export OPENALEX_API_KEY=your_key


5. HOW TO RUN

Run every script from inside the code/ folder:   cd code

Step A. Download (needs internet; fetch_works.py takes the longest)

  python fetch_jdse.py            aggregate counts from OpenAlex (group_by queries): topics, years, venues,
                                  countries, keywords, open-access status, most cited papers
  python fetch_sources.py         journal records for the main venues, and yearly series
  python fetch_works.py           one record per paper: six sustainable topics (S) and five digital topics (D),
                                  2010-2026, articles and reviews -> data/works/
  python fetch_all_sources.py     journal records for every journal in data/works -> data/sources_meta.json
  python fetch_benchmarks.py      profiles of three benchmark journals (BMEB, JSFI, Journal of Climate Finance)
  python fetch_scopus_counts.py   Scopus cross-check counts (needs SCOPUS_API_KEY)

Step B. Analysis (no internet needed, except the two notes below)

  python scopus_list.py           reads the Scopus Source List -> data/scopus_list_sep2026.json
  python analyse.py               classifies the top venues and the journals launched since 2010 -> data/analysis.json
                                  (fetches missing journal records from OpenAlex)
  python prepare_deck_data.py     -> data/deck_data.json
  python analyse_tiers.py         the four journal filters -> data/deck_data_tiers.json
                                  (fetches the country of Indonesian institutions from OpenAlex)
  python analyse_themes.py        the six theme analyses -> data/deck_data_themes.json
  python analyse_oa_model.py      journal business model (subscription or open access) -> data/deck_data_oamodel.json
  python analyse_specialist.py    topic share of the top sustainable-finance journals -> data/deck_data_specialist.json

Step C. Figures

  python make_figures.py          -> figures/


6. DEFINITIONS USED IN THE CODE

  Corpus. Sustainable set: papers whose primary OpenAlex topic is one of six topics
  (T13146, T10471, T10119, T12013, T12883, T10115). Digital set: papers with any of five topics
  (T11995, T13346, T10987, T10270, T12958). Intersection: a paper with one topic from each set.
  Articles and reviews only, 2010-2026.

  Four journal filters.
    all      every OpenAlex source of type journal; repositories and preprint servers removed
    scopus   ISSN or EISSN on the Scopus Source List, September 2026, including discontinued titles
    active   listed and not discontinued by Scopus
    q1       active, and SCImago 2025 best quartile Q1
  Matching is by ISSN (8 characters, no hyphen).

  Indonesian paper. At least one author with an affiliation in Indonesia (OpenAlex authorship countries).

  Citation score. Citations of a paper divided by the average citations of papers of the same year in the
  same filter; papers 2018-2023.

  Activity index. (Indonesia's papers in a theme / all Indonesia's papers) divided by
  (world papers in the theme / all world papers).

  Keyword map. Top 90 keywords 2021-2026; equivalence index; links with at least 5 papers;
  Louvain clustering with resolution 1.6 and seed 7; Callon centrality and density.

  Burst detection. Kleinberg two-state model on yearly keyword shares, 2010-2025, s = 2, gamma = 1.

  Journal model. Subscription = not a fully open-access journal in OpenAlex (open access is optional,
  through a hybrid fee). Open access with APC = fully open access with an APC. Open access without APC =
  APC of zero, or listed in DOAJ without an APC.

  Topic share. A journal's papers in the topic "Sustainable finance and green bonds" divided by all its
  papers, 2016-2026. Specialist = above 25%.


7. NOTES

  The figure files use the same chart code and the same colours as the slides.

  Reproducibility check. The analysis scripts and make_figures.py were rerun from this package on the data
  included. All results and all figure files were identical to the originals. The only difference: two lists
  in data/deck_data_themes.json (growth_impact, activity) can come out in a different order, because Python
  orders sets differently between runs. Their content is the same, and the figures do not change.
  Charts are SVG files. Open them in a web browser, or import them into PowerPoint, Word or Inkscape.
  Tables are CSV files in UTF-8. They open in Excel.

  AI use. Claude (Anthropic) helped write the code for data download and analysis, and helped draft the
  slides. The author checked the results and is responsible for all content.

  Contact: Arief Anshory Yusuf, Universitas Padjadjaran.
