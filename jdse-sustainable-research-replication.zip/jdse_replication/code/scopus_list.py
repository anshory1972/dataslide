# Scopus listing status from the official Scopus Source List, September 2026 (ext_list_Sep_2026.xlsx).
#   listed        ISSN or EISSN on the "Scopus Sources Sep. 2026" sheet, or on the "Discontinued Titles Sep. 2026" sheet
#   discontinued  flagged in the sources sheet's "Titles Discontinued by Scopus" column, or on the discontinued sheet
# Cached to data/scopus_list_sep2026.json after the first read.
import os as _os, sys as _sys
ROOT = _os.path.dirname(_os.path.dirname(_os.path.abspath(__file__)))  # package root
_sys.stdout.reconfigure(encoding='utf-8', errors='replace')
import json, os
import openpyxl

XLSX = ROOT + "/data/inputs/ext_list_Sep_2026.xlsx"
CACHE = ROOT + "/data/scopus_list_sep2026.json"


def norm(s):
    s = "".join(ch for ch in str(s or "").upper() if ch.isalnum())
    if s.isdigit() and len(s) < 8: s = s.zfill(8)
    return s if len(s) == 8 else ""


def load():
    if os.path.exists(CACHE):
        return json.load(open(CACHE))
    wb = openpyxl.load_workbook(XLSX, read_only=True)
    src = {}
    ws = wb["Scopus Sources Sep. 2026"]; rows = ws.iter_rows(values_only=True); hdr = list(next(rows))
    ci = {h: i for i, h in enumerate(hdr) if h}
    i_issn, i_eissn, i_act, i_disc, i_type, i_title, i_cov = ci["ISSN"], ci["EISSN"], ci["Active or Inactive"], ci["Titles Discontinued by Scopus"], ci["Source Type"], ci["Source Title"], ci["Coverage"]
    import re
    for r in rows:
        yrs = [int(y) for y in re.findall(r"(\d{4})", str(r[i_cov] or ""))]
        rec = {"title": r[i_title], "status": r[i_act], "disc": bool(str(r[i_disc] or "").strip()), "type": r[i_type], "cov_first": min(yrs) if yrs else None}
        for k in (r[i_issn], r[i_eissn]):
            k = norm(k)
            if k: src[k] = rec
    disc = set()
    ws = wb["Discontinued Titles Sep. 2026"]; rows = list(ws.iter_rows(values_only=True))
    hdr_i = next(i for i, r in enumerate(rows) if r and r[0] == "Sourcerecord ID"); hdr = rows[hdr_i]
    ci = {h: i for i, h in enumerate(hdr) if h}
    for r in rows[hdr_i + 1:]:
        for k in (r[ci["ISSN"]], r[ci["EISSN"]]):
            k = norm(k)
            if k: disc.add(k)
    for k, v in src.items():
        if v["disc"]: disc.add(k)
    out = {"sources": src, "discontinued": sorted(disc)}
    json.dump(out, open(CACHE, "w"))
    return out


if __name__ == "__main__":
    L = load()
    from collections import Counter
    print("ISSN keys", len(L["sources"]), "discontinued ISSNs", len(L["discontinued"]))
    print(Counter(v["status"] for v in L["sources"].values()), Counter(v["type"] for v in L["sources"].values()).most_common(5))
    print("flagged in sources sheet", sum(1 for v in L["sources"].values() if v["disc"]))
