# Classify venues against the Scopus Source List (September 2026) and SCImago 2025; build the tables for the deck.
import os as _os, sys as _sys
ROOT = _os.path.dirname(_os.path.dirname(_os.path.abspath(__file__)))  # package root
_sys.stdout.reconfigure(encoding='utf-8', errors='replace')
import csv, json, re, sys
sys.path.insert(0, _os.path.dirname(_os.path.abspath(__file__)))
from classify_sources import norm_issn, is_mega_journal
from scopus_list import load as load_scopus_list

D = ROOT + "/data/"
SCIMAGO = ROOT + "/data/inputs/scimagojr 2025.csv"

# SCImago lookup by ISSN with quartile, coverage first year, SJR, h, publisher
sj = {}
with open(SCIMAGO, encoding="utf-8-sig") as f:
    for r in csv.DictReader(f, delimiter=";"):
        cov = r.get("Coverage", "") or ""
        m = re.findall(r"(\d{4})", cov); first = int(m[0]) if m else None
        rec = {"title": r["Title"], "q": r["SJR Best Quartile"], "sjr": r["SJR"], "h": r["H index"], "publisher": r["Publisher"],
               "cov_first": first, "coverage": cov, "country": r["Country"], "oa": r["Open Access"], "type": r["Type"]}
        for i in (r.get("Issn") or "").split(","):
            i = norm_issn(i.strip())
            if i: sj[i] = rec
SL = load_scopus_list(); LISTED = SL["sources"]; disc = set(SL["discontinued"])
print("scimago issns", len(sj), "discontinued", len(disc))

S = json.load(open(D + "sources_meta.json", encoding="utf-8"))
# fetch metadata for venues not yet in sources_meta (lists pulled later)
import urllib.request
KEY = _os.environ.get("OPENALEX_API_KEY", "")
need = set()
for name in ["venue_sust_noCSR_id"]:
    for r in json.load(open(D + name + ".json", encoding="utf-8"))["rows"]:
        sid = r["key"].split("/")[-1]
        if sid.startswith("S") and sid not in S: need.add(sid)
need = sorted(need)
SEL = "id,display_name,issn_l,issn,type,host_organization_name,country_code,is_oa,is_in_doaj,apc_usd,works_count,cited_by_count,summary_stats,counts_by_year"
for i in range(0, len(need), 50):
    chunk = need[i:i + 50]
    with urllib.request.urlopen(f"https://api.openalex.org/sources?filter=ids.openalex:{'|'.join(chunk)}&per_page=50&select={SEL}&api_key={KEY}", timeout=90) as r:
        for src in json.load(r)["results"]:
            cy = sorted([c for c in src.get("counts_by_year", []) if c["works_count"] > 0], key=lambda c: c["year"])
            src["first_year_in_counts"] = cy[0]["year"] if cy else None; S[src["id"].split("/")[-1]] = src
if need: json.dump(S, open(D + "sources_meta.json", "w", encoding="utf-8"), indent=1); print("added sources", len(need))
REPO_WORDS = ("zenodo", "repositor", "doaj", "repec", "dialnet", "cairn", "figshare", "ssrn", "agecon", "referencia", "irdb", "core (", "scielo", "hal (", "osf", "eprints", "arxiv", "research square", "econstor")


def classify(sid):
    s = S.get(sid)
    if not s: return {"cls": "unknown", "name": sid}
    name = (s.get("display_name") or "").lower()
    if s.get("type") != "journal" or any(w in name for w in REPO_WORDS):
        return {"cls": "repository", "name": s.get("display_name")}
    issns = [norm_issn(i) for i in (s.get("issn") or [])] + [norm_issn(s.get("issn_l") or "")]
    issns = [i for i in issns if i]
    rec = next((sj[i] for i in issns if i in sj), None)
    lst = next((LISTED[i] for i in issns if i in LISTED), None)
    dl = any(i in disc for i in issns)
    out = {"name": s.get("display_name"), "publisher": s.get("host_organization_name"), "country": s.get("country_code"), "first_year": s.get("first_year_in_counts"),
           "is_oa": s.get("is_oa"), "doaj": s.get("is_in_doaj"), "apc": s.get("apc_usd"), "h": (s.get("summary_stats") or {}).get("h_index"),
           "cite2y": (s.get("summary_stats") or {}).get("2yr_mean_citedness"), "works": s.get("works_count"), "mega": is_mega_journal(s.get("display_name") or "")}
    if dl: out["cls"] = "delisted"
    elif lst:
        q = rec["q"] if rec else None
        out["cls"] = q if q in ("Q1", "Q2", "Q3", "Q4") else "scopus_unranked"
        out["cov_first"] = lst.get("cov_first") or (rec or {}).get("cov_first"); out["sjr"] = (rec or {}).get("sjr")
    else: out["cls"] = "not_indexed"
    return out


def load(name): return json.load(open(D + name + ".json", encoding="utf-8"))


def venue_table(name, top=25):
    d = load(name); rows = []
    for r in d["rows"]:
        sid = r["key"].split("/")[-1]; c = classify(sid); c["count"] = r["count"]; c["id"] = sid; rows.append(c)
    return d["total"], rows


def share_by_class(rows, total):
    agg = {}
    for r in rows: agg[r["cls"]] = agg.get(r["cls"], 0) + r["count"]
    covered = sum(r["count"] for r in rows)
    return {"covered_by_top200": covered, "total": total, "shares_of_top200": {k: round(100 * v / covered, 1) for k, v in sorted(agg.items(), key=lambda x: -x[1])}}


A = {}
for name in ["venue_sust_primary", "venue_sust_primary_2022", "venue_T13146", "venue_intersection", "venue_sust_id", "venue_sust_noCSR_id", "venue_sust_asean"]:
    total, rows = venue_table(name)
    A[name] = {"total": total, "rows": rows, "by_class": share_by_class(rows, total)}
    print(f"\n== {name}: total {total}; top-200 venues cover {A[name]['by_class']['covered_by_top200']}; class shares {A[name]['by_class']['shares_of_top200']}")
    for r in [x for x in rows if x["cls"] != "repository"][:12]:
        print(f"   {r['count']:>6} {r['cls']:<15} {str(r.get('first_year')):<5} {str(r.get('apc')):<6} h={str(r.get('h')):<5} {r['name'][:60]} | {str(r.get('publisher'))[:30]}")

# journal age benchmark: journals launched 2010 or later that appear in the sustainable venue lists, with years to Scopus coverage
launched = {}
for name in ["venue_sust_primary", "venue_T13146", "venue_intersection"]:
    for r in A[name]["rows"]:
        fy = r.get("first_year")
        if r["cls"] != "repository" and fy and fy >= 2010 and r["count"] >= 20:
            launched[r["id"]] = r
print("\n== journals launched 2010+ in the field (count>=20 in a list)")
rows = sorted(launched.values(), key=lambda r: (r.get("first_year") or 0))
for r in rows:
    yti = (r["cov_first"] - r["first_year"]) if r.get("cov_first") and r.get("first_year") else None
    print(f"   {r['first_year']} {r['cls']:<15} cov_first={str(r.get('cov_first')):<5} yrs_to_index={str(yti):<4} apc={str(r.get('apc')):<6} h={str(r.get('h')):<4} 2y={round(r.get('cite2y') or 0,1):<5} {r['name'][:55]} | {str(r.get('publisher'))[:28]}")
A["launched_2010plus"] = rows

# year series
for n in ["year_sust_primary", "year_sust_id", "year_sust_cn", "year_sust_noCSR_world", "year_sust_noCSR_id", "year_T13146", "year_T13146_id", "year_intersection", "year_digi_any", "year_sust_any"]:
    d = load(n); A[n] = {int(r["key"]): r["count"] for r in d["rows"] if str(r["key"]).isdigit()}
print("\n== Indonesia share of world, primary sustainable set (all / without CSR topic)")
for y in range(2012, 2027):
    w, i = A["year_sust_primary"].get(y, 0), A["year_sust_id"].get(y, 0); w2, i2 = A["year_sust_noCSR_world"].get(y, 0), A["year_sust_noCSR_id"].get(y, 0)
    print(f"   {y}: world {w:>6} id {i:>5} ({100*i/max(w,1):.1f}%)   noCSR world {w2:>6} id {i2:>4} ({100*i2/max(w2,1):.1f}%)   cn {A['year_sust_cn'].get(y,0)}")
json.dump(A, open(D + "analysis.json", "w", encoding="utf-8"), indent=1, default=str)
print("saved analysis.json")
