# Writes every figure of the deck as files: charts as SVG, tables as CSV, into ../figures.
# It uses the same chart code and the same data files as the slides. Run after the analysis scripts.
import os, sys
os.chdir(os.path.dirname(os.path.abspath(__file__)))
sys.stdout.reconfigure(encoding='utf-8', errors='replace')
import io, json, math, os, sys
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8")
D = json.load(open("../data/deck_data.json", encoding="utf-8"))
HOUSE = ""
HOUSE2 = ""
SLUG = "jdse-sustainable-research" + ("-v2" if os.environ.get("V2") else "")
URL = f"https://anshory1972.github.io/dataslide/{SLUG}.html"
OG = "jdse-sustainable-research-og-dbc50804.jpg"
TITLE = "Sustainable economy and finance research: trends, journals, and a place for JDSE"
DESC = ("Research trends, main journals and Indonesia's place in sustainable economy and finance research, measured on OpenAlex and Scopus, "
        "for the Bank Indonesia Institute workshop on the Journal of Digital and Sustainable Economy and Finance (JDSE), Bandung, 15 October 2026.")
ART_RATIO = {"cover": (1, 1), "div0": (1, 1), "div5": (1, 1), "div1": (1, 1), "div2": (1, 1), "div3": (1, 1), "div4": (1, 1), "thanks": (1, 1), "missing": (2, 3)}


def esc(s):
    return str(s).replace("&", "&amp;").replace("<", "&lt;")


def fmt(v, d=1):
    return f"{v:,.{d}f}".replace("-", "&minus;")


# ------------------------------------------------------------------ shell
def art(k):
    """Embedded JPEG from art/<k>.b64; a flat placeholder of the right aspect ratio until the image exists."""
    shots = {}
    if k in shots and os.path.exists(shots[k]):
        return png_as_jpeg(shots[k], 82, 1300)
    f = f"art/{k}.b64"
    if os.path.exists(f):
        return "data:image/jpeg;base64," + open(f).read()
    w, h = ART_RATIO.get(k, (1, 1))
    W, H = 400 * w, 400 * h
    svg = (f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {W} {H}"><rect width="{W}" height="{H}" fill="#e6d9ce"/>'
           f'<text x="{W/2}" y="{H/2}" font-family="system-ui" font-size="40" fill="#8b8480" text-anchor="middle">{k} {w}:{h}</text></svg>')
    return "data:image/svg+xml;utf8," + svg.replace("#", "%23").replace('"', "'")


def panel(eyebrow, head, take="", body="", src="", img=None, side=False):
    p = ['<div class="viz-root scope-slide2"><div class="wrap"><section class="panel">']
    srch = (f'<details class="src"><summary>Source &amp; method</summary><div class="src-body">{src}</div></details>' if src else "")
    if img:
        p.append('<div class="picgrid"><div class="pg-left">')
        if eyebrow: p.append(f'<p class="panel-eyebrow">{eyebrow}</p>')
        p.append(f"<h2>{head}</h2>")
        if take: p.append(f'<p class="takeaway">{take}</p>')
        p.append(f'<img class="pgimg" src="{art(img)}" alt=""></div><div class="pg-right">{body}{srch}</div></div>')
        p.append("</section></div></div>")
        return "\n".join(p)
    if side: p.append('<div class="sidehead"><div class="sh-text">')
    if eyebrow: p.append(f'<p class="panel-eyebrow">{eyebrow}</p>')
    p.append(f"<h2>{head}</h2>")
    if take: p.append(f'<p class="takeaway">{take}</p>')
    if side: p.append(f'</div><div class="sh-body">{body}</div></div>'); body = ""
    if body: p.append(body)
    if srch: p.append(srch)
    p.append("</section></div></div>")
    return "\n".join(p)


def row(inner, label):
    return f'<section class="row-single" aria-label="{label}">{inner}</section>'


# ------------------------------------------------------------------ charts
def line_chart(x, series, y0, y1, yticks, ytitle, w=1180, h=430, xticks=None, yfmt=lambda v: f"{v:g}",
               left=70, right=200, top=40, bottom=46, gap=18, refline=None, dots=False):
    X = lambda v: left + (v - x[0]) / (x[-1] - x[0]) * (w - left - right)
    Y = lambda v: top + (y1 - v) / (y1 - y0) * (h - top - bottom)
    s = [f'<svg class="ds-chart" viewBox="0 0 {w} {h}" role="img" aria-label="{esc(ytitle)}">',
         f'<text x="{left}" y="22" class="ph">{ytitle}</text>']
    for t in yticks:
        s.append(f'<line x1="{left}" y1="{Y(t):.1f}" x2="{w-right+10}" y2="{Y(t):.1f}" class="g"/>'
                 f'<text x="{left-10}" y="{Y(t)+5:.1f}" class="ax end">{yfmt(t)}</text>')
    if refline is not None:
        s.append(f'<line x1="{left}" y1="{Y(refline):.1f}" x2="{w-right+10}" y2="{Y(refline):.1f}" '
                 f'stroke="var(--text-secondary)" stroke-width="1.4"/>')
    for t in (xticks or x):
        s.append(f'<text x="{X(t):.1f}" y="{h-bottom+26}" class="ax mid">{t}</text>')
    ends = []
    for se in series:
        pts = [(X(a), Y(b)) for a, b in zip(x, se["values"]) if b is not None]
        d = " ".join(f"{'M' if i == 0 else 'L'}{p[0]:.1f},{p[1]:.1f}" for i, p in enumerate(pts))
        dash = f' stroke-dasharray="{se["dash"]}"' if se.get("dash") else ""
        s.append(f'<path d="{d}" fill="none" stroke="{se["color"]}" stroke-width="{se.get("width", 2.4)}"'
                 f' stroke-linejoin="round"{dash}/>')
        if dots:
            for (px, py), v in zip(pts, [b for b in se["values"] if b is not None]):
                s.append(f'<circle cx="{px:.1f}" cy="{py:.1f}" r="5" fill="{se["color"]}"/>'
                         f'<text x="{px:.1f}" y="{py-12:.1f}" class="val mid" fill="{se["color"]}">{se.get("vfmt", lambda q: fmt(q, 1))(v)}</text>')
        if se.get("label", True):
            ends.append([pts[-1][1], pts[-1][0], se])
    ends.sort(key=lambda e: e[0])
    for i in range(1, len(ends)):
        if ends[i][0] - ends[i - 1][0] < gap:
            ends[i][0] = ends[i - 1][0] + gap
    for yy, xx, se in ends:
        b = ' font-weight="700"' if se.get("bold") else ""
        s.append(f'<text x="{xx+10:.1f}" y="{yy+5:.1f}" class="lab" fill="{se["color"]}"{b}>{se["name"]}</text>')
    s.append("</svg>")
    return "\n".join(s)


def hbars(items, x0, x1, ticks, title, w=1180, rowh=34, left=300, right=110, top=46, valfmt=lambda v: fmt(v, 1),
          ref=None, reflab="", cls=""):
    """items: list of (label, value, colour, bold)."""
    h = top + rowh * len(items) + 40
    X = lambda v: left + (v - x0) / (x1 - x0) * (w - left - right)
    s = [f'<svg class="ds-chart {cls}" viewBox="0 0 {w} {h}" role="img" aria-label="{esc(title)}">',
         f'<text x="10" y="22" class="ph">{title}</text>']
    for t in ticks:
        s.append(f'<line x1="{X(t):.1f}" y1="{top-8}" x2="{X(t):.1f}" y2="{h-34}" class="g"/>'
                 f'<text x="{X(t):.1f}" y="{h-12}" class="ax mid">{fmt(t, 0) if float(t).is_integer() else fmt(t, 1)}</text>')
    zero = X(max(x0, min(0, x1)))
    for i, (lab, v, colr, bold) in enumerate(items):
        y = top + i * rowh
        a, b = sorted([zero, X(v)])
        fw = ' font-weight="700"' if bold else ""
        s.append(f'<text x="{left-12}" y="{y+rowh/2+5:.1f}" class="lab end"{fw} fill="{colr if bold else "var(--text-primary)"}">{lab}</text>'
                 f'<rect x="{a:.1f}" y="{y+5}" width="{max(b-a,1.5):.1f}" height="{rowh-10}" rx="3" fill="{colr}"/>')
        tx = (b + 8) if v >= 0 else (a - 8)
        anc = "" if v >= 0 else " end"
        s.append(f'<text x="{tx:.1f}" y="{y+rowh/2+5:.1f}" class="val{anc}"{fw} fill="{colr if bold else "var(--text-secondary)"}">{valfmt(v)}</text>')
    if ref is not None:
        s.append(f'<line x1="{X(ref):.1f}" y1="{top-12}" x2="{X(ref):.1f}" y2="{h-34}" stroke="var(--c9)" stroke-width="2" stroke-dasharray="6 4"/>'
                 f'<text x="{X(ref)+6:.1f}" y="{top-14}" class="lab" fill="var(--c9)">{reflab}</text>')
    s.append("</svg>")
    return "\n".join(s)


def vbars(items, y0, y1, title, w=580, h=360, valfmt=lambda v: fmt(v, 1), left=20, top=44, bottom=60, cls=""):
    """Column bars. items: list of (label, value, colour)."""
    n = len(items); slot = (w - left - 20) / n; bw = slot * 0.62
    Y = lambda v: top + (y1 - v) / (y1 - y0) * (h - top - bottom)
    s = [f'<svg class="ds-chart {cls}" viewBox="0 0 {w} {h}" role="img" aria-label="{esc(title)}">',
         f'<text x="{left}" y="22" class="ph">{title}</text>',
         f'<line x1="{left}" y1="{Y(y0):.1f}" x2="{w-10}" y2="{Y(y0):.1f}" class="g"/>']
    for i, (lab, v, colr) in enumerate(items):
        x = left + slot * i + (slot - bw) / 2
        s.append(f'<rect x="{x:.1f}" y="{Y(v):.1f}" width="{bw:.1f}" height="{Y(y0)-Y(v):.1f}" rx="3" fill="{colr}"/>'
                 f'<text x="{x+bw/2:.1f}" y="{Y(v)-10:.1f}" class="val mid" font-weight="700" fill="{colr}">{valfmt(v)}</text>')
        for j, ln in enumerate(lab.split("|")):
            s.append(f'<text x="{x+bw/2:.1f}" y="{h-bottom+22+j*19}" class="ax mid">{ln}</text>')
    s.append("</svg>")
    return "\n".join(s)


def gvbars(groups, series, y0, y1, yticks, title, w=1180, h=480, left=70, top=50, bottom=60, valfmt=lambda v: fmt(v, 1), stacked=False):
    """Grouped column bars. series: list of dict(name, values, color)."""
    n, m = len(groups), len(series)
    slot = (w - left - 30) / n; bw = slot * 0.8 / m
    Y = lambda v: top + (y1 - v) / (y1 - y0) * (h - top - bottom)
    s = [f'<svg class="ds-chart" viewBox="0 0 {w} {h}" role="img" aria-label="{esc(title)}">',
         f'<text x="{left}" y="24" class="ph">{title}</text>']
    for t in yticks:
        s.append(f'<line x1="{left}" y1="{Y(t):.1f}" x2="{w-20}" y2="{Y(t):.1f}" class="g"/><text x="{left-10}" y="{Y(t)+5:.1f}" class="ax end">{valfmt(t)}</text>')
    for i, gname in enumerate(groups):
        x0 = left + slot * i + slot * 0.1
        if stacked:
            sw = slot * 0.55; x = left + slot * i + (slot - sw) / 2; base = y0
            for se in series:
                v = se["values"][i]; top_y, bot_y = Y(base + v), Y(base)
                s.append(f'<rect x="{x:.1f}" y="{top_y:.1f}" width="{sw:.1f}" height="{bot_y-top_y:.1f}" fill="{se["color"]}"/>')
                if bot_y - top_y >= 22:
                    s.append(f'<text x="{x+sw/2:.1f}" y="{(top_y+bot_y)/2+6:.1f}" class="val mid" font-weight="700" fill="#fff">{valfmt(v)}</text>')
                else:
                    s.append(f'<text x="{x+sw+8:.1f}" y="{(top_y+bot_y)/2+5:.1f}" class="val" fill="{se["color"]}">{valfmt(v)}</text>')
                base += v
            s.append(f'<text x="{x+sw/2:.1f}" y="{Y(base)-10:.1f}" class="val mid" font-weight="700">{valfmt(base)}</text>')
            s.append(f'<text x="{x+sw/2:.1f}" y="{h-bottom+26}" class="lab mid">{gname}</text>')
            continue
        for j, se in enumerate(series):
            v = se["values"][i]; x = x0 + j * bw
            s.append(f'<rect x="{x:.1f}" y="{Y(v):.1f}" width="{bw-6:.1f}" height="{Y(y0)-Y(v):.1f}" rx="3" fill="{se["color"]}"/>'
                     f'<text x="{x+(bw-6)/2:.1f}" y="{Y(v)-8:.1f}" class="val mid" font-weight="700" fill="{se["color"]}">{valfmt(v)}</text>')
        s.append(f'<text x="{x0+slot*0.4:.1f}" y="{h-bottom+26}" class="lab mid">{gname}</text>')
    lx = left
    for se in series:
        s.append(f'<rect x="{lx}" y="{h-18}" width="14" height="14" rx="2" fill="{se["color"]}"/><text x="{lx+20}" y="{h-6}" class="ax">{se["name"]}</text>')
        lx += 30 + 9 * len(se["name"])
    s.append("</svg>")
    return "\n".join(s)


def cards(items, cls="cards"):
    def big(b):
        parts = b.rsplit(" ", 1)
        if len(parts) == 2 and parts[1] in ("T", "jt", "pts") and "&rarr;" not in b:
            return f'{parts[0]}<span class="of"> {parts[1]}</span>'
        return b
    c = "".join(f'<div class="card"><div class="big">{big(b)}</div><div class="small">{sm}</div>'
                f'<div class="note">{n}</div></div>' for b, sm, n in items)
    return f'<div class="{cls}">{c}</div>'


def table(head, rows, cls="dtable"):
    th = "".join(f"<th>{h}</th>" for h in head)
    tr = "".join("<tr>" + "".join(f"<td>{c}</td>" for c in r) + "</tr>" for r in rows)
    return f'<div class="dtable-wrap"><table class="{cls}"><thead><tr>{th}</tr></thead><tbody>{tr}</tbody></table></div>'


def two(a, b):
    return f'<div class="two">{a}{b}</div>'


def chain(steps):
    """A row of numbered boxes with arrows between them. steps: list of (title, line)."""
    c = "".join(f'<div class="step"><div class="sn">{i+1}</div><div class="st">{t}</div><div class="sl">{l}</div></div>'
                for i, (t, l) in enumerate(steps))
    return f'<div class="chain">{c}</div>'


# ------------------------------------------------------------------ slides

# ------------------------------------------------------------------ slides: "Before monitoring" (discussant deck)
import base64 as _b64


def img(path, mime="image/jpeg"):
    """Embed an asset file as a data URI."""
    if not os.path.exists(path):
        return art("missing")
    return f"data:{mime};base64," + _b64.b64encode(open(path, "rb").read()).decode()


def png_as_jpeg(path, q=82, maxw=1300):
    """Convert a PNG screenshot to an embedded JPEG data URI (smaller page)."""
    from PIL import Image
    import io as _io
    im = Image.open(path).convert("RGB")
    if im.width > maxw:
        im = im.resize((maxw, int(im.height * maxw / im.width)))
    b = _io.BytesIO(); im.save(b, "JPEG", quality=q, optimize=True)
    return "data:image/jpeg;base64," + _b64.b64encode(b.getvalue()).decode()


def tiles(items, cls="ogrid"):
    """items: (name, text, flag) with flag in {'', 'bad', 'note'}"""
    return f'<div class="{cls}">' + "".join(f'<div class="otile {f}"><p class="oname">{n}</p><p class="oval">{t}</p></div>' for n, t, f in items) + "</div>"


def ci_chart(items, x0, x1, ticks, title, w=1180, rowh=46, left=330, right=120, top=46, unit="SD"):
    """Horizontal effect sizes with 95% intervals. items: (label, est, lo, hi, colour, note)."""
    h = top + rowh * len(items) + 44
    X = lambda v: left + (v - x0) / (x1 - x0) * (w - left - right)
    s = [f'<svg class="ds-chart bigtext" viewBox="0 0 {w} {h}" role="img" aria-label="{esc(title)}">', f'<text x="10" y="22" class="ph">{title}</text>']
    for t in ticks:
        s.append(f'<line x1="{X(t):.1f}" y1="{top-8}" x2="{X(t):.1f}" y2="{h-34}" class="g"/><text x="{X(t):.1f}" y="{h-12}" class="ax mid">{t:g}</text>')
    s.append(f'<line x1="{X(0):.1f}" y1="{top-8}" x2="{X(0):.1f}" y2="{h-34}" stroke="var(--text-secondary)" stroke-width="1.4"/>')
    for i, (lab, est, lo, hi, colr, note) in enumerate(items):
        y = top + i * rowh + rowh / 2
        s.append(f'<text x="{left-14}" y="{y+6:.1f}" class="lab end" fill="var(--text-primary)">{lab}</text>')
        if lo is not None:
            s.append(f'<line x1="{X(lo):.1f}" y1="{y:.1f}" x2="{X(hi):.1f}" y2="{y:.1f}" stroke="{colr}" stroke-width="3"/>'
                     f'<line x1="{X(lo):.1f}" y1="{y-7:.1f}" x2="{X(lo):.1f}" y2="{y+7:.1f}" stroke="{colr}" stroke-width="3"/>'
                     f'<line x1="{X(hi):.1f}" y1="{y-7:.1f}" x2="{X(hi):.1f}" y2="{y+7:.1f}" stroke="{colr}" stroke-width="3"/>')
        s.append(f'<circle cx="{X(est):.1f}" cy="{y:.1f}" r="9" fill="{colr}"/>')
        xr = X(hi if hi is not None else est) + 14
        s.append(f'<text x="{xr:.1f}" y="{y+6:.1f}" class="val" fill="{colr}">{est:+.2f}</text>')
        if note:
            s.append(f'<text x="{w-right+110:.1f}" y="{y+6:.1f}" class="ax end" fill="var(--muted)">{note}</text>')
    s.append("</svg>")
    return "\n".join(s)


def roamef_svg(w=600, h=580):
    import math
    cx, cy, r = 300, 290, 205
    names = ["Rationale", "Objectives", "Appraisal", "Monitoring", "Evaluation", "Feedback"]
    s = [f'<svg class="roamef" viewBox="0 0 {w} {h}" role="img" aria-label="The ROAMEF cycle">',
         '<defs><marker id="ah" viewBox="0 0 10 10" refX="8" refY="5" markerWidth="7" markerHeight="7" orient="auto-start-reverse"><path d="M0,0 L10,5 L0,10 z" fill="var(--muted)"/></marker></defs>']
    pts = []
    for i in range(6):
        a = math.radians(90 - i * 60); pts.append((cx + r * math.cos(a), cy - r * math.sin(a), a))
    for i in range(6):
        a0 = math.radians(90 - i * 60 - 20); a1 = math.radians(90 - (i + 1) * 60 + 20)
        x0, y0 = cx + r * math.cos(a0), cy - r * math.sin(a0); x1, y1 = cx + r * math.cos(a1), cy - r * math.sin(a1)
        s.append(f'<path d="M{x0:.1f},{y0:.1f} A{r},{r} 0 0 1 {x1:.1f},{y1:.1f}" fill="none" stroke="var(--muted)" stroke-width="3" marker-end="url(#ah)"/>')
    for (x, y, a), n in zip(pts, names):
        emph = n in ("Rationale", "Objectives", "Appraisal")
        s.append(f'<circle cx="{x:.1f}" cy="{y:.1f}" r="52" fill="{"var(--c8)" if emph else "var(--surface-1)"}" stroke="{"var(--c8)" if emph else "var(--text-primary)"}" stroke-width="2"/>')
        s.append(f'<text x="{x:.1f}" y="{y+6:.1f}" text-anchor="middle" font-size="17" font-weight="700" fill="{"#fff" if emph else "var(--text-primary)"}">{n}</text>')
    s.append(f'<text x="{cx}" y="{cy+8}" text-anchor="middle" font-size="26" font-weight="750" fill="var(--text-primary)">ROAMEF</text>')
    # brackets
    s.append(f'<text x="{cx+120}" y="{cy+235}" font-size="15" font-style="italic" fill="var(--muted)" text-anchor="start">delivery begins</text>')
    s.append("</svg>")
    return "\n".join(s)


def divider(part, title, question, k, alt):
    def f():
        return (f'<div class="viz-root scope-slide2"><div class="wrap"><section class="panel divider">'
                f'<div class="divrow"><div class="covertext"><p class="panel-eyebrow">{part}</p><h2 class="divtitle">{title}</h2>'
                f'<p class="divq">{question}</p></div><img class="divimg" src="{art(k)}" alt="{alt}"></div></section></div></div>')
    return f



# ------------------------------------------------------------------ slides: JDSE session (sustainable economy and finance research)
DD = json.load(open("../data/deck_data.json", encoding="utf-8"))
DD["scopus"] = {int(k): v for k, v in DD["scopus"].items()}
YRS = DD["years"]; SER = DD["series"]

P1 = "Part I &middot; Research trends"
P2 = "Part II &middot; The journals"
P3 = "Part III &middot; Indonesia"
CLS_LABEL = {"Q1": "Scopus Q1", "Q2": "Scopus Q2", "Q3": "Scopus Q3", "Q4": "Scopus Q4", "scopus_unranked": "Scopus, unranked", "delisted": "Delisted by Scopus", "not_indexed": "Not in Scopus", "repository": "Repository", "unknown": "?"}


PUBSHORT = {"Multidisciplinary Digital Publishing Institute": "MDPI", "Emerald Publishing Limited": "Emerald", "American Institute of Mathematical Sciences": "AIMS Press", "Public Library of Science": "PLOS",
            "Springer Science+Business Media": "Springer", "Elsevier BV": "Elsevier", "Springer Nature": "Springer Nature", "Palgrave Macmillan": "Palgrave Macmillan", "Verlag Dr. Otto Schmidt": "Otto Schmidt"}


def pub(p):
    p = p or ""
    return PUBSHORT.get(p, p if len(p) <= 24 else p[:23] + "&hellip;")


def cut(t, k):
    return t if len(t) <= k else t[:k - 1].rstrip() + "&hellip;"


def yr(y):
    return str(y) if y and y >= 1900 else ""


SHORT = {"Sustainable Finance and Green Bonds": "Sustainable finance, green bonds", "Energy, Environment, Economic Growth": "Energy, environment, growth", "FinTech, Crowdfunding, Digital Finance": "FinTech, digital finance",
         "Digital Economy and Transformation": "Digital economy", "Corporate Social Responsibility Reporting": "CSR and ESG reporting", "Blockchain Technology Applications and Security": "Blockchain", "Microfinance and Financial Inclusion": "Financial inclusion",
         "Digital Transformation in Financial Services": "Digital financial services", "Climate Change Policy and Economics": "Climate policy and economics", "Sustainable Development and Environmental Management": "Sustainable development, management",
         "Sustainability and Climate Change Governance": "Climate governance", "Sustainable Development and Environmental Policy": "Sustainable development, policy", "Monetary Policy and Economic Impact": "Monetary policy", "Banking stability, regulation, efficiency": "Banking stability, regulation",
         "Global Financial Crisis and Policies": "Financial crisis and policies", "Financial Markets and Investment Strategies": "Financial markets, investment", "Market Dynamics and Volatility": "Market dynamics, volatility", "COVID-19 Pandemic Impacts": "COVID-19 impacts",
         "Financial Risk and Volatility Modeling": "Financial risk modelling", "University of Pembangunan Nasional Veteran Jawa Timur": "UPN Veteran Jawa Timur", "Muhammadiyah University of Surakarta": "Univ. Muhammadiyah Surakarta", "National Research and Innovation Agency": "BRIN", "Universitas Pembangunan Nasional Veteran Jawa Timur": "UPN Veteran Jawa Timur"}


def short(nm): return SHORT.get(nm, nm)


def qtag(c):
    col = {"Q1": "var(--c2)", "Q2": "var(--c1)", "Q3": "var(--c4)", "Q4": "var(--c4)", "delisted": "var(--c8)", "not_indexed": "var(--muted)"}.get(c, "var(--muted)")
    return f'<span style="color:{col};font-weight:700">{CLS_LABEL.get(c, c)}</span>'


def n(v): return f"{v:,}"


def s_cover():
    return f"""<div class="viz-root scope-slide2"><div class="wrap"><section class="panel cover">
<div class="coverrow"><div class="covertext">
<p class="panel-eyebrow">Bank Indonesia Institute &middot; Konsinyering JDSE &middot; Session 3</p>
<h1 class="cover-title">Sustainable economy and finance research: trends, journals, and a place for JDSE</h1>
<p class="cover-sub">Research trends, the main journals, and Indonesia&rsquo;s position. Based on 650,000 papers and four journal filters.</p>
<p class="cover-by"><b>Arief Anshory Yusuf</b><span class="sep"> &middot; </span><br class="mob">Universitas Padjadjaran</p>
<p class="cover-date">Bandung, 15 October 2026</p>
</div><img class="coverimg" src="{art('cover')}" alt="A plain of open journals with one standing upright, lit"></div>
</section></div></div>"""


def s_frame():
    cs = cards([("I", "Which topics are growing?", "Which themes are growing, which are fading, and how fast the digital and sustainable literatures are meeting."),
                ("II", "Which journals publish this research?", "Which journals carry the work, what they charge, how fast new entrants were indexed, and what a central-bank journal looks like today."),
                ("III", "How much does Indonesia publish, and where?", "How much Indonesia publishes on these themes, where it publishes, and how much of it the world can see.")], "cards three")
    body = cs + '<p class="reveal">A journal&rsquo;s presence is decided by three choices: which conversation it joins, who it is for, and what it does that the incumbents do not. The first two are measurable. The third is a design decision, and the last slide proposes one.</p>'
    src = "OpenAlex (works, topics, sources, institutions), October 2026; Scopus Source List, September 2026; SCImago Journal Rank 2025; Scopus Search API. All queries and outputs in the replication package"
    return panel("Three questions", "What the bibliometrics can tell a journal that does not exist yet", "", body, src)


def s_method1():
    t = tiles([("1 &middot; Corpus", "OpenAlex works, 2010&ndash;2026, articles and reviews. No keyword matching: papers are selected by the topic OpenAlex assigns to every work (the same taxonomy SCImago uses).", ""),
               ("2 &middot; Six sustainable topics", "Sustainable finance and green bonds; climate-change policy and economics; sustainability and climate governance; sustainable development and environmental policy, and management; CSR and ESG reporting. 543,190 works carry at least one of them; 181,067 have one as primary topic, 2016&ndash;2026.", ""),
               ("3 &middot; Five digital topics", "FinTech, crowdfunding and digital finance; digital transformation in financial services; microfinance and financial inclusion; blockchain; digital economy and transformation. 398,142 works.", ""),
               ("4 &middot; The intersection", "Works that carry a topic from both sets: 5,143 works. This is the literature JDSE is named for.", ""),
               ("5 &middot; Themes", "OpenAlex keywords within the sustainable-finance topic, 2015&ndash;2018 against 2023&ndash;2026, as shares of the topic&rsquo;s output.", ""),
               ("6 &middot; Four filters", "Every journal matched by ISSN to the Scopus Source List of September 2026 and to SCImago 2025. Each result is reported for all OpenAlex journals, all Scopus-listed journals, Scopus excluding discontinued titles, and Scopus Q1 excluding discontinued titles.", "note")], "ogrid stella3")
    return panel(P1, "Method: how the field was measured", "", t, "OpenAlex topic IDs: T13146, T10471, T10119, T12013, T12883, T10115 (sustainable); T11995, T13346, T10987, T10270, T12958 (digital). Filter-only queries with server-side group_by; no text search.")


def s_growth():
    i15 = YRS.index(2015)
    def idx(k): base = SER[k][i15]; return [round(100 * v / base, 1) for v in SER[k]]
    series = [{"name": "Sustainable finance and green bonds", "values": idx("T13146"), "color": "var(--c8)", "bold": True},
              {"name": "Digital &times; sustainable (both topics)", "values": idx("intersection"), "color": "var(--c9)", "bold": True},
              {"name": "Digital finance set", "values": idx("digi_any"), "color": "var(--c1)"},
              {"name": "Sustainable set, excl. CSR reporting", "values": idx("sust_noCSR_world"), "color": "var(--muted)"}]
    ch = line_chart(YRS, series, 0, 4000, [0, 500, 1000, 1500, 2000, 2500, 3000, 3500], "Papers per year, index 2015 = 100 (2026 omitted: partial year)", w=1180, h=440, xticks=[2012, 2015, 2018, 2021, 2025], right=330, yfmt=lambda v: f"{v:,.0f}")
    cs = cards([(f"{SER['T13146'][YRS.index(2025)]/SER['T13146'][i15]:.0f}x", "sustainable finance and green bonds, 2015 to 2025", f"{n(SER['T13146'][i15])} to {n(SER['T13146'][YRS.index(2025)])} papers a year"),
                (f"{SER['intersection'][YRS.index(2025)]/SER['intersection'][i15]:.0f}x", "digital &times; sustainable, 2015 to 2025", f"{n(SER['intersection'][i15])} to {n(SER['intersection'][YRS.index(2025)])} papers a year"),
                (f"{DD['scopus'][2025]['world']/DD['scopus'][2015]['world']:.0f}x", "Scopus cross-check, same decade", f"{n(DD['scopus'][2015]['world'])} to {n(DD['scopus'][2025]['world'])} papers with the phrases in title, abstract or keywords")], "cards three")
    body = ch + cs + '<p class="reveal">The wider sustainability literature grew by half in a decade. Sustainable finance grew twelve times, and the digital-sustainable overlap thirty-six times. The growth is at the finance end, and at the intersection.</p>'
    return panel(P1, "Figure 1 &middot; The field is growing at its finance end, and fastest where digital meets sustainable", "", body,
                 "OpenAlex works by publication year, primary topic (sustainable finance; sustainable set) or any topic (digital set; intersection). 2026 is a partial year and is not plotted. Scopus: TITLE-ABS-KEY phrase set, articles and reviews.")


def paired_hbars(labels, a, b, na, nb, x0, x1, ticks, title, w=1180, rowh=27, left=250, right=80, top=72):
    h = top + rowh * len(labels) + 44
    X = lambda v: left + (v - x0) / (x1 - x0) * (w - left - right)
    s = [f'<svg class="ds-chart" viewBox="0 0 {w} {h}" role="img" aria-label="{esc(title)}">', f'<text x="10" y="22" class="ph">{title}</text>']
    for t in ticks:
        s.append(f'<line x1="{X(t):.1f}" y1="{top-8}" x2="{X(t):.1f}" y2="{h-34}" class="g"/><text x="{X(t):.1f}" y="{h-12}" class="ax mid">{t:g}%</text>')
    for i, lab in enumerate(labels):
        y = top + i * rowh
        s.append(f'<text x="{left-12}" y="{y+rowh/2+5:.1f}" class="lab end" fill="var(--text-primary)">{lab}</text>')
        s.append(f'<rect x="{X(0):.1f}" y="{y+3}" width="{max(X(a[i])-X(0),1):.1f}" height="{rowh/2-4}" fill="var(--baseline)"/>')
        s.append(f'<rect x="{X(0):.1f}" y="{y+rowh/2}" width="{max(X(b[i])-X(0),1):.1f}" height="{rowh/2-4}" fill="var(--c8)"/>')
        s.append(f'<text x="{X(a[i])+6:.1f}" y="{y+rowh/2-1:.1f}" class="ax" fill="var(--muted)">{a[i]:.0f}</text><text x="{X(b[i])+6:.1f}" y="{y+rowh-2:.1f}" class="ax" font-weight="700" fill="var(--c8)">{b[i]:.0f}</text>')
    s.append(f'<rect x="10" y="{top-38}" width="12" height="12" fill="var(--baseline)"/><text x="28" y="{top-28}" class="ax">{na}</text><rect x="140" y="{top-38}" width="12" height="12" fill="var(--c8)"/><text x="158" y="{top-28}" class="ax">{nb}</text>')
    s.append("</svg>"); return chr(10).join(s)


def s_themes():
    K = DD["kw_T13146"]["rows"]
    order = ["green finance", "green bonds", "sustainable finance", "climate finance", "climate change mitigation", "green banking", "climate risk", "transition risk", "greenwashing", "ESG ratings", "green credit", "financial stability", "emerging markets", "China", "environmental regulation", "green innovation"]
    rows = {r["kw"]: r for r in K}
    groups = [k for k in order if k in rows]
    series = [{"name": "2015&ndash;2018", "values": [rows[k]["early"] for k in groups], "color": "var(--baseline)"}, {"name": "2023&ndash;2026", "values": [rows[k]["late"] for k in groups], "color": "var(--c8)"}]
    ch = paired_hbars(groups, [rows[k]["early"] for k in groups], [rows[k]["late"] for k in groups], "2015&ndash;2018", "2023&ndash;2026", 0, 40, [0, 10, 20, 30, 40], "Share of papers in the sustainable-finance topic carrying the keyword, %")
    body = ch + tiles([("Fading", "Climate finance (17% to 6%) and climate-change mitigation (8% to 4%): the public-finance and NDC framing of the 2015 Paris years has given way to markets and firms.", ""),
                       ("Rising", "Climate risk (4% to 7%), transition risk and ESG ratings (from nothing), greenwashing (1% to 4%), green credit (2% to 4%), financial stability (1% to 3%): the central-bank and supervisory agenda is now inside the topic.", "bad"),
                       ("Geography", "China rose from 2% to 7% of the topic; emerging markets from 1% to 4%. The empirical centre of the field moved east and south.", "note")], "ogrid stella3")
    return panel(P1, "Figure 2 &middot; The themes moved from climate finance to climate risk, from public money to firms, banks and ratings", "", body,
                 f"OpenAlex keywords on works whose primary topic is Sustainable finance and green bonds: {n(DD['kw_T13146']['early_total'])} works in 2015-2018, {n(DD['kw_T13146']['late_total'])} in 2023-2026. A work can carry several keywords. Keyword assignment is less complete for older works, so early shares are lower bounds.")


def s_intersection():
    series = [{"name": "", "label": False, "values": SER["intersection"], "color": "var(--c8)", "bold": True}]
    ch = line_chart(YRS, series, 0, 1600, [0, 400, 800, 1200, 1600], "Papers per year with both a digital and a sustainable topic", w=620, h=360, xticks=[2012, 2016, 2020, 2025], right=30, dots=False, yfmt=lambda v: f"{v:,.0f}")
    top = DD["intersection_topics"]
    hb = hbars([(short(nm), c, "var(--c8)" if i == 0 else "var(--c9)", i == 0) for i, (nm, c) in enumerate(top)], 0, 1200, [0, 400, 800, 1200], "Primary topic of the 5,143 intersection papers", w=560, rowh=34, left=280, right=70, valfmt=lambda v: n(int(v)))
    body = two(ch, hb) + tiles([("What it is", "Green bonds and fintech; digital finance and the energy transition; blockchain for carbon markets and ESG data; financial inclusion and climate resilience. Still only 5,143 papers in sixteen years, 1,479 in 2025.", ""),
                                ("Where it goes now", "Its venues are the generalists: Sustainability, Finance Research Letters, Environmental Science and Pollution Research. No journal is built for it.", "bad"),
                                ("What that means", "The intersection is small, growing at 30&ndash;40% a year, and has no specialist journal. A new journal can specialise in it.", "note")], "ogrid stella3")
    return panel(P1, "Figure 3 &middot; The digital-sustainable intersection is small, fast and has no home journal", "", body,
                 "OpenAlex works carrying at least one topic from each set, 2010-2026. Venue list from the same query grouped by source.")


def s_topcited():
    rows = [[f"<b>{cut(w['title'], 78)}</b>", w["venue"] or "", str(w["year"]), n(w["cites"])] for w in DD["top_cited"][:10]]
    t = table(["Most cited papers in the sustainable-finance topic, 2016&ndash;2026", "Journal", "Year", "Citations"], rows, cls="dtable meals cited")
    body = t + '<p class="reveal">The most cited papers are in top finance journals, not in sustainability journals. JDSE will not compete for these papers. It can compete for applied and policy papers. Most papers from emerging markets are of this kind.</p>'
    return panel(P2, "Figure 4 &middot; The most cited papers are in the top finance journals", "", body, "OpenAlex, works with primary topic Sustainable finance and green bonds, 2016-2026, sorted by citations, October 2026.")


META_ALL = json.load(open("../data/sources_meta.json", encoding="utf-8"))
OM = json.load(open("../data/deck_data_oamodel.json", encoding="utf-8"))
_BYNAME = {}
for _sid, _m in META_ALL.items():
    _k = _m.get("display_name")
    if _k and (_k not in _BYNAME or (_m.get("works_count") or 0) > (META_ALL[_BYNAME[_k]].get("works_count") or 0)): _BYNAME[_k] = _sid


def jmodel(name):
    m = META_ALL.get(_BYNAME.get(name, ""), {})
    if not m: return "", None
    if not m.get("is_oa"): return "sub", m.get("apc_usd")
    if m.get("apc_usd"): return "oa_apc", m.get("apc_usd")
    if m.get("apc_usd") == 0 or m.get("is_in_doaj"): return "oa_free", 0
    return "oa_unknown", None


def model_cells(name):
    k, apc = jmodel(name)
    if k == "sub": return "Subscription", (f"${apc:,} optional" if apc else "optional")
    if k == "oa_apc": return "Open access", f"${apc:,}"
    if k == "oa_free": return "Open access", "none"
    if k == "oa_unknown": return "Open access", ""
    return "", ""


def venue_rows(key, n_rows=12):
    out = []
    for r in DD[key][:n_rows]:
        mo, apc = model_cells(r["name"])
        out.append([f"<b>{cut(r['name'], 52)}</b>", qtag(r["cls"]), pub(r.get("publisher")), mo, apc, str(r.get("h") or ""), f"{(r.get('cite2y') or 0):.1f}", n(r["count"])])
    return out


def s_venues_all():
    t = table(["Journal", "Index status", "Publisher", "Model", "APC", "h", "2-yr cites", "Papers"], venue_rows("venues_sust", 10), cls="dtable meals venues")
    sh = DD["class_shares"]["venue_sust_primary"]["shares_of_top200"]
    cs = cards([(f"{sh.get('Q1', 0):.0f}%", "of the output in the 200 largest venues is in Scopus Q1 journals", "Q2 to Q4 add another 6%. Across all venues the Q1 share is 33% (filter table)"),
                (f"{sh.get('not_indexed', 0) + sh.get('delisted', 0):.0f}%", "is in journals Scopus does not index, or has delisted", "repositories and preprints hold the remaining 18%"),
                (f"{sum(1 for r in DD['venues_sust'][:10] if jmodel(r['name'])[0] == 'sub')} of 10", "top journals are subscription journals: publishing is free for authors", "Open access there is optional and costs $3,450&ndash;4,660. Sustainability (MDPI) charges every author $2,896")], "cards three")
    body = t + cs
    return panel(P2, "Figure 5 &middot; Main journals for the six topics: one very large journal, then Elsevier and Wiley Q1 journals", "", body,
                 f"Works with a sustainable primary topic, 2016-2026, grouped by source: {n(DD['class_shares']['venue_sust_primary']['total'])} works, of which {n(DD['class_shares']['venue_sust_primary']['covered_by_top200'])} in the 200 largest venues. Index status: Scopus Source List September 2026 and SCImago 2025, matched by ISSN. h and 2-year citedness from OpenAlex.")


def s_venues_core():
    SP = json.load(open("../data/deck_data_specialist.json", encoding="utf-8"))
    rows = venue_rows("venues_T13146", 10)
    for r, v in zip(rows, DD["venues_T13146"][:10]):
        sp = SP.get(v["name"], {}).get("share")
        r.append(f"<b>{sp:.0f}%</b>" if sp is not None and sp >= 25 else (f"{sp:.1f}%" if sp is not None else ""))
    t = table(["Journal", "Index status", "Publisher", "Model", "APC", "h", "2-yr cites", "Papers", "Topic share"], rows, cls="dtable meals venues")
    sh = DD["class_shares"]["venue_T13146"]["shares_of_top200"]
    cs = cards([(f"{sh.get('Q1', 0):.0f}%", "of sustainable-finance output in the 200 largest venues is Scopus Q1", "lower than for the six topics together"),
                (f"{sh.get('not_indexed', 0) + sh.get('delisted', 0):.0f}%", "is outside Scopus", "trade magazines, student journals and new journals not yet indexed"),
                ("1", "specialist journal in the top ten: Journal of Sustainable Finance &amp; Investment", "37% of its papers are in this topic. For the other nine it is 5% or less")], "cards three")
    body = t + cs
    return panel(P2, "Figure 6 &middot; Sustainable finance papers appear mostly in general finance journals. Only one top journal is a specialist", "", body,
                 f"Works with primary topic Sustainable finance and green bonds, 2016-2026: {n(DD['class_shares']['venue_T13146']['total'])} works. Same classification as Figure 5. Topic share = the journal&rsquo;s papers in this topic &divide; all its papers, 2016-2026 (OpenAlex yearly counts). Specialist = topic share above 25%.")


def s_launched():
    pick = ["Journal of Sustainable Finance & Investment", "Financial Innovation", "Borsa Istanbul Review", "China Finance Review International", "Sustainability Accounting Management and Policy Journal", "Climate Risk Management",
            "Green Finance", "Discover Sustainability", "Journal of Climate Finance", "PLOS Climate", "Sustainable Futures", "Earth System Governance", "Humanities and Social Sciences Communications"]
    L = {r["name"]: r for r in DD["launched"]}
    rows = []
    for nm in pick:
        r = L.get(nm)
        if not r: continue
        yti = r["cov_first"] - r["first_year"]
        rows.append([f"<b>{cut(nm, 50)}</b>", pub(r.get("publisher")), str(r["first_year"]), str(r["cov_first"]), f"<b>{yti}</b>", qtag(r["cls"]), model_cells(nm)[1] if model_cells(nm)[0] != "Open access" else (model_cells(nm)[1] or "none"), str(r.get("h")), f"{(r.get('cite2y') or 0):.1f}"])
    t = table(["Journal launched since 2010", "Publisher", "First year", "In Scopus from", "Years to index", "Status 2025", "APC", "h", "2-yr cites"], rows, cls="dtable meals venues")
    cs = cards([("0&ndash;1 year", "to Scopus for journals launched by a large publisher", "Elsevier, Wiley, Emerald, Taylor &amp; Francis titles were indexed from their first or second volume"),
                ("3 years", "for Financial Innovation, hosted by a Chinese university, published by Springer, no APC", "now Q1, h 83, 2-year citedness 10.3. A good model for a journal hosted by an institution"),
                ("5 years", "for journals started without a large publisher", "Sustainable Futures, Earth System Governance, Humanities and Social Sciences Communications")], "cards three")
    body = t + cs
    return panel(P2, "Figure 7 &middot; New journals entered Scopus in 0 to 3 years when a large publisher or a strong institution supported them", "", body,
                 "Journals launched 2010 or later that appear in the venue lists of Figures 5-7 with at least 20 papers. First year = first year with works in OpenAlex; Scopus coverage start from SCImago 2025. Borsa Istanbul Review is hosted by the Istanbul stock exchange; Financial Innovation by Southwestern University of Finance and Economics, Chengdu.")


def s_benchmarks():
    b = DD["bmeb"]
    tb = table(["Journal", "Host", "Since", "Scopus", "h", "2-yr cites", "First authors&rsquo; countries"],
               [["<b>Bulletin of Monetary Economics and Banking</b>", "Bank Indonesia", "1998", "Q2", "33", "1.9", "Indonesia 43%, India 13%, Australia 13%, Malaysia 7%"],
                ["International Journal of Central Banking", "central banks&rsquo; consortium", "2005", "Q1", "22", "n/a", "US, UK, euro area"],
                ["Borsa Istanbul Review", "Borsa Istanbul, with Elsevier", "2013", "Q1", "74", "6.5", "Turkey, China, India, Pakistan"],
                ["Financial Innovation", "SWUFE Chengdu, with Springer", "2012", "Q1", "83", "10.3", "China, India, Pakistan, Vietnam"],
                ["Journal of Sustainable Finance &amp; Investment", "Taylor &amp; Francis", "2011", "Q1", "66", "5.1", "UK, US, India, China"],
                ["Journal of Climate Finance", "Elsevier", "2022", "Q1", "18", "7.5", "China, US, UK, Germany"]], cls="dtable meals venues")
    hb = hbars([(short(nm), c, "var(--c9)", False) for nm, c in b["topics"][:8]], 0, 100, [0, 25, 50, 75, 100], "BMEB, primary topic of its 381 papers, 2016-2026", w=560, rowh=32, left=250, right=60, valfmt=lambda v: n(int(v)))
    body = two(tb, hb) + '<p class="reveal">BMEB is the baseline. It is a Bank Indonesia journal in Scopus. 43% of its authors are Indonesian. Its h-index is 33, with two citations per paper in two years. Sustainable finance is not among its main topics. An institution-hosted journal can reach Q1 in three years. Central-bank hosting alone is not enough: IJCB has an h-index of 22 after twenty years.</p>'
    return panel(P2, "Figure 8 &middot; BI&rsquo;s current journal, and institution-hosted journals that reached Q1", "", body,
                 "OpenAlex sources and works, October 2026; SCImago 2025 quartiles. Author countries from OpenAlex authorships, 2016-2026. IJCB two-year citedness is not reported by OpenAlex (0 recorded).")


def s_oa():
    oa = DD["oa"]; tot = DD["oa_total"]
    items = [("Closed", oa["closed"]), ("Diamond (free to read and publish)", oa["diamond"]), ("Hybrid", oa["hybrid"]), ("Green (repository copy)", oa["green"]), ("Gold (APC)", oa["gold"]), ("Bronze", oa["bronze"])]
    hb = hbars([(lab, round(100 * v / tot, 1), "var(--c8)" if "Diamond" in lab else "var(--c9)", "Diamond" in lab) for lab, v in items], 0, 45, [0, 10, 20, 30, 40], "Open-access status of the sustainable set, % of 181,067 papers, 2016-2026", w=1180, rowh=40, left=330, right=90, valfmt=lambda v: f"{v:.0f}%")
    cs = cards([("38%", "of the field is behind a paywall", "mostly the Elsevier and Wiley Q1 titles"),
                ("23%", "is diamond open access: no fee to read, no fee to publish", "almost all of it in journals outside Scopus, which is why it is invisible"),
                ("0", "Q1 journals in Figures 5 and 6 that are diamond and specialist", "JSFI and Climate Policy charge no APC but are subscription titles")], "cards three")
    body = hb + cs + '<p class="reveal">The gap in the market is specific: a diamond open-access journal, on a Scopus track, for sustainable and digital finance in emerging markets. A central bank can afford to run one without an APC. Almost nobody else can.</p>'
    return panel(P2, "Figure 9 &middot; A diamond open-access journal on an indexing track does not exist in this field", "", body, "OpenAlex open_access.oa_status on works with a sustainable primary topic, 2016-2026.")


def s_id_share():
    share_all = [round(100 * i / w, 1) for i, w in zip(SER["id_all"], SER["sust_primary"])]
    share_no = [round(100 * i / w, 1) for i, w in zip(SER["id_noCSR"], SER["sust_noCSR_world"])]
    share_cn = [round(100 * c / w, 1) for c, w in zip(SER["cn"], SER["sust_primary"])]
    ch = line_chart(YRS, [{"name": "Indonesia, all six topics", "values": share_all, "color": "var(--c8)", "bold": True}, {"name": "Indonesia, excl. CSR reporting", "values": share_no, "color": "var(--c9)", "bold": True},
                          {"name": "China, all six topics", "values": share_cn, "color": "var(--muted)", "dash": "6 4"}], 0, 16, [0, 4, 8, 12, 16], "Share of the world&rsquo;s papers with an author from the country, %", w=1180, h=420, xticks=[2012, 2015, 2018, 2021, 2025], right=300, yfmt=lambda v: f"{v:g}%")
    cs = cards([("2nd", "Indonesia&rsquo;s rank in the world by papers in the six sustainable topics, 2016-2026", f"{n(DD['country_totals']['sust'])} papers worldwide; Indonesia {n(14647)}, after China, ahead of the United States"),
                ("85%", "of Indonesia&rsquo;s papers are in one topic: CSR and ESG reporting", "12,418 of 14,647, mostly accounting studies of listed firms"),
                ("5th", "in sustainable finance and green bonds proper", "948 papers, 4.1% of the topic; China 3,959, India 1,194, US 1,040, UK 1,018")], "cards three")
    body = ch + cs
    return panel(P3, "Figure 11 &middot; Indonesia is the world&rsquo;s second producer in the sustainable set, and most of it is one topic", "", body,
                 "OpenAlex works with a sustainable primary topic and at least one author with an Indonesian (or Chinese) affiliation, by publication year, divided by the world total of the same topics. 2026 omitted.")


def s_countries():
    a = DD["countries_T13146"]; b = DD["countries_sust"]
    h1 = hbars([(nm, c, "var(--c8)" if k == "ID" else "var(--c9)", k == "ID") for nm, k, c in a], 0, 4200, [0, 1000, 2000, 3000, 4000], "Sustainable finance and green bonds, papers 2016-2026, by author country", w=580, rowh=30, left=200, right=70, valfmt=lambda v: n(int(v)))
    h2 = hbars([(nm, c, "var(--c8)" if k == "ID" else "var(--c9)", k == "ID") for nm, k, c in b], 0, 20000, [0, 5000, 10000, 15000, 20000], "All six sustainable topics, papers 2016-2026, by author country", w=580, rowh=30, left=200, right=70, valfmt=lambda v: n(int(v)))
    body = two(h1, h2) + '<p class="reveal">In the finance topic Indonesia is close to India, the US and the UK, well behind China. In the wider set it is second only to China. The difference between the two charts is the CSR-reporting literature.</p>'
    return panel(P3, "Figure 12 &middot; Two league tables: in sustainable finance Indonesia is fifth, in the wider set second", "", body, "OpenAlex, authorships.countries, works with the stated primary topic, 2016-2026. A paper counts once per country.")


def s_id_venues():
    groups = ["World", "ASEAN-6", "Indonesia, excl. CSR", "Indonesia, all"]
    keys = ["venue_sust_primary", "venue_sust_asean", "venue_sust_noCSR_id", "venue_sust_id"]
    def sh(k, c): return DD["class_shares"][k]["shares_of_top200"].get(c, 0)
    series = [{"name": "Scopus Q1", "values": [sh(k, "Q1") for k in keys], "color": "var(--c2)"},
              {"name": "Scopus Q2-Q4", "values": [round(sh(k, "Q2") + sh(k, "Q3") + sh(k, "Q4"), 1) for k in keys], "color": "var(--c1)"},
              {"name": "Delisted", "values": [sh(k, "delisted") for k in keys], "color": "var(--c8)"},
              {"name": "Not in Scopus", "values": [sh(k, "not_indexed") for k in keys], "color": "var(--muted)"}]
    ch = gvbars(groups, series, 0, 100, [0, 25, 50, 75, 100], "Where the papers are published, % of output in the 200 largest venues", w=600, h=420, left=60, bottom=60, valfmt=lambda v: f"{v:.0f}")
    rows = [[f"<b>{cut(r['name'], 48)}</b>", qtag(r["cls"]), pub(r.get("publisher")), n(r["count"])] for r in DD["venues_id"][:10]]
    t = table(["Indonesia&rsquo;s largest venues, sustainable set", "Index status", "Publisher", "Papers"], rows, cls="dtable meals venues")
    body = two(ch, t) + tiles([("The 90%", "Nine in ten Indonesian papers on these themes are in journals Scopus does not index: university accounting journals, Owner, COSTING, KnE proceedings. Correct for the CSR topic and it is still seven in ten.", "bad"),
                               ("The Scopus view", f"Scopus itself sees {n(DD['scopus'][2025]['indonesia'])} Indonesian papers in 2025 for the phrase set, 3.2% of the world; ASEAN-6 {n(DD['scopus'][2025]['asean6'])}, 8.6%.", ""),
                               ("The implication", "The authors exist and are productive. What they lack is a venue that is both reachable and indexed. That is the author base JDSE can serve, if it keeps quality high.", "note")], "ogrid stella3")
    return panel(P3, "Figure 13 &middot; Nine in ten Indonesian papers on these themes are invisible to Scopus", "", body,
                 "Same venue classification as Figure 5, applied to works with an Indonesian author (all six topics; and excluding CSR and ESG reporting) and to ASEAN-6 (Indonesia, Malaysia, Thailand, Vietnam, Philippines, Singapore). Scopus cross-check: TITLE-ABS-KEY phrase set with AFFILCOUNTRY.")


def s_id_inst():
    hb = hbars([(short(nm), c, "var(--c9)", False) for nm, c in DD["inst_id"]], 0, 650, [0, 200, 400, 600], "Indonesian institutions, papers in the six sustainable topics, 2016-2026", w=620, rowh=32, left=270, right=70, valfmt=lambda v: n(int(v)))
    tp = hbars([(short(nm), c, "var(--c8)" if i == 0 else "var(--c9)", i == 0) for i, (nm, c) in enumerate(DD["topic_id"])], 0, 13000, [0, 4000, 8000, 12000], "Indonesia&rsquo;s papers by primary topic", w=540, rowh=36, left=290, right=80, valfmt=lambda v: n(int(v)))
    body = two(hb, tp) + '<p class="reveal">The producers are not the usual top five. Trisakti leads; Udayana, Brawijaya, Sebelas Maret, Diponegoro and the regional universities follow. This is a broad base of applied researchers writing about listed firms&rsquo; disclosures, in Indonesian, for local journals. The journal&rsquo;s job is to pull the best of this toward finance questions a central bank cares about.</p>'
    return panel(P3, "Figure 14 &middot; Who writes it in Indonesia: a broad base outside the top five, almost all on CSR reporting", "", body, "OpenAlex authorships.institutions.lineage and primary_topic for works with an Indonesian author, 2016-2026.")


def s_implications():
    t = tiles([("1 &middot; Position at the intersection", "Digital and sustainable finance together is a 5,000-paper literature growing 35% a year with no specialist journal (Figure 3). Name it in the title, the aims and the first call.", ""),
               ("2 &middot; Follow the themes that rose", "Climate and transition risk, green credit, financial stability, ESG ratings and greenwashing, carbon pricing (Figure 2). These are supervisory questions; a central bank is the natural host.", ""),
               ("3 &middot; Serve the emerging-market author", "Indonesia is second in the world by count and 90% invisible (Figures 11 and 13). ASEAN-6 is the first author base; India, Pakistan and Vietnam are where Borsa Istanbul Review and Financial Innovation found theirs (Figure 8).", ""),
               ("4 &middot; Be diamond, and be indexed", "No fee to read or publish, on a Scopus track from the first issue (Figure 9). The institution-hosted models reached Q1 in three years; DOAJ in year one, Scopus application after two years of regular issues (Figure 7).", "bad"),
               ("5 &middot; Require data and code, publish briefs", "Every empirical paper with replication files; a two-page policy brief alongside. Few journals in the field do either. It is cheap for a host that already has analysts.", ""),
               ("6 &middot; Measure from day one", "Citations, author countries, topic mix and index status, from OpenAlex, on a public page. BMEB&rsquo;s h 33 and two citations per paper in two years is the baseline to beat, and the number to report against.", "note")], "ogrid stella3")
    return panel("Implications", "What the evidence implies for JDSE", "", t, "Each card points to the figure that supports it.")


def s_sources():
    body = ('<p class="srcs">OpenAlex works, topics, keywords and sources, retrieved 14 October 2026 with the filter-only API; six sustainable and five digital topic IDs listed on the method slide. '
            'Scopus Search API (Elsevier), 14 October 2026, phrase set in TITLE-ABS-KEY. SCImago Journal Rank 2025 for quartiles and coverage years; Scopus Source List, September 2026. '
            'Method follows the Indonesian research-quality study (anshory1972.github.io/dataslide/researchquality.html): classification by assigned topic, not keyword matching; journal status by ISSN; repositories separated from journals.</p>'
            '<p class="srcs">Limits. OpenAlex is a reliable census of the literature and less reliable on who wrote it; institution counts are indicative. Topic assignment is probabilistic. Keyword coverage is thinner before 2020, so early-period shares are lower bounds. 2026 is a partial year. Index status is as of September 2026.</p>')
    return panel("Sources", "Sources and limits", "", body, "")


SLIDES = [(s_cover, "Cover"), (s_frame, "Three questions"),
          (divider("Part I", "Which topics are growing?", "Growth, themes, and papers that combine digital and sustainable finance", "div1", "A tree with a river-delta canopy, its newest tips lit"), "Part I"),
          (s_method1, "Method"), (s_growth, "Fig 1 growth"), (s_themes, "Fig 2 themes"), (s_intersection, "Fig 3 intersection"), (s_topcited, "Fig 4 top cited"),
          (divider("Part II", "Which journals publish this research?", "Main journals, their fees, how fast new journals entered Scopus, and BI&rsquo;s current journal", "div2", "A row of gates, one small new gate open"), "Part II"),
          (s_venues_all, "Fig 5 venues"), (s_venues_core, "Fig 6 core venues"), (s_launched, "Fig 7 launches"), (s_benchmarks, "Fig 8 benchmarks"), (s_oa, "Fig 9 open access"),
          (divider("Part III", "How much does Indonesia publish, and where?", "Volume, topics, journals, and how much is in Scopus", "div3", "An archipelago with paper boats sailing to a continent"), "Part III"),
          (s_id_share, "Fig 11 share"), (s_countries, "Fig 12 countries"), (s_id_venues, "Fig 13 Indonesian venues"), (s_id_inst, "Fig 14 institutions"),
          (s_implications, "Implications"), (s_sources, "Sources"),
          (divider("", "Thank you", "Arief Anshory Yusuf &middot; Universitas Padjadjaran", "thanks", "A figure placing the first volume on an empty shelf"), "Thank you")]


# ------------------------------------------------------------------ four-tier versions of the figures (override the single-corpus ones)
DT = json.load(open("../data/deck_data_tiers.json", encoding="utf-8"))
TY = DT["years"]; TS = DT["series"]
TIERS = ["all", "scopus", "active", "q1"]
TN = {"all": "All OpenAlex journals", "scopus": "Scopus, all listed", "active": "Scopus, excl. discontinued", "q1": "Scopus Q1, excl. discontinued"}
TC = {"all": "var(--baseline)", "scopus": "var(--muted)", "active": "var(--c9)", "q1": "var(--c8)"}
Y25, Y15 = TY.index(2025), TY.index(2015)
FUN = DT["funnel"]


def pct(a, b): return 100 * a / b if b else 0


def mult(k, t): return TS[k][t][Y25] / max(TS[k][t][Y15], 1)


def tier_legend():
    return '<div class="tlegend">' + "".join(f'<span><i style="background:{TC[t]}"></i>{TN[t]}</span>' for t in TIERS) + "</div>"


def stacked_hbars(rows, cats, colours, title, w=1180, rowh=44, left=260, right=40, top=84):
    """rows: list of (label, {cat: value}) with values summing to 100."""
    h = top + rowh * len(rows) + 50
    X = lambda v: left + v / 100 * (w - left - right)
    s = [f'<svg class="ds-chart" viewBox="0 0 {w} {h}" role="img" aria-label="{esc(title)}">', f'<text x="10" y="22" class="ph">{title}</text>']
    lx = left
    for c in cats:
        s.append(f'<rect x="{lx}" y="{top-40}" width="12" height="12" fill="{colours[c]}"/><text x="{lx+16}" y="{top-30}" class="ax">{c}</text>'); lx += 24 + 8 * len(c)
    for i, (lab, vals) in enumerate(rows):
        y = top + i * rowh; x = 0
        s.append(f'<text x="{left-12}" y="{y+rowh/2+4:.1f}" class="lab end" fill="var(--text-primary)">{lab}</text>')
        for c in cats:
            v = vals.get(c, 0)
            if v <= 0: continue
            s.append(f'<rect x="{X(x):.1f}" y="{y+6}" width="{X(x+v)-X(x):.1f}" height="{rowh-14}" fill="{colours[c]}"/>')
            if v >= 6: s.append(f'<text x="{(X(x)+X(x+v))/2:.1f}" y="{y+rowh/2+4:.1f}" class="ax mid" font-weight="700" style="fill:{'#ffffff' if colours[c] in ('var(--c9)', 'var(--c8)') else '#1f1f1f'}">{v:.0f}%</text>')
            x += v
    s.append("</svg>"); return chr(10).join(s)


def s_tiers():
    rows = []
    for key, lab in [("S", "Six sustainable topics (primary topic)"), ("T13146", "Sustainable finance and green bonds"), ("inter", "Digital &times; sustainable intersection"),
                     ("S_ASEAN", "Six topics, an ASEAN-6 author"), ("S_ID", "Six topics, an Indonesian author"), ("S_ID_noCSR", "Indonesian author, excl. CSR reporting")]:
        f = FUN.get(key, {}); a = f.get("all", 0)
        rows.append([f"<b>{lab}</b>", n(a)] + [f"{n(f.get(t, 0))} <span class='ns'>{pct(f.get(t, 0), a):.0f}%</span>" for t in ["scopus", "active", "q1"]])
    t = table(["Works 2016&ndash;2026"] + [TN[x] for x in TIERS], rows, cls="dtable meals tiers")
    cs = cards([("4 filters", "every result is computed four times", "each filter keeps fewer papers than the one before"),
                (f"{pct(FUN['S'].get('q1', 0), FUN['S']['all']):.0f}%", "of the world&rsquo;s sustainable-topic papers are in Scopus Q1 journals", f"{pct(FUN['S'].get('active', 0), FUN['S']['all']):.0f}% are in a Scopus journal that was not discontinued"),
                ("1,816", "journals discontinued by Scopus, September 2026 list", "their papers count in filter 2 but not in filters 3 and 4")], "cards three")
    body = t + cs + ('<p class="tnote">All OpenAlex journals: every source OpenAlex types as a journal; repositories, preprint servers and works without a source are excluded. '
                     'Scopus, all listed: ISSN or EISSN on the official Scopus Source List, September 2026, including its discontinued titles. Scopus, excl. discontinued: listed and not discontinued by Scopus (active and inactive titles both kept). '
                     'Scopus Q1, excl. discontinued: the same, and SCImago 2025 best quartile Q1. Matching is by ISSN.</p>')
    return panel("Data and method", "Four journal filters: all journals, and three Scopus levels", "", body,
                 "Per-work OpenAlex downloads (248,756 sustainable-topic works and 398,142 digital-topic works, 2010-2026), each journal matched by ISSN to the Scopus Source List, September 2026, and to SCImago 2025 quartiles. Counts are works 2016-2026.")


def s_growth():
    lines_T = [{"name": TN[t], "values": TS["T13146"][t][:-1], "color": TC[t], "bold": t == "q1"} for t in TIERS]
    ch1 = line_chart(TY[:-1], lines_T, 0, 6000, [0, 1500, 3000, 4500, 6000], "Sustainable finance and green bonds, papers per year", w=620, h=380, xticks=[2010, 2015, 2020, 2025], right=40, yfmt=lambda v: f"{v:,.0f}")
    for L in lines_T: L["label"] = False
    ch1 = line_chart(TY[:-1], lines_T, 0, 6000, [0, 1500, 3000, 4500, 6000], "Sustainable finance and green bonds, papers per year", w=620, h=380, xticks=[2010, 2015, 2020, 2025], right=30, yfmt=lambda v: f"{v:,.0f}")
    lines_I = [{"name": TN[t], "values": TS["S"][t][:-1], "color": TC[t], "bold": t == "q1", "label": False} for t in TIERS]
    ch2 = line_chart(TY[:-1], lines_I, 0, 25000, [0, 5000, 10000, 15000, 20000, 25000], "All six sustainable topics, papers per year", w=620, h=380, xticks=[2010, 2015, 2020, 2025], right=30, yfmt=lambda v: f"{v:,.0f}")
    rows = [[lab] + [f"{mult(k, t):.0f}&times;" for t in TIERS] for k, lab in [("T13146", "Sustainable finance and green bonds"), ("inter", "Digital &times; sustainable intersection"), ("D", "Digital finance set"), ("noCSR", "Sustainable set excl. CSR reporting"), ("S", "All six sustainable topics")]]
    t = table(["Growth 2015 to 2025"] + [TN[x] for x in TIERS], rows, cls="dtable meals tiers")
    body = tier_legend() + two(ch1, ch2) + t
    return panel(P1, "Figure 1 &middot; The field tripled in ten years. Sustainable finance grew 19 to 42 times, under all four filters", "", body,
                 "Per-work OpenAlex data by publication year and journal tier. 2026 is partial and not plotted. Growth = papers in 2025 divided by papers in 2015.")


def s_themes():
    def chart(t, title):
        K = {r["kw"]: r for r in DT["kw"][t]["rows"]}
        groups = ["green finance", "green bonds", "sustainable finance", "climate finance", "climate mitigation", "climate risk", "transition risk", "greenwashing", "ESG ratings", "green credit", "financial stability", "emerging markets", "China"]
        G = lambda g: "climate change mitigation" if g == "climate mitigation" else g
        return paired_hbars(groups, [K[G(g)]["early"] for g in groups], [K[G(g)]["late"] for g in groups], "2015&ndash;2018", "2023&ndash;2026", 0, 40, [0, 10, 20, 30, 40], title, w=580, rowh=31, left=190, right=40)
    a = chart("all", f"All OpenAlex journals (n = {n(DT['kw']['all']['n_early'])} and {n(DT['kw']['all']['n_late'])})")
    b = chart("q1", f"Scopus Q1, excl. discontinued (n = {n(DT['kw']['q1']['n_early'])} and {n(DT['kw']['q1']['n_late'])})")
    K1 = {r["kw"]: r for r in DT["kw"]["q1"]["rows"]}; KA = {r["kw"]: r for r in DT["kw"]["all"]["rows"]}
    body = two(a, b) + tiles([("Biggest change: green finance", f"Green finance is in {KA['green finance']['late']:.0f}% of recent papers in all journals, up from {KA['green finance']['early']:.0f}%. In Q1 it rose from {K1['green finance']['early']:.0f}% to {K1['green finance']['late']:.0f}%. Papers on China rose from {K1['China']['early']:.0f}% to {K1['China']['late']:.0f}% in Q1.", "bad"),
                              ("Climate finance fell", f"Climate finance fell from {KA['climate finance']['early']:.0f}% to {KA['climate finance']['late']:.0f}% in all journals, and from {K1['climate finance']['early']:.0f}% to {K1['climate finance']['late']:.0f}% in Q1. Climate mitigation also fell.", ""),
                              ("New topics, still small", f"Transition risk, greenwashing and ESG ratings were near zero in 2015&ndash;2018. Now each is 3&ndash;5% of papers. Climate risk rose from {KA['climate risk']['early']:.0f}% to {KA['climate risk']['late']:.0f}% in all journals, but only from {K1['climate risk']['early']:.0f}% to {K1['climate risk']['late']:.0f}% in Q1. The early Q1 sample is small: {n(DT['kw']['q1']['n_early'])} papers.", "note")], "ogrid stella3")
    return panel(P1, "Figure 2 &middot; Green finance now dominates. Climate finance fell. Risk, ratings and greenwashing are new but still small", "", body,
                 "OpenAlex keywords on works whose primary topic is Sustainable finance and green bonds, share of works carrying the keyword, 2015-2018 against 2023-2026, by journal tier. Keyword assignment is thinner for older works.")


def s_intersection():
    lines = [{"name": TN[t], "values": TS["inter"][t][:-1], "color": TC[t], "bold": t == "q1", "label": False} for t in TIERS]
    ch = line_chart(TY[:-1], lines, 0, 1600, [0, 400, 800, 1200, 1600], "Papers per year with both a digital and a sustainable topic", w=620, h=360, xticks=[2010, 2015, 2020, 2025], right=30, yfmt=lambda v: f"{v:,.0f}")
    top = DT["inter_topics"]["q1"]
    hb = hbars([(short(TOPIC_NM.get(k, k)), c, "var(--c8)" if i == 0 else "var(--c9)", i == 0) for i, (k, c) in enumerate(top)], 0, max(c for _, c in top) * 1.15, [0, 100, 200, 300], f"Primary topic of the {n(FUN['inter']['q1'])} intersection papers in Q1 journals", w=560, rowh=32, left=300, right=60, valfmt=lambda v: n(int(v)))
    qv = ", ".join(v[0] for v in DT["inter_venues"]["q1"][:4])
    body = tier_legend() + two(ch, hb) + tiles([("Size", f"{n(FUN['inter']['all'])} papers in all journals, 2010-2026; {n(FUN['inter']['active'])} in non-discontinued Scopus journals; {n(FUN['inter']['q1'])} in Q1.", ""),
                                                ("Q1 journals that publish it", f"{qv}. These are general environment and finance journals. None specialises in this topic.", "bad"),
                                                ("Meaning for JDSE", "The topic is small and grows fast under all filters. No journal specialises in it. JDSE can be the first.", "note")], "ogrid stella3")
    return panel(P1, "Figure 3 &middot; Few papers combine digital and sustainable finance. They grow fast. No journal specialises in them", "", body,
                 "OpenAlex works carrying at least one topic from each set, by journal tier.")


TOPIC_NM = {"T13146": "Sustainable Finance and Green Bonds", "T10438": "Energy, Environment, Economic Growth", "T11995": "FinTech, Crowdfunding, Digital Finance", "T12958": "Digital Economy and Transformation",
            "T10115": "Corporate Social Responsibility Reporting", "T10270": "Blockchain Technology Applications and Security", "T10987": "Microfinance and Financial Inclusion", "T13346": "Digital Transformation in Financial Services",
            "T14464": "Community development, social impact", "T11365": "Islamic Finance and Banking Studies", "T10471": "Climate Change Policy and Economics", "T12883": "Sustainable Development and Environmental Management"}


def s_oa():
    cats = ["closed", "hybrid", "gold", "green", "bronze", "diamond"]
    col = {"closed": "var(--c9)", "hybrid": "var(--muted)", "gold": "#c99a2e", "green": "#7a9a6b", "bronze": "#b08060", "diamond": "var(--c8)"}
    rows = []
    for t in TIERS:
        o = DT["oa"][t]; tot = sum(o.values()); rows.append((TN[t], {c: 100 * o.get(c, 0) / tot for c in cats}))
    ch = stacked_hbars(rows, cats, col, "Open-access status of papers in the six topics, 2016-2026, % of papers in each filter")
    dq = lambda t: 100 * DT["oa"][t].get("diamond", 0) / sum(DT["oa"][t].values())
    cs = cards([(f"{dq('all'):.0f}%", "of papers in all journals are diamond: free to read, free to publish", "most of them in journals outside Scopus"),
                (f"{dq('q1'):.0f}%", "of papers in Q1 journals are diamond", "most Q1 papers are behind a paywall or paid by the author"),
                ("the opportunity", "a free-to-publish journal, indexed in Scopus, for sustainable and digital finance", "a central bank can pay the costs, so authors pay nothing")], "cards three")
    return panel(P2, "Figure 9 &middot; Diamond open access is common outside Scopus and rare inside Q1", "", ch + cs, "OpenAlex open_access.oa_status, works with a sustainable primary topic, by journal tier.")


def s_oa_model():
    OMD = json.load(open("../data/deck_data_oamodel.json", encoding="utf-8"))
    names = {"sub": "Subscription (OA optional)", "oa_apc": "OA, APC required", "oa_free": "OA, no APC", "oa_unknown": "OA, fee not known"}
    cats = [names[k] for k in ["sub", "oa_apc", "oa_free", "oa_unknown"]]
    col = {names["sub"]: "var(--c9)", names["oa_apc"]: "#c99a2e", names["oa_free"]: "var(--c8)", names["oa_unknown"]: "var(--baseline)"}
    def row(g, t, lab):
        o = OMD["share"][g][t]; tot = sum(o.values())
        return (lab, {names[k]: 100 * o.get(k, 0) / tot for k in names})
    rows = [row("world", "all", "World, all journals"), row("world", "active", "World, Scopus excl. disc."), row("world", "q1", "World, Scopus Q1"),
            row("ID", "all", "Indonesia, all journals"), row("ID", "active", "Indonesia, Scopus excl. disc."), row("ID", "q1", "Indonesia, Scopus Q1")]
    ch = stacked_hbars(rows, cats, col, "Papers in the six topics, 2016-2026, by the business model of the journal, %. OA = open access", rowh=40, left=300)
    sh = lambda g, t, k: 100 * OMD["share"][g][t].get(k, 0) / sum(OMD["share"][g][t].values())
    sp = OMD["subpaid"]["world"]["q1"]; free_q1 = 100 * (1 - (sp.get("hybrid", 0) + sp.get("gold", 0)) / sum(sp.values()))
    cs = cards([(f"{sh('world', 'q1', 'sub'):.0f}%", "of Q1 papers are in subscription journals", f"Publishing there is free. {free_q1:.0f}% of these papers paid no open-access fee, but readers must pay"),
                (f"{sh('ID', 'q1', 'oa_apc'):.0f}%", "of Indonesia&rsquo;s Q1 papers are in open-access journals that charge every author", f"World: {sh('world', 'q1', 'oa_apc'):.0f}%. Sustainability (MDPI) is Indonesia&rsquo;s largest Q1 journal"),
                ("free for both", "JDSE can be free for authors and for readers", "Subscription journals are free for authors but closed to readers. APC journals are open but charge authors")], "cards three")
    return panel(P2, "Figure 10 &middot; Most Q1 papers are in subscription journals: free to publish, but readers must pay", "", ch + cs,
                 "Journal model from OpenAlex source records: subscription = not a fully open-access journal (open access is optional, through a hybrid fee); open access with APC = fully open-access journal with an APC; no APC = APC of zero or listed in DOAJ without an APC. &lsquo;Fee not known&rsquo; is mostly small open-access journals outside Scopus. Paid fee = papers with hybrid or gold status.")


def s_id_share():
    sh = lambda k, base, t: [round(pct(a, b), 1) for a, b in zip(TS[k][t][:-1], TS[base][t][:-1])]
    l1 = [{"name": TN[t], "values": sh("ID", "S", t), "color": TC[t], "bold": t == "q1", "label": False} for t in TIERS]
    l2 = [{"name": TN[t], "values": sh("ID_noCSR", "noCSR", t), "color": TC[t], "bold": t == "q1", "label": False} for t in TIERS]
    c1 = line_chart(TY[:-1], l1, 0, 16, [0, 4, 8, 12, 16], "Indonesia&rsquo;s share of the world, all six topics, %", w=600, h=360, xticks=[2010, 2015, 2020, 2025], right=30, yfmt=lambda v: f"{v:g}%")
    c2 = line_chart(TY[:-1], l2, 0, 16, [0, 4, 8, 12, 16], "Indonesia&rsquo;s share, excluding CSR and ESG reporting, %", w=600, h=360, xticks=[2010, 2015, 2020, 2025], right=30, yfmt=lambda v: f"{v:g}%")
    s25 = {t: pct(TS["ID"][t][Y25], TS["S"][t][Y25]) for t in TIERS}
    rk = DT["country_rank_ID"]; rkT = DT["country_rank_ID_T13146"]
    cs = cards([(f"{s25['all']:.0f}% &rarr; {s25['q1']:.1f}%", "Indonesia&rsquo;s share of 2025 papers, all journals against Q1", f"non-discontinued Scopus: {s25['active']:.1f}%"),
                (f"{rk['all']} &rarr; {rk['q1']}", "Indonesia&rsquo;s world rank, six topics, all journals against Q1", f"non-discontinued Scopus: {rk['active']}"),
                (f"{rkT['all']} &rarr; {rkT['q1']}", "rank in sustainable finance and green bonds proper", f"non-discontinued Scopus: {rkT['active']}")], "cards three")
    body = tier_legend() + two(c1, c2) + cs
    return panel(P3, "Figure 11 &middot; Indonesia is a large producer in all journals and a small one in Q1", "", body,
                 "Works with a sustainable primary topic and at least one Indonesian author, divided by the world total of the same filter and year. 2026 omitted.")


def s_countries():
    CN = {"CN": "China", "US": "United States", "GB": "United Kingdom", "ID": "Indonesia", "IN": "India", "DE": "Germany", "AU": "Australia", "IT": "Italy", "FR": "France", "ES": "Spain", "NL": "Netherlands", "BR": "Brazil",
          "RU": "Russia", "CA": "Canada", "UA": "Ukraine", "PK": "Pakistan", "MY": "Malaysia", "TR": "Turkey", "SE": "Sweden", "CH": "Switzerland", "KR": "South Korea", "JP": "Japan", "ZA": "South Africa", "PL": "Poland",
          "VN": "Vietnam", "SA": "Saudi Arabia", "NG": "Nigeria", "PT": "Portugal", "GR": "Greece", "NO": "Norway", "DK": "Denmark", "FI": "Finland", "BE": "Belgium", "AT": "Austria", "IE": "Ireland", "NZ": "New Zealand",
          "TW": "Taiwan", "HK": "Hong Kong", "SG": "Singapore", "TH": "Thailand", "PH": "Philippines", "MX": "Mexico", "CL": "Chile", "AE": "UAE", "IR": "Iran", "EG": "Egypt", "BD": "Bangladesh", "GH": "Ghana", "KE": "Kenya", "CO": "Colombia"}
    def col(t, key):
        L = DT[key][t][:10]; return [f"{'<b style=\"color:var(--c8)\">' if c == 'ID' else ''}{CN.get(c, c)} {n(v)}{'</b>' if c == 'ID' else ''}" for c, v in L]
    cols = {t: col(t, "countries") for t in TIERS}
    rows = [[str(i + 1)] + [cols[t][i] if i < len(cols[t]) else "" for t in TIERS] for i in range(10)]
    t1 = table(["Rank, six topics"] + [TN[t] for t in TIERS], rows, cls="dtable meals tiers rank")
    colsT = {t: col(t, "countries_T13146") for t in TIERS}
    rowsT = [[str(i + 1)] + [colsT[t][i] if i < len(colsT[t]) else "" for t in TIERS] for i in range(8)]
    t2 = table(["Rank, sustainable finance and green bonds"] + [TN[t] for t in TIERS], rowsT, cls="dtable meals tiers rank")
    return panel(P3, "Figure 12 &middot; The country ranking changes with the filter", "", t1 + t2, "OpenAlex authorships.countries; a paper counts once per country; works 2016-2026 with the stated primary topic, by journal tier.")


def s_id_venues():
    groups = ["World", "ASEAN-6", "Indonesia", "Indonesia, excl. CSR"]
    keys = ["S", "S_ASEAN", "S_ID", "S_ID_noCSR"]
    series = [{"name": {"scopus": "Scopus, all listed", "active": "Scopus, excl. discontinued", "q1": "Scopus Q1"}[t], "values": [round(pct(FUN[k].get(t, 0), FUN[k]["all"]), 1) for k in keys], "color": TC[t]} for t in ["scopus", "active", "q1"]]
    ch = gvbars(groups, series, 0, 100, [0, 25, 50, 75, 100], "Share of the papers in all journals that each Scopus filter keeps, %", w=660, h=420, left=60, bottom=60, valfmt=lambda v: f"{v:.0f}")
    rows = [[f"<b>{v[0][:46]}</b>", (v[1] or "")[:26], n(v[2])] for v in DT["id_venues"]["q1"][:9]]
    t = table(["Indonesia&rsquo;s largest Q1 venues, six topics", "Publisher", "Papers"], rows, cls="dtable meals venues")
    w_, i_ = pct(FUN["S"].get("active", 0), FUN["S"]["all"]), pct(FUN["S_ID"].get("active", 0), FUN["S_ID"]["all"])
    body = two(ch, t) + tiles([("The gap", f"A non-discontinued Scopus journal holds {w_:.0f}% of the world&rsquo;s papers on these themes and {i_:.0f}% of Indonesia&rsquo;s. Remove CSR reporting and Indonesia rises to {pct(FUN['S_ID_noCSR'].get('active', 0), FUN['S_ID_noCSR']['all']):.0f}%.", "bad"),
                               ("Indonesia&rsquo;s Q1 papers", "They appear in the same international journals as other countries. No Indonesian journal is in the list.", ""),
                               ("Meaning for JDSE", "Indonesian authors exist and publish a lot. They lack an indexed journal close to home. JDSE can serve them if it keeps quality high.", "note")], "ogrid stella3")
    return panel(P3, "Figure 13 &middot; Most of Indonesia&rsquo;s papers on these themes are outside Scopus", "", body,
                 "Per-work data, works 2016-2026 with a sustainable primary topic; the base (100%) is papers in all OpenAlex journals for each group.")


def s_id_inst():
    a = DT["id_inst"]["all"][:12]; q = DT["id_inst"]["q1"][:12]
    h1 = hbars([(short(nm), c, "var(--baseline)", False) for nm, c in a], 0, max(c for _, c in a) * 1.15, [0, 200, 400, 600], "Indonesian institutions, papers in all journals", w=580, rowh=30, left=270, right=60, valfmt=lambda v: n(int(v)))
    h2 = hbars([(short(nm), c, "var(--c8)", False) for nm, c in q], 0, max(c for _, c in q) * 1.15, [0, 20, 40, 60, 80], "Indonesian institutions, papers in Scopus Q1 journals", w=580, rowh=30, left=270, right=60, valfmt=lambda v: n(int(v)))
    body = two(h1, h2) + '<p class="reveal">By volume, the leaders are large private and regional universities. Most of their papers are CSR disclosure studies. In Q1, the leaders are the research universities. JDSE needs both groups: the first for submissions, the second for quality.</p>'
    return panel(P3, "Figure 14 &middot; In Indonesia, the top institutions by volume differ from the top institutions in Q1", "", body, "OpenAlex institutions for works with an Indonesian author, 2016-2026, Indonesian institutions only, by journal filter. A paper counts once per institution.")


def ordn(k):
    return f"{k}{'th' if 10 <= k % 100 <= 20 else {1: 'st', 2: 'nd', 3: 'rd'}.get(k % 10, 'th')}"


def s_implications():
    rk = DT["country_rank_ID"]
    t = tiles([("1 &middot; Focus on digital &times; sustainable finance", f"{n(FUN['inter']['all'])} papers in all journals, {n(FUN['inter']['q1'])} in Q1. The fastest growth under every filter (Figures 1 and 3). No specialist journal yet. Put it in the title, the aims and the first call.", ""),
               ("2 &middot; Cover the themes that grow fast and are cited", "ESG performance and ratings, green finance and green bonds, climate and transition risk, greenwashing (Figures 2, 15 and 18). Avoid themes one country dominates, such as state-owned enterprises (Figure 20). First special issue: ESG ratings and climate risk, the youngest cluster (Figure 17).", ""),
               ("3 &middot; Serve emerging-market authors", f"Indonesia is {ordn(rk['all'])} in the world in all journals and {ordn(rk['q1'])} in Q1 (Figures 11 to 14). The authors exist. They lack a journal. Start with ASEAN-6, then India, Pakistan and Vietnam (Figure 8). Use calls and reviews to move Indonesian authors from disclosure topics to climate and finance topics (Figure 19).", ""),
               ("4 &middot; Free to publish, and indexed", "No fee for readers or authors. 28% of all papers are diamond, but only 2% of Q1 papers (Figures 9 and 10). Apply to DOAJ in year one. Apply to Scopus after two years of regular issues (Figure 7).", "bad"),
               ("5 &middot; Require data and code; publish policy briefs", "Every empirical paper shares its data and code. Each paper has a two-page policy brief. Few journals in the field do this. BI has analysts who can support it.", ""),
               ("6 &middot; Track the journal&rsquo;s metrics from the start", "Citations, author countries, topics and index status, from OpenAlex, on a public page. Baseline: BMEB, h-index 33, two citations per paper in two years.", "note")], "ogrid stella3")
    return panel("Implications", "What the evidence implies for JDSE", "", t, "Each card points to the figure that supports it.")


def s_sources():
    body = ('<p class="srcs">OpenAlex works, topics, keywords, sources and institutions, retrieved 14 October 2026: 248,756 works with a sustainable primary topic and 398,142 with a digital topic, 2010-2026, downloaded one by one so that every journal could be classified. '
            'Journal status from the official Scopus Source List, September 2026 (sources sheet and discontinued-titles sheet), matched by ISSN and EISSN; quartiles from SCImago Journal Rank 2025. '
            'Scopus Search API (Elsevier), 14 October 2026, phrase set in TITLE-ABS-KEY, for the cross-check. '
            'Method follows the Indonesian research-quality study (anshory1972.github.io/dataslide/researchquality.html): classification by assigned topic, not keyword matching; journal status by ISSN; repositories separated from journals; every result reported under four filters.</p>'
            '<p class="srcs">Limits. OpenAlex is a reliable census of the literature and less reliable on who wrote it; institution counts are indicative. Topic assignment is probabilistic. Keyword coverage is thinner before 2020, so early-period shares are lower bounds. 2026 is a partial year. A journal is matched to Scopus only if its ISSN is in the list, which undercounts by a few per cent. Figures 4 to 8 use the 200 largest venues of each group; Figures 1 to 3 and 9 to 13 use every paper.</p>')
    return panel("Sources", "Sources and limits", "", body, "")


SLIDES = [(s_cover, "Cover"), (s_frame, "Three questions"),
          (divider("Part I", "Which topics are growing?", "Growth, themes, and papers that combine digital and sustainable finance", "div1", "A tree with a river-delta canopy, its newest tips lit"), "Part I"),
          (s_method1, "Method"), (s_tiers, "Four filters"), (s_growth, "Fig 1 growth"), (s_themes, "Fig 2 themes"), (s_intersection, "Fig 3 intersection"), (s_topcited, "Fig 4 top cited"),
          (divider("Part II", "Which journals publish this research?", "Main journals, their fees, how fast new journals entered Scopus, and BI&rsquo;s current journal", "div2", "A row of gates, one small new gate open"), "Part II"),
          (s_venues_all, "Fig 5 venues"), (s_venues_core, "Fig 6 core venues"), (s_launched, "Fig 7 launches"), (s_benchmarks, "Fig 8 benchmarks"), (s_oa, "Fig 9 open access"),
          (divider("Part III", "How much does Indonesia publish, and where?", "Volume, topics, journals, and how much is in Scopus", "div3", "An archipelago with paper boats sailing to a continent"), "Part III"),
          (s_id_share, "Fig 11 share"), (s_countries, "Fig 12 countries"), (s_id_venues, "Fig 13 Indonesian venues"), (s_id_inst, "Fig 14 institutions"),
          (s_implications, "Implications"), (s_sources, "Sources"),
          (divider("", "Thank you", "Arief Anshory Yusuf &middot; Universitas Padjadjaran", "thanks", "A figure placing the first volume on an empty shelf"), "Thank you")]


# ------------------------------------------------------------------ Part IV: six standard theme analyses
TH = json.load(open("../data/deck_data_themes.json", encoding="utf-8"))
P4 = "Part IV &middot; Themes for JDSE"


def scatter(points, x0, x1, y0, y1, xticks, yticks, xlab, ylab, title, w=580, h=470, left=60, right=20, top=40, bottom=56, xref=None, yref=None, logx=False, xfmt=lambda v: f"{v:g}", yfmt=lambda v: f"{v:g}", qlabels=None):
    """points: dict(x, y, r, label, color, show)."""
    fx = (lambda v: math.log10(v)) if logx else (lambda v: v)
    X = lambda v: left + (fx(min(max(v, x0), x1)) - fx(x0)) / (fx(x1) - fx(x0)) * (w - left - right)
    Y = lambda v: top + (y1 - min(max(v, y0), y1)) / (y1 - y0) * (h - top - bottom)
    s = [f'<svg class="ds-chart sc" viewBox="0 0 {w} {h}" role="img" aria-label="{esc(title)}">', f'<text x="10" y="20" class="ph">{title}</text>']
    for t in xticks: s.append(f'<line x1="{X(t):.1f}" y1="{top}" x2="{X(t):.1f}" y2="{h-bottom}" class="g"/><text x="{X(t):.1f}" y="{h-bottom+22}" class="ax mid">{xfmt(t)}</text>')
    for t in yticks: s.append(f'<line x1="{left}" y1="{Y(t):.1f}" x2="{w-right}" y2="{Y(t):.1f}" class="g"/><text x="{left-8}" y="{Y(t)+4:.1f}" class="ax end">{yfmt(t)}</text>')
    if xref is not None: s.append(f'<line x1="{X(xref):.1f}" y1="{top}" x2="{X(xref):.1f}" y2="{h-bottom}" stroke="var(--text-secondary)" stroke-width="1.2" stroke-dasharray="5 4"/>')
    if yref is not None: s.append(f'<line x1="{left}" y1="{Y(yref):.1f}" x2="{w-right}" y2="{Y(yref):.1f}" stroke="var(--text-secondary)" stroke-width="1.2" stroke-dasharray="5 4"/>')
    if qlabels:
        for (qx, qy, anc, txt) in qlabels: s.append(f'<text x="{X(qx):.1f}" y="{Y(qy):.1f}" class="ax {anc}" font-style="italic" fill="var(--muted)">{txt}</text>')
    for p in sorted(points, key=lambda p: -p["r"]):
        s.append(f'<circle cx="{X(p["x"]):.1f}" cy="{Y(p["y"]):.1f}" r="{p["r"]:.1f}" fill="{p["color"]}" fill-opacity="0.55" stroke="{p["color"]}" stroke-width="1"/>')
    placed = []
    if qlabels:
        for (qx, qy, anc, txt) in qlabels:
            qw = 6.8 * len(txt); qx0 = X(qx) - (qw if anc == "end" else 0)
            placed.append((qx0, Y(qy) - 11, qx0 + qw, Y(qy) + 3))
    circles = [(X(q["x"]), Y(q["y"]), q["r"]) for q in points]
    def hits_circle(bx):
        n_ = 0
        for (ccx, ccy, rr) in circles:
            nx, ny = min(max(ccx, bx[0]), bx[2]), min(max(ccy, bx[1]), bx[3])
            if (nx - ccx) ** 2 + (ny - ccy) ** 2 < rr * rr: n_ += 1
        return n_
    inside = lambda bx: bx[0] >= left and bx[2] <= w - right and bx[1] >= top - 4 and bx[3] <= h - bottom
    clear = lambda bx: all(bx[2] < b[0] or bx[0] > b[2] or bx[3] < b[1] or bx[1] > b[3] for b in placed)
    lines, texts = [], []
    for p in sorted([q for q in points if q.get("show")], key=lambda q: -q["r"]):
        wlab = 7.0 * len(p["label"]); cx, cy, r = X(p["x"]), Y(p["y"]), p["r"]
        best = None
        for dy in (0, -16, 16, -32, 32, -48, 48, -64, 64):
            for side in (1, -1):
                lx = cx + r + 4 if side == 1 else cx - r - 4 - wlab
                ly = cy + 4 + dy; bx = (lx, ly - 11, lx + wlab, ly + 3)
                if not inside(bx) or not clear(bx): continue
                score = abs(dy) + 25 * hits_circle(bx)
                if best is None or score < best[0]: best = (score, lx, ly, dy, side)
        if best is None:
            lx = cx + r + 4 if cx + r + 4 + wlab <= w - right else cx - r - 4 - wlab; ly = cy + 4; dy = 0; side = 1 if lx > cx else -1
        else:
            _, lx, ly, dy, side = best
        placed.append((lx, ly - 11, lx + wlab, ly + 3))
        if abs(dy) >= 16:
            ex = lx if side == 1 else lx + wlab
            lines.append(f'<line x1="{cx:.1f}" y1="{cy:.1f}" x2="{ex:.1f}" y2="{ly - 4:.1f}" stroke="var(--text-secondary)" stroke-width="0.8"/>')
        texts.append(f'<text x="{lx:.1f}" y="{ly:.1f}" class="ax" font-size="11.5" font-weight="600" fill="var(--text-primary)" stroke="var(--surface-1)" stroke-width="3" stroke-linejoin="round" paint-order="stroke">{p["label"]}</text>')
    s += lines + texts
    s.append(f'<text x="{(left+w-right)/2:.1f}" y="{h-12}" class="ax mid" font-weight="700">{xlab}</text>')
    s.append(f'<text x="14" y="{(top+h-bottom)/2:.1f}" class="ax mid" font-weight="700" transform="rotate(-90 14 {(top+h-bottom)/2:.1f})">{ylab}</text>')
    s.append("</svg>"); return chr(10).join(s)


def s_method_themes():
    t = tiles([("1 &middot; Growth &times; impact", "Each keyword: compound growth of papers 2020 to 2025, and field-normalised citation score (citations divided by the average of papers of the same year in the same filter, papers 2018-2023). Rotolo, Hicks and Martin 2015; Small, Boyack and Klavans 2014.", ""),
               ("2 &middot; Q1 share per theme", "Share of a keyword&rsquo;s papers in all journals that appear in Scopus Q1 (not discontinued), 2016-2026. Tells which themes good authors already send to the best journals.", ""),
               ("3 &middot; Co-word strategic diagram", "Keyword co-occurrence 2021-2026, equivalence index, Louvain clusters. Each cluster placed by centrality (links to other themes) and density (internal cohesion). Callon et al. 1991; SciMAT, bibliometrix.", ""),
               ("4 &middot; Burst detection", "Kleinberg (2003) two-state model on each keyword&rsquo;s yearly share of papers, 2010-2025. A burst is a period when the share jumps above its long-run rate. As in CiteSpace.", ""),
               ("5 &middot; Indonesia&rsquo;s activity index", "Indonesia&rsquo;s share of a theme divided by its share of the whole field, 2016-2026, against how much the theme is cited worldwide. Activity index, revealed comparative advantage.", ""),
               ("6 &middot; Geographic concentration", "For each theme: number of countries, the leading country&rsquo;s share of papers, China&rsquo;s and ASEAN-6&rsquo;s shares, 2016-2026. A theme led by one country is closed; a dispersed one is open to new entrants.", "note")], "ogrid stella3")
    return panel(P4, "Method: six standard tests of where a field is promising", "", t,
                 f"Keyword level: {TH['vocab_n']} OpenAlex keywords with at least 300 papers 2019-2026 in the six sustainable topics; country names, firm-level control variables and theory labels removed. Each test computed for all journals and for Scopus Q1 (not discontinued).")


GI_LABELS = {"all": {"ESG performance", "ESG ratings", "ESG disclosure", "green finance", "green bonds", "green economy", "environmental accounting", "sustainability reporting", "corporate social responsibility", "climate policy", "carbon pricing", "emerging markets", "sustainable finance"},
             "q1": {"ESG performance", "ESG ratings", "ESG disclosure", "green innovation", "financial constraints", "green finance", "state-owned enterprises", "climate policy", "carbon pricing", "energy transition", "emissions trading", "climate risk", "corporate governance"}}


def gi_points(L, min_recent, label_n=16):
    rows = [r for r in TH["growth_impact"][L] if r["ncs"] is not None and r["recent"] >= min_recent]
    topset = GI_LABELS[L]
    mx = max(r["recent"] for r in rows)
    pts = []
    for r in rows:
        hot = (r["cagr"] > TH["field_cagr"][L]) and r["ncs"] > 1
        pts.append({"x": 100 * r["cagr"], "y": r["ncs"], "r": 3 + 15 * math.sqrt(r["recent"] / mx), "label": r["kw"], "color": "var(--c8)" if hot else "var(--c9)", "show": r["kw"] in topset})
    return pts


def s_growth_impact():
    fa, fq = 100 * TH["field_cagr"]["all"], 100 * TH["field_cagr"]["q1"]
    ql = lambda fc: [(105, 2.9, "end", "fast and cited"), (-8, 2.9, "", "slow but cited"), (105, 0.12, "end", "fast but little cited"), (-8, 0.12, "", "slow, little cited")]
    a = scatter(gi_points("all", 300), -10, 110, 0, 3, [0, 25, 50, 75, 100], [0, 1, 2, 3], "Growth of papers a year, 2020&ndash;2025, %", "Citation score (field = 1)", "All OpenAlex journals", xref=fa, yref=1, xfmt=lambda v: f"{v:g}%", qlabels=ql(fa))
    b = scatter(gi_points("q1", 150), -10, 110, 0, 3, [0, 25, 50, 75, 100], [0, 1, 2, 3], "Growth of papers a year, 2020&ndash;2025, %", "Citation score (Q1 = 1)", "Scopus Q1, not discontinued", xref=fq, yref=1, xfmt=lambda v: f"{v:g}%", qlabels=ql(fq))
    body = two(a, b) + tiles([("Fast and cited, under both filters", "ESG performance (100% a year, score 3.1), ESG ratings and disclosure, green finance, green bonds, corporate governance; in Q1 also green innovation, financial constraints and state-owned enterprises. Firm- and market-level questions with a measurable outcome.", "bad"),
                              ("Cited but slow", "Climate mitigation and adaptation, carbon pricing, the Paris Agreement, energy transition: large and cited in all journals, but growing slower than the field. In Q1 they are at or below the Q1 average.", ""),
                              ("Fast but little cited", "Sustainability reporting, the bare labels &ldquo;sustainable finance&rdquo; and &ldquo;ESG&rdquo;, green economy (score 0.4), environmental accounting (0.4), green transition. Many papers, few citations. A journal that accepts these papers easily will get many weak submissions.", "note")], "ogrid stella3")
    return panel(P4, "Figure 15 &middot; Growth and citations: ESG and green-finance themes at firm and market level grow fast and are well cited", "", body,
                 f"Each bubble a keyword; size = papers 2023-2025. Growth = compound annual growth of papers 2020 to 2025. Citation score = mean of citations divided by the same-year average of the filter, papers 2018-2023. Dashed lines: field growth ({fa:.0f}% a year in all journals, {fq:.0f}% in Q1) and score 1. Red = above both.")


def s_q1share():
    rows = sorted(TH["q1share"][:26], key=lambda r: -r["share_q1"])
    f = 100 * TH["q1share_field"]
    items = [(r["kw"], round(100 * r["share_q1"], 1), "var(--c8)" if 100 * r["share_q1"] > f else "var(--baseline)", 100 * r["share_q1"] > f) for r in rows]
    hb = hbars(items, 0, 60, [0, 10, 20, 30, 40, 50, 60], "Share of the theme&rsquo;s papers (all journals, 2016-2026) published in Scopus Q1, not discontinued, %", w=1180, rowh=21, left=330, right=70, valfmt=lambda v: f"{v:.0f}%", ref=f, reflab=f"field {f:.0f}%")
    body = hb + '<p class="reveal">Climate, energy-transition and carbon-pricing papers reach Q1 more often than average. CSR, disclosure and green-economy papers reach Q1 less often. To attract Q1-level authors, JDSE must compete in the first group. In the second group it must be selective.</p>'
    return panel(P4, "Figure 16 &middot; Share of each theme&rsquo;s papers in Q1 journals", "", body, "26 largest themes by papers in all journals, 2016-2026. Red = above the field&rsquo;s Q1 share.")


def strat(L, title):
    cl = TH["coword"][L]
    xs = sorted(c["centrality"] for c in cl); ys = sorted(c["density"] for c in cl)
    mx, my = xs[len(xs) // 2], ys[len(ys) // 2]
    big = max(c["papers"] for c in cl)
    cl = sorted(cl, key=lambda c: -c["papers"])
    pts = [{"x": c["centrality"], "y": c["density"], "r": 6 + 22 * math.sqrt(c["papers"] / big), "label": str(i + 1), "color": "var(--c8)" if (c["growth"] or 0) >= 2 else "var(--c9)", "show": True} for i, c in enumerate(cl)]
    x1 = max(xs) * 1.25; y1 = max(ys) * 1.2
    return scatter(pts, 0, x1, 0, y1, [round(x1 * i / 4, 1) for i in range(5)], [round(y1 * i / 4, 1) for i in range(5)], "Centrality (links to other themes)", "Density (internal cohesion)", title, w=580, h=470, xref=mx, yref=my,
                   xfmt=lambda v: f"{v:.0f}", yfmt=lambda v: f"{v:.0f}", qlabels=[(x1 * 0.98, y1 * 0.97, "end", "motor themes"), (0.02 * x1, y1 * 0.97, "", "niche"), (0.02 * x1, y1 * 0.04, "", "emerging or declining"), (x1 * 0.98, y1 * 0.04, "end", "basic, transversal")])


def cl_table(L):
    cl = sorted(TH["coword"][L], key=lambda c: -c["papers"])
    rows = [[f"<b>{i+1}</b>", ", ".join(c["members"][:4]), n(c["papers"]), f"{c['growth']:.1f}&times;" if c["growth"] else ""] for i, c in enumerate(cl)]
    return table(["#", "Cluster: largest keywords", "Papers", "Growth"], rows, cls="dtable meals bursts")


FORMULAS = (
    '<div class="fx">'
    '<div><p class="fxh">Link strength between keywords <i>i</i> and <i>j</i> (equivalence index)</p>'
    '<math display="block"><msub><mi>e</mi><mrow><mi>i</mi><mi>j</mi></mrow></msub><mo>=</mo>'
    '<mfrac><msubsup><mi>c</mi><mrow><mi>i</mi><mi>j</mi></mrow><mn>2</mn></msubsup><mrow><msub><mi>c</mi><mi>i</mi></msub><mo>&#x2062;</mo><msub><mi>c</mi><mi>j</mi></msub></mrow></mfrac></math>'
    '<p class="fxn"><i>c<sub>i</sub></i>, <i>c<sub>j</sub></i> = papers with each keyword; <i>c<sub>ij</sub></i> = papers with both. Callon et al. (1983)</p></div>'
    '<div><p class="fxh">Density of theme <i>s</i>: strength inside the theme</p>'
    '<math display="block"><msub><mi>D</mi><mi>s</mi></msub><mo>=</mo><mn>100</mn><mo>&#xD7;</mo>'
    '<mfrac><mrow><munder><mo>&#x2211;</mo><mrow><mi>i</mi><mo>,</mo><mi>j</mi><mo>&#x2208;</mo><mi>s</mi></mrow></munder><msub><mi>e</mi><mrow><mi>i</mi><mi>j</mi></mrow></msub></mrow><msub><mi>n</mi><mi>s</mi></msub></mfrac></math>'
    '<p class="fxn">Sum over pairs of keywords inside <i>s</i>; <i>n<sub>s</sub></i> = keywords in <i>s</i>. Callon et al. (1991)</p></div>'
    '<div><p class="fxh">Centrality of theme <i>s</i>: strength to other themes</p>'
    '<math display="block"><msub><mi>C</mi><mi>s</mi></msub><mo>=</mo><mn>10</mn><mo>&#xD7;</mo>'
    '<munder><mo>&#x2211;</mo><mrow><mi>i</mi><mo>&#x2208;</mo><mi>s</mi><mo>,</mo><mspace width="0.2em"/><mi>h</mi><mo>&#x2209;</mo><mi>s</mi></mrow></munder><msub><mi>e</mi><mrow><mi>i</mi><mi>h</mi></mrow></msub></math>'
    '<p class="fxn">Sum over links from a keyword in <i>s</i> to a keyword outside <i>s</i>. Callon et al. (1991)</p></div>'
    '</div>'
    '<p class="fxq">Quadrants (Cobo et al. 2011): high <i>C</i> and high <i>D</i> = motor themes; low <i>C</i>, high <i>D</i> = highly developed and isolated (niche); '
    'low <i>C</i>, low <i>D</i> = emerging or declining; high <i>C</i>, low <i>D</i> = basic and transversal. Lines at the medians.</p>')


def s_coword():
    body = two(strat("all", "All OpenAlex journals, 2021-2026"), strat("q1", "Scopus Q1, not discontinued, 2021-2026"))
    body += FORMULAS + two(cl_table("all"), cl_table("q1"))
    body += "" if True else tiles([("Motor themes in Q1", "The firm-finance cluster (state-owned enterprises, financial constraints, green innovation) and carbon pricing and emissions trading: central and cohesive. These are the field&rsquo;s engines.", "bad"),
                   ("Basic and transversal", "CSR and sustainability reporting, green finance and the SDGs: central but loose. Everyone touches them; nobody owns them.", ""),
                   ("Small and young", "ESG ratings, climate risk and sustainable investment form their own Q1 cluster: small, loosely tied, growing fastest. The place for a new journal&rsquo;s first special issue.", "note")], "ogrid stella3")
    return panel(P4, "Figure 17 &middot; Keyword map: main themes, general themes, and a new group on ESG ratings and climate risk", "", body,
                 "Top 90 keywords 2021-2026 in each filter; links = co-occurrence (equivalence index, at least 5 papers); Louvain clusters (resolution 1.6). Centrality = sum of a cluster&rsquo;s links to other clusters; density = internal links per keyword. Bubble size = papers; red = papers doubled between 2021-23 and 2024-26 (growth column). Quadrants split at the medians. Motor themes in Q1: the firm-finance cluster (state-owned enterprises, financial constraints, green innovation), carbon pricing and emissions trading. Young and small: ESG ratings, climate risk, sustainable investment.")


def s_bursts():
    def rows(L, k=12):
        B = [b for b in TH["bursts"][L] if b["start"] >= 2018][:k]
        mx = max(b["strength"] for b in B)
        return [[f"<b>{b['kw']}</b>", f"{b['start']}&ndash;{b['end']}{' &rarr;' if b['ongoing'] else ''}", f"<span class='bar' style='width:{int(100*b['strength']/mx)}px'></span>"] for b in B]
    t1 = table(["All OpenAlex journals", "Burst", "Strength"], rows("all"), cls="dtable meals bursts")
    t2 = table(["Scopus Q1, not discontinued", "Burst", "Strength"], rows("q1"), cls="dtable meals bursts")
    body = two(t1, t2) + '<p class="reveal">All strong rises are recent and still continuing. Both filters show the same keywords: ESG performance, ratings and disclosure, green finance, financial constraints, green innovation, greenwashing and corporate governance. In Q1, carbon neutrality and state-owned enterprises also appear. Both come mostly from Chinese studies.</p>'
    return panel(P4, "Figure 18 &middot; Keywords with a sudden rise in the last three years", "", body,
                 "Kleinberg (2003) two-state burst model on each keyword&rsquo;s yearly share of the filter, 2010-2025, s = 2, &gamma; = 1. Bursts starting 2018 or later; &rarr; = still running in 2025. Strength = log-likelihood gain of the burst state, scaled to the strongest burst in each filter.")


def s_activity():
    rows = [r for r in TH["activity"]["all"] if r["id_n"] >= 60 and r["world_ncs"] is not None]
    label = {"independent commissioners", "carbon emission disclosure", "environmental accounting", "sustainability reporting", "corporate governance", "ESG disclosure", "greenwashing", "climate policy", "climate change adaptation", "carbon pricing", "green bonds", "ESG ratings", "energy transition"}
    mx = max(r["id_n"] for r in rows)
    pts = [{"x": r["ai"], "y": r["world_ncs"], "r": 3 + 15 * math.sqrt(r["id_n"] / mx), "label": r["kw"], "color": "var(--c8)" if r["ai"] >= 1 else "var(--c9)", "show": r["kw"] in label} for r in rows]
    sc = scatter(pts, 0.1, 12, 0, 2.6, [0.1, 0.3, 1, 3, 10], [0, 0.5, 1, 1.5, 2, 2.5], "Indonesia&rsquo;s activity index (log scale; 1 = average)", "World citation score of the theme", "Themes with at least 60 Indonesian papers, all journals, 2016-2026", w=1180, h=500, left=70, logx=True, xref=1, yref=1,
                 xfmt=lambda v: f"{v:g}", qlabels=[(11, 2.5, "end", "Indonesia strong, theme cited"), (0.11, 2.5, "", "Indonesia weak, theme cited"), (11, 0.08, "end", "Indonesia strong, theme little cited")])
    body = sc + tiles([("Where Indonesia specialises", "Disclosure and governance variables: independent commissioners, audit committees, carbon-emission disclosure, environmental accounting. Activity index 6 to 9. The world cites these themes at 0.3 to 0.6 of average. Half of Indonesia&rsquo;s keyword mentions are here.", "bad"),
                       ("Where it is absent", "Climate adaptation, mitigation and policy, carbon pricing, emissions trading, the Paris Agreement, energy transition, green bonds: activity index 0.2 to 0.5. The world cites these themes above average.", ""),
                       ("Within each theme", "Indonesia is also active in some well-cited themes: corporate governance, ESG disclosure, greenwashing. But its own papers are cited below the world in 95% of themes. The median gap is 0.6 of average. So the issue is quality within themes, not only the choice of themes.", "note")], "ogrid stella3")
    return panel(P4, "Figure 19 &middot; Indonesia: strong in disclosure topics, weak in climate topics, cited below the world average", "", body,
                 "Activity index = (Indonesian papers in the theme / all Indonesian papers) / (world papers in the theme / all papers), 2016-2026, all journals. World citation score as in Figure 15. Under the Scopus filters Indonesia has too few papers per theme for a stable index.")


def s_geography():
    G = {r["kw"]: r for r in TH["geography"]["q1"]}; GA = {r["kw"]: r for r in TH["geography"]["all"]}
    CNN = {"CN": "China", "US": "United States", "GB": "United Kingdom", "IT": "Italy", "ID": "Indonesia", "DE": "Germany", "AU": "Australia", "IN": "India", "ES": "Spain", "FR": "France", "NL": "Netherlands"}
    pick = [r for r in TH["geography"]["q1"]][:20]
    rows = []
    for r in sorted(pick, key=lambda r: r["leader_share"]):
        a = GA.get(r["kw"], {})
        lead = f"{CNN.get(r['leader'], r['leader'])} {100*r['leader_share']:.0f}%"
        style = "color:var(--c8);font-weight:700" if r["leader_share"] >= 0.5 else ("color:var(--c2);font-weight:700" if r["leader_share"] < 0.25 else "")
        rows.append([f"<b>{r['kw']}</b>", n(r["n"]), str(r["countries"]), f"<span style='{style}'>{lead}</span>", f"{100*r['asean']:.0f}%", f"{100*a.get('asean',0):.0f}%" if a else "", f"{100*r['id']:.1f}%"])
    t = table(["Theme (20 largest in Q1)", "Q1 papers", "Countries", "Leading country, Q1", "ASEAN-6 share, Q1", "ASEAN-6 share, all journals", "Indonesia, Q1"], rows, cls="dtable meals tiers geo")
    body = t + '<p class="reveal">Open themes (green, leading country under a quarter of Q1 papers): energy transition, sustainability reporting and transitions, the SDGs, the Paris Agreement, climate mitigation, greenhouse gases. Closed themes (red): green finance, emissions trading, ESG performance, state-owned enterprises, financial constraints. In these, China writes more than half of Q1 papers. ASEAN-6 authors write 3&ndash;11% of Q1 papers in every theme. Indonesia writes under 4%.</p>'
    return panel(P4, "Figure 20 &middot; Which countries write each theme", "", body,
                 "Papers 2016-2026 with the keyword; a paper counts once per country. Leading country share = share of the theme&rsquo;s papers with an author from that country. Sorted from most open to most concentrated.")


_si = [i for i, (f, lab) in enumerate(SLIDES) if lab == "Implications"][0]
SLIDES[_si:_si] = [(divider("Part IV", "Which themes should JDSE cover?", "Six standard tests: growth and citations, Q1 share, keyword map, sudden rises, Indonesia&rsquo;s strengths, and countries", "div4", "A compass on a map of small islands"), "Part IV"),
                   (s_method_themes, "Method IV"), (s_growth_impact, "Fig 15 growth x impact"), (s_q1share, "Fig 16 Q1 share"), (s_coword, "Fig 17 co-word"), (s_bursts, "Fig 18 bursts"), (s_activity, "Fig 19 activity"), (s_geography, "Fig 20 geography")]


# ------------------------------------------------------------------ context, objectives, data and method, references; final slide order
PM = "Data and method"
SCOPUS_Q = ('TITLE-ABS-KEY("sustainable finance" OR "green finance" OR "green bond*" OR "climate finance" OR "ESG investing" OR "ESG performance" OR "ESG disclosure" OR "ESG rating*" '
            'OR "sustainable banking" OR "transition risk" OR "carbon pricing" OR "green credit") AND PUBYEAR = &lt;year&gt; AND DOCTYPE(ar OR re)')


def s_context():
    t = tiles([("The initiative", "Bank Indonesia Institute (BINS) is designing a new journal: the Journal of Digital and Sustainable Economy and Finance (JDSE). This workshop drafts its concept.", ""),
               ("What the TOR asks for", "Aims and scope; positioning; frequency; priority themes; target authors and readers; editorial policy (double-blind review, open access, COPE ethics, APC); editorial structure; author guidelines; a roadmap from ISSN to SINTA, DOAJ and Garuda, with Scopus, WoS-SSCI and ABDC in the long run.", ""),
               ("This session&rsquo;s brief", "Session 3: research trends, strategic issues and publication opportunities in sustainable economy and finance, as a basis for the journal. Session 2 covers the digital side.", ""),
               ("Why bibliometrics", "A new journal must choose its topics and its authors. Published papers show which topics grow, which are cited, which journals publish them, and where the authors are.", "note")], "ogrid stella")
    return panel("Context", "Context: a new Bank Indonesia journal", "", t, "Terms of reference, Konsinyering Penyusunan Rancangan Konsep JDSE, Bandung, 15 October 2026; BINS invitation letter.")


def s_objectives():
    rows = [["<b>1. Which topics are growing?</b>", "Growth by topic and journal filter. Themes that rose and fell. Digital &times; sustainable papers. Most cited papers.", "Fokus tematik, bidang kajian prioritas"],
            ["<b>2. Which journals publish this research?</b>", "Main journals: index status, fees, citations. Time for new journals to enter Scopus. Central-bank journals. Open access.", "Positioning; kebijakan APC; target indeksasi"],
            ["<b>3. How much does Indonesia publish, and where?</b>", "Indonesia&rsquo;s share, rank, journals, institutions and topics, under four journal filters", "Target segmen penulis dan pembaca"],
            ["<b>4. Which themes should JDSE cover?</b>", "Six standard tests: growth and citations, Q1 share, keyword map, sudden rises, Indonesia&rsquo;s activity index, countries", "Aims and scope; call for papers; special issues"]]
    t = table(["Objective", "What is measured", "TOR output it informs"], rows, cls="dtable wide reco")
    return panel("Objectives", "Four questions, each tied to an output the TOR asks for", "", t, "TOR section IV, Keluaran yang diharapkan.")


def s_data_sources():
    rows = [["<b>OpenAlex</b> (OurResearch)", "Works, topics, keywords, journals, institutions, open-access status, citations", "API, 14 October 2026", "248,756 + 398,142 works; 49,446 sources", "Main corpus. Open, covers all journals including non-Scopus Indonesian ones"],
            ["<b>Scopus Source List</b> (Elsevier)", "Every source indexed in Scopus: ISSN, EISSN, active or inactive, discontinued flag; separate discontinued-titles sheet", "September 2026 release", "49,104 sources; 1,816 discontinued ISSNs", "Decides whether a journal is in Scopus"],
            ["<b>SCImago Journal Rank</b>", "Quartile (Q1 to Q4) of every Scopus journal, by subject category", "2025 edition", "~29,000 journals", "Decides Q1"],
            ["<b>Scopus Search API</b> (Elsevier)", "Paper counts for a keyword query, world, Indonesia, ASEAN-6", "API, 14 October 2026", "17 years &times; 3 queries", "Cross-check of growth"],
            ["<b>OpenAlex sources</b>", "h-index, two-year mean citedness, APC, publisher, first year", "API, 14 October 2026", "per journal", "Journal benchmarks (Figures 5 to 8)"]]
    t = table(["Source", "What it provides", "Version", "Size", "Role"], rows, cls="dtable wide reco")
    return panel(PM, "Data sources", "", t, "OpenAlex: Priem, Piwowar and Orr (2022). Coverage comparisons: Visser, van Eck and Waltman (2021); Alperin et al. (2024). OpenAlex covers about 26% more titles than Scopus and nearly all active Scopus titles (own census, August 2026).")


def s_corpus():
    rows = [["T13146", "Sustainable finance and green bonds", "Finance", "56,138", "sustainable"], ["T10471", "Climate change policy and economics", "Economics and econometrics", "182,657", "sustainable"],
            ["T10119", "Sustainability and climate change governance", "Global and planetary change", "59,545", "sustainable"], ["T12013", "Sustainable development and environmental policy", "Management, monitoring, policy and law", "48,226", "sustainable"],
            ["T12883", "Sustainable development and environmental management", "Management, monitoring, policy and law", "120,870", "sustainable"], ["T10115", "Corporate social responsibility reporting", "Strategy and management", "210,402", "sustainable"],
            ["T11995", "FinTech, crowdfunding, digital finance", "Management information systems", "74,705", "digital"], ["T13346", "Digital transformation in financial services", "General economics and finance", "68,025", "digital"],
            ["T10987", "Microfinance and financial inclusion", "Economics and econometrics", "111,913", "digital"], ["T10270", "Blockchain technology applications", "Information systems", "168,283", "digital"],
            ["T12958", "Digital economy and transformation", "Strategy and management", "39,273", "digital"]]
    t = table(["Topic ID", "OpenAlex topic", "Subfield", "Works, all years", "Set"], rows, cls="dtable meals tiers topics")
    body = t + tiles([("Why topics, not keyword search", "OpenAlex assigns every work up to three topics from 4,516, using title, abstract, journal and citations. Keyword search mis-assigns at scale: in the earlier SDG study, a quarter of papers tagged &ldquo;innovation&rdquo; were education research. Topic assignment avoids that.", ""),
                      ("Corpus rules", "Sustainable corpus: primary topic in the six sustainable topics, 2010-2026, articles and reviews: 248,756 works. Digital corpus: any topic in the five digital topics: 398,142. Intersection: a work with one topic from each set. Keywords: OpenAlex&rsquo;s own keyword field on each work.", ""),
                      ("Keyword search, used once", f"Scopus cross-check only: <code>{SCOPUS_Q}</code>. Run per year, alone and with AFFILCOUNTRY(Indonesia) and the ASEAN-6.", "note")], "ogrid stella3")
    return panel(PM, "Corpus: eleven OpenAlex topics, and one Scopus keyword query as a cross-check", "", body,
                 "Topic counts from the OpenAlex topics endpoint, all years and document types. Corpus counts are articles and reviews 2010-2026. A first version of the Scopus query used the bare word ESG, which also matched medical abbreviations before 2015; the ESG phrases are spelled out instead.")


def s_metrics():
    rows = [["<b>Papers</b>", "Count of works per year, topic, journal or country", "a paper counts once per country and once per institution", "Figs 1, 3, 5-14"],
            ["<b>Growth multiple</b>", "papers in 2025 &divide; papers in 2015", "2026 is partial, so excluded", "Fig 1"],
            ["<b>CAGR</b>", "(papers 2025 &divide; papers 2020)<sup>1/5</sup> &minus; 1", "compound annual growth rate", "Fig 15"],
            ["<b>Acceleration</b>", "CAGR 2022-25 &minus; CAGR 2019-22", "positive = speeding up", "data only"],
            ["<b>Keyword share</b>", "papers with the keyword &divide; all papers in the topic, per period", "2015-18 against 2023-26", "Fig 2"],
            ["<b>Citation score</b>", "mean of (citations &divide; average citations of papers of the same year in the same filter)", "1 = average; papers 2018-2023 only; Waltman et al. (2011)", "Figs 16, 19"],
            ["<b>Top-10% share</b>", "share of papers in the top 10% most cited of their year and filter", "excellence indicator", "data only"],
            ["<b>h-index</b>", "largest h such that h papers have at least h citations each", "journal level, OpenAlex; Hirsch (2005)", "Figs 5-8"],
            ["<b>Two-year mean citedness</b>", "citations in a year to papers of the two previous years &divide; those papers", "close to the Impact Factor; OpenAlex", "Figs 5-8"],
            ["<b>Q1 share</b>", "papers in Scopus Q1, not discontinued &divide; papers in all journals", "journal-tier indicator", "Fig 16, filter table"],
            ["<b>Activity index</b>", "(Indonesia&rsquo;s papers in theme &divide; Indonesia&rsquo;s papers) &divide; (world papers in theme &divide; world papers)", "1 = average specialisation; Schubert and Braun (1986)", "Fig 19"],
            ["<b>Leading-country share</b>", "share of a theme&rsquo;s papers with an author from the top country", "concentration; also China, ASEAN-6, Indonesia shares", "Fig 20"],
            ["<b>OA status</b>", "OpenAlex: closed, hybrid, gold, green, bronze, diamond", "diamond = free to read and to publish", "Figs 9, 10"]]
    t = table(["Metric", "Definition", "Notes", "Used in"], rows, cls="dtable meals metrics")
    return panel("Appendix", "Metrics: what each number on the slides means", "", t, "All computed from the downloaded OpenAlex records except h-index and two-year citedness, which OpenAlex reports per journal.")


def s_methods():
    rows = [["<b>Four journal filters</b>", "Every journal matched by ISSN and EISSN to the Scopus Source List (Sep 2026) and SCImago 2025; each result reported for all journals, Scopus listed, Scopus excl. discontinued, Scopus Q1 excl. discontinued", "own design", "all figures"],
            ["<b>Emerging-topic test</b>", "Growth (CAGR) against field-normalised citation score per keyword; quadrants at field growth and score 1", "Rotolo, Hicks and Martin (2015); Small, Boyack and Klavans (2014)", "Fig 15"],
            ["<b>Topic prominence logic</b>", "Share of a theme in Q1 journals, as one of the three components of prominence", "Klavans and Boyack (2017)", "Fig 16"],
            ["<b>Co-word strategic diagram</b>", "Keyword co-occurrence; equivalence index e = c<sub>ij</sub>&sup2; &divide; (c<sub>i</sub> c<sub>j</sub>); Louvain clustering; Callon centrality and density; quadrants at medians", "Callon, Courtial and Laville (1991); Cobo et al. (2011); Blondel et al. (2008); Aria and Cuccurullo (2017)", "Fig 17"],
            ["<b>Burst detection</b>", "Two-state hidden Markov model on yearly keyword shares; burst rate = 2 &times; base rate; transition cost &gamma; = 1", "Kleinberg (2003); Chen (2006)", "Fig 18"],
            ["<b>Relative specialisation</b>", "Activity index against world citation score of the theme", "Schubert and Braun (1986)", "Fig 19"],
            ["<b>Geographic concentration</b>", "Number of countries, leading-country share, China and ASEAN-6 shares", "standard diffusion indicators", "Fig 20"],
            ["<b>Journal benchmarks</b>", "Venue lists by group; first year in OpenAlex against first year in Scopus coverage", "own design", "Figs 5-8"]]
    t = table(["Method", "What was done", "Reference", "Figure"], rows, cls="dtable meals metrics")
    return panel(PM, "Methods and parameters", "", t, "All code, data and a README are in the replication package (download link on the last slide). It reproduces every figure.")


def s_limits():
    t = tiles([("OpenAlex on authors", "Good for counting papers. Less good for author affiliations: some institution records merge similar names. Institution counts are approximate.", ""),
               ("Topics and keywords", "Topic assignment is a classifier, not a human judgement. Keyword coverage is thinner before 2020, so early shares are lower bounds and growth is overstated for new keywords.", ""),
               ("Scopus matching by ISSN", "A journal counts as Scopus only if an ISSN matches the September 2026 list. Title changes and missing ISSNs undercount Scopus by a few per cent.", ""),
               ("Citations", "Total citations to date, not by year. Recent papers have had less time; the citation score compares papers of the same year to correct for this. 2024-26 papers are excluded from it.", ""),
               ("Time", "2026 is a partial year and is never plotted as a full one. Growth is 2015-2025 or 2020-2025.", ""),
               ("Not done", "Reference age (novelty), citation velocity by year, newcomer authors, funding and policy citations. Each needs a second download.", "note")], "ogrid stella3")
    return panel("Part V &middot; What this means for JDSE", "Limits of the data and the method", "", t, "OpenAlex reliability: own institution check in the research-quality study (three of 25 largest Indonesian institution records conflated, excluded there).")


def s_references():
    refs = ["Alperin, J. P., Portenoy, J., Demes, K., Larivi&egrave;re, V. and Haustein, S. (2024). An analysis of the suitability of OpenAlex for bibliometric analyses. arXiv:2404.17663.",
            "Aria, M. and Cuccurullo, C. (2017). bibliometrix: An R-tool for comprehensive science mapping analysis. <i>Journal of Informetrics</i>, 11(4), 959&ndash;975.",
            "Blondel, V. D., Guillaume, J.-L., Lambiotte, R. and Lefebvre, E. (2008). Fast unfolding of communities in large networks. <i>Journal of Statistical Mechanics</i>, P10008.",
            "Callon, M., Courtial, J. P., Turner, W. A. and Bauin, S. (1983). From translations to problematic networks: An introduction to co-word analysis. <i>Social Science Information</i>, 22(2), 191&ndash;235.",
            "Callon, M., Courtial, J. P. and Laville, F. (1991). Co-word analysis as a tool for describing the network of interactions between basic and technological research: the case of polymer chemistry. <i>Scientometrics</i>, 22(1), 155&ndash;205.",
            "Chen, C. (2006). CiteSpace II: Detecting and visualizing emerging trends and transient patterns in scientific literature. <i>Journal of the American Society for Information Science and Technology</i>, 57(3), 359&ndash;377.",
            "Cobo, M. J., L&oacute;pez-Herrera, A. G., Herrera-Viedma, E. and Herrera, F. (2011). An approach for detecting, quantifying, and visualizing the evolution of a research field: a practical application to the Fuzzy Sets Theory field. <i>Journal of Informetrics</i>, 5(1), 146&ndash;166.",
            "Elsevier (2026). Scopus Source List, September 2026 (ext_list_Sep_2026.xlsx).",
            "Hirsch, J. E. (2005). An index to quantify an individual&rsquo;s scientific research output. <i>PNAS</i>, 102(46), 16569&ndash;16572.",
            "Klavans, R. and Boyack, K. W. (2017). Research portfolio analysis and topic prominence. <i>Journal of Informetrics</i>, 11(4), 1158&ndash;1174.",
            "Kleinberg, J. (2003). Bursty and hierarchical structure in streams. <i>Data Mining and Knowledge Discovery</i>, 7(4), 373&ndash;397.",
            "Priem, J., Piwowar, H. and Orr, R. (2022). OpenAlex: A fully-open index of scholarly works, authors, venues, institutions, and concepts. arXiv:2205.01833.",
            "Rotolo, D., Hicks, D. and Martin, B. R. (2015). What is an emerging technology? <i>Research Policy</i>, 44(10), 1827&ndash;1843.",
            "Schubert, A. and Braun, T. (1986). Relative indicators and relational charts for comparative assessment of publication output and citation impact. <i>Scientometrics</i>, 9(5&ndash;6), 281&ndash;291.",
            "SCImago (2025). SCImago Journal &amp; Country Rank. https://www.scimagojr.com.",
            "Small, H., Boyack, K. W. and Klavans, R. (2014). Identifying emerging topics in science and technology. <i>Research Policy</i>, 43(8), 1450&ndash;1467.",
            "Visser, M., van Eck, N. J. and Waltman, L. (2021). Large-scale comparison of bibliographic data sources: Scopus, Web of Science, Dimensions, Crossref, and Microsoft Academic. <i>Quantitative Science Studies</i>, 2(1), 20&ndash;41.",
            "Waltman, L., van Eck, N. J., van Leeuwen, T. N., Visser, M. S. and van Raan, A. F. J. (2011). Towards a new crown indicator: some theoretical considerations. <i>Journal of Informetrics</i>, 5(1), 37&ndash;47.",
            "Yusuf, A. A. (2026). What the quality filter reveals: Indonesian research by volume and by Q1. anshory1972.github.io/dataslide/researchquality.html."]
    body = '<ol class="refs">' + "".join(f"<li>{r}</li>" for r in refs) + "</ol>"
    return panel("References", "References", "", body, "")


REPL_LINK = ("<p class=\"aiack\"><b>Replication package.</b> <a href=\"jdse-sustainable-research-replication.zip\" download>Download the data, code and README (zip, 52 MB)</a>. "
             "It reproduces every figure and table.</p>")


SLIDES = [(s_cover, "Cover"),
          (divider("Background", "Context, aims and method", "Why this session, what it measures, and how", "div0", "A figure with a lamp reading a long paper map spread across a plain"), "Background"),
          (s_context, "Context"), (s_objectives, "Objectives"),
          (s_data_sources, "Data sources"), (s_corpus, "Corpus"), (s_tiers, "Four filters"), (s_methods, "Methods"),
          (divider("Part I", "Which topics are growing?", "Growth, themes, and papers that combine digital and sustainable finance", "div1", "A tree with a river-delta canopy, its newest tips lit"), "Part I"),
          (s_growth, "Fig 1 growth"), (s_themes, "Fig 2 themes"), (s_intersection, "Fig 3 intersection"),
          (divider("Part II", "Which journals publish this research?", "Where the most cited papers are, the main journals, their fees, how fast new journals entered Scopus, and BI&rsquo;s current journal", "div2", "A row of gates, one small new gate open"), "Part II"),
          (s_topcited, "Fig 4 top cited"), (s_venues_all, "Fig 5 venues"), (s_venues_core, "Fig 6 core venues"), (s_launched, "Fig 7 launches"), (s_benchmarks, "Fig 8 benchmarks"), (s_oa, "Fig 9 open access"), (s_oa_model, "Fig 10 journal model"),
          (divider("Part III", "How much does Indonesia publish, and where?", "Volume, topics, journals, and how much is in Scopus", "div3", "An archipelago with paper boats sailing to a continent"), "Part III"),
          (s_id_share, "Fig 11 share"), (s_countries, "Fig 12 countries"), (s_id_venues, "Fig 13 Indonesian venues"), (s_id_inst, "Fig 14 institutions"),
          (divider("Part IV", "Which themes should JDSE cover?", "Six standard tests: growth and citations, Q1 share, keyword map, sudden rises, Indonesia&rsquo;s strengths, and countries", "div4", "A figure with a compass on a rock among small islands"), "Part IV"),
          (s_growth_impact, "Fig 15 growth x impact"), (s_q1share, "Fig 16 Q1 share"), (s_coword, "Fig 17 co-word"), (s_bursts, "Fig 18 bursts"), (s_activity, "Fig 19 activity"), (s_geography, "Fig 20 geography"),
          (divider("Part V", "What this means for JDSE", "Limits of the evidence, then six recommendations", "div5", "A small group of figures laying the first stones of a path toward a distant lit building"), "Part V"),
          (s_limits, "Limits"), (s_implications, "Implications"), (s_metrics, "Metrics"), (s_references, "References"),
          (divider("", "Thank you", "Arief Anshory Yusuf &middot; Universitas Padjadjaran</p>" + REPL_LINK + "<p hidden>", "thanks", "A figure placing the first volume on an empty shelf"), "Thank you")]


# ------------------------------------------------------------------ study notes: collapsible, closed by default, one per slide
def _h(t): return f"<h4>{t}</h4>"
def _p(t): return f"<p>{t}</p>"
def _ul(*xs): return "<ul>" + "".join(f"<li>{x}</li>" for x in xs) + "</ul>"
def _qa(*pairs): return "<dl>" + "".join(f"<dt>{q}</dt><dd>{a}</dd>" for q, a in pairs) + "</dl>"


NOTES = {}
NOTES["Cover"] = (_h("How to use these notes") + _p("Each slide has a note like this one, closed by default. Open it while you prepare; close it when you present. The notes assume no background in bibliometrics.") +
                  _h("Your role today") + _p("You are the speaker on the <b>sustainable</b> half of the journal&rsquo;s scope. Prof. Kridanto (session 2) covers the digital half. Your job is to tell BINS which research themes the journal should cover, who it should serve, and how to stand out. The deck answers with data, not opinion.") +
                  _h("The one-sentence message") + _p("The field is growing fast at its finance end and where digital meets sustainable; the best journals are owned by large publishers and by China&rsquo;s authors; Indonesia publishes a great deal but almost none of it is visible in Scopus Q1; JDSE should own the digital &times; sustainable intersection, serve emerging-market authors, be free to publish in, and get indexed fast."))
NOTES["Context"] = (NOTES["Cover"] + _h("What this slide says") + _p("Why you are here and what BINS needs from the day.") +
                    _h("Concepts") + _ul("<b>JDSE</b>: Journal of Digital and Sustainable Economy and Finance, a new journal planned by Bank Indonesia Institute (BINS).", "<b>Konsinyering</b>: a closed working meeting to draft a document; here, the concept of the journal.",
                                         "<b>SINTA</b>: Indonesia&rsquo;s national journal accreditation (S1 to S6). <b>DOAJ</b>: Directory of Open Access Journals, a quality list for open-access journals. <b>Garuda</b>: Indonesia&rsquo;s national article index.",
                                         "<b>Scopus</b> (Elsevier) and <b>Web of Science / SSCI</b> (Clarivate): the two international indexes that universities and ministries use to judge journals. <b>ABDC</b>: the Australian Business Deans Council list, used in business and finance schools.",
                                         "<b>COPE</b>: Committee on Publication Ethics, the standard ethics code. <b>APC</b>: article processing charge, the fee an author pays to publish open access.") +
                    _h("What to say") + _p("&ldquo;A journal that does not exist yet has to choose which conversation it joins. I will show what the published literature says about that choice.&rdquo;"))
NOTES["Objectives"] = (_h("What this slide says") + _p("The four questions of the talk, each tied to a line in the TOR. This is how you show BINS the talk is useful for their document, not just interesting.") +
                       _h("How to use it") + _p("Read the left column aloud. Point to the right column for the outputs: &ldquo;Question 1 feeds your priority themes, question 2 your positioning and fee policy, question 3 your target authors, question 4 your aims and scope and first call for papers.&rdquo;"))
NOTES["Data sources"] = (_h("What this slide says") + _p("Where every number comes from.") +
                         _h("Concepts") + _ul("<b>OpenAlex</b>: a free, open database of almost all scholarly papers (about 250 million), run by a non-profit (OurResearch). It replaced Microsoft Academic. It includes journals that Scopus does not index, which matters for Indonesia: in my August 2026 census, Indonesia had 11,918 journals in OpenAlex and 303 in Scopus.",
                                              "<b>Scopus</b>: Elsevier&rsquo;s curated index of about 49,000 sources. A journal must apply and pass review to be included, and can be <b>discontinued</b> (removed) for quality or ethics problems.",
                                              "<b>Scopus Source List</b>: the spreadsheet Elsevier publishes every few months listing every indexed source, with active/inactive status and a discontinued flag. We used the September 2026 release.",
                                              "<b>SCImago Journal Rank (SJR)</b>: a ranking of Scopus journals built from Scopus data. Each journal gets a quartile in each subject: <b>Q1</b> is the top 25% of journals in that subject.",
                                              "<b>API</b>: a way for a program to query a database directly. We downloaded records by program, not by hand.") +
                         _h("If asked") + _qa(("Why not just Scopus?", "Scopus misses most Indonesian journals. If we only used Scopus, Indonesia&rsquo;s output would look ten times smaller and we could not see where its authors publish. So we use OpenAlex for the census and Scopus to tell which journals are indexed."),
                                              ("Is OpenAlex reliable?", "For counting what was published, yes; published comparisons find it covers more than Scopus. It is weaker on author affiliations, which is why institution counts are labelled indicative.")))
NOTES["Corpus"] = (_h("What this slide says") + _p("Exactly which papers were counted.") +
                   _h("Concepts") + _ul("<b>Topic</b>: OpenAlex classifies every paper into up to three of 4,516 topics, using a machine-learning model trained on titles, abstracts, journals and citations. The <b>primary topic</b> is the best fit.",
                                        "<b>Keyword</b> (on the slides later): OpenAlex also attaches short keywords to each paper, such as &ldquo;green bonds&rdquo; or &ldquo;ESG ratings&rdquo;. We use these to describe themes inside the topics.",
                                        "<b>Corpus</b>: the set of papers analysed. Ours: 248,756 papers whose primary topic is one of six sustainable topics; 398,142 papers carrying one of five digital topics; and the <b>intersection</b>, papers carrying one topic from each set.",
                                        "<b>Articles and reviews</b>: we excluded editorials, letters, book chapters and conference papers.") +
                   _h("Why topics, not keyword search") + _p("Searching titles for words catches the wrong papers: &ldquo;innovation&rdquo; catches education research, &ldquo;transfer&rdquo; catches heat transfer. In my SDG study a quarter of one SDG&rsquo;s papers were mis-assigned that way. A topic classifier reads the whole paper record, so it is cleaner.") +
                   _h("The Scopus query") + _p("We used a keyword search once, in Scopus, only to cross-check growth. It is shown in full so anyone can rerun it. The bare word ESG was replaced by ESG phrases because &ldquo;ESG&rdquo; is also a medical abbreviation.") +
                   _h("If asked") + _qa(("Why CSR reporting in the sustainable set?", "It is the largest sustainable topic and it is where most Indonesian papers sit; leaving it out would hide that. Several slides show results with and without it."),
                                        ("Why not climate science?", "The journal is about economics and finance. Climate science papers are not its authors or readers.")))
NOTES["Four filters"] = (_h("What this slide says") + _p("Every result is computed four times, through four increasingly strict filters on the journal a paper appears in. This is the most important idea in the deck.") +
                        _h("The four filters") + _ul("<b>All OpenAlex journals</b>: every paper in a journal, indexed or not.", "<b>Scopus, all listed</b>: only papers in journals on the Scopus list, including journals Scopus later discontinued.",
                                                    "<b>Scopus, excluding discontinued</b>: drops journals Scopus removed. Discontinued journals are often predatory or low-quality.", "<b>Scopus Q1, excluding discontinued</b>: only journals in the top quartile of their subject in SCImago.") +
                        _h("How to read the table") + _p("Each row is a group of papers; each column keeps fewer. The small grey percentage is the share of the first column kept. World: 50% of sustainable-topic papers are in Scopus journals and 33% in Q1. Indonesia: 11% in Scopus and 4% in Q1. Part III explains this gap.") +
                        _h("What to say") + _p("&ldquo;Counting everything and counting only Q1 tell different stories. I show both, so we do not mistake volume for quality.&rdquo;") +
                        _h("If asked") + _qa(("Why keep discontinued journals in one filter?", "Their papers were indexed when published. Showing the filter with and without them shows how much of a country&rsquo;s papers are in journals Scopus later removed."),
                                             ("Why Q1 and not Q1+Q2?", "Q1 is the usual bar for a reputable international journal and the usual benchmark for BINS. Q2 to Q4 are inside the &lsquo;excluding discontinued&rsquo; filter.")))
NOTES["Metrics"] = (_h("What this slide says") + _p("A glossary of every number on the slides. Keep it open on your laptop during questions.") +
                    _h("The ones that matter most") + _ul("<b>CAGR</b> (compound annual growth rate): the steady yearly growth that would turn the 2020 count into the 2025 count. 15% a year doubles a field in five years.",
                                                         "<b>Citation score</b> (also called field-normalised citation score, MNCS): a paper&rsquo;s citations divided by the average citations of papers published the same year in the same filter. 1 = average; 2 = cited twice as much as an average paper of its age. This corrects for the fact that older papers have had more time to be cited.",
                                                         "<b>h-index of a journal</b>: if a journal has h-index 33, it has published 33 papers each cited at least 33 times. A rough measure of how many influential papers it has carried.",
                                                         "<b>Two-year mean citedness</b>: average citations a journal&rsquo;s recent papers receive; close to the Impact Factor.",
                                                         "<b>Activity index</b>: whether a country publishes more or less on a theme than its overall size would predict. 2 = twice its normal share; 0.5 = half.",
                                                         "<b>Diamond open access</b>: free to read and free to publish; the journal is paid for by an institution. <b>Gold</b>: free to read, author pays an APC. <b>Hybrid</b>: subscription journal where the author can pay to open one paper."))
NOTES["Methods"] = (_h("What this slide says") + _p("The six standard techniques from the bibliometric literature, with the reference each comes from. It answers &ldquo;is this a standard method?&rdquo;") +
                    _h("Plain-language version of each") + _ul("<b>Growth against impact</b>: a theme is promising if it grows faster than the field and its papers are cited more than average. Growth alone can pick short-lived topics. Citations alone can pick old topics. The standard test uses both (Rotolo and colleagues 2015; Small and colleagues 2014).",
                                                                "<b>Q1 share</b>: what share of a theme&rsquo;s papers make it into the best journals. Elsevier&rsquo;s own &lsquo;topic prominence&rsquo; uses journal quality as one of three ingredients (Klavans and Boyack 2017).",
                                                                "<b>Co-word map</b>: keywords that appear together on the same papers are linked; groups of tightly linked keywords form themes. Each theme is placed by how cohesive it is (density) and how connected it is to other themes (centrality). Invented by Callon in 1991; standard in the SciMAT and bibliometrix software.",
                                                                "<b>Burst detection</b>: a statistical model that finds the years when a keyword&rsquo;s share suddenly jumped above its normal rate (Kleinberg 2003). It is what the CiteSpace software calls &lsquo;citation bursts&rsquo;.",
                                                                "<b>Activity index</b>: specialisation of a country, the bibliometric version of revealed comparative advantage in trade (Schubert and Braun 1986).",
                                                                "<b>Geographic concentration</b>: how much of a theme one country writes. A theme where one country writes 80% is hard for newcomers to enter.") +
                    _h("If asked") + _qa(("What is Louvain?", "A widely used algorithm that splits a network into groups whose members are more linked to each other than to the rest (Blondel and colleagues 2008)."),
                                         ("What is the equivalence index?", "A way to measure the strength of the link between two keywords that corrects for how common each is: co-occurrences squared divided by the product of the two counts.")))
NOTES["Limits"] = (_h("What this slide says") + _p("Where the numbers could be wrong, said up front. This protects you in discussion.") +
                   _h("The two you may be asked about") + _ul("<b>Institution counts</b>: OpenAlex sometimes merges institutions with similar names (I found three Indonesian cases in an earlier study). Treat institution rankings as indicative.",
                                                               "<b>Recent keywords look faster than they are</b>: OpenAlex attached keywords less completely to older papers, so a keyword that appears from nothing may partly reflect better tagging. Growth comparisons between keywords in the same period are safe; absolute growth of a new keyword should be read with care.") +
                   _h("What to say") + _p("&ldquo;These are census numbers, not a peer review of each paper. They show patterns across hundreds of thousands of papers, which is what a journal strategy needs.&rdquo;"))
NOTES["Part I"] = _p("Part I answers: which themes are growing, which are fading, and how fast digital and sustainable finance are meeting.")
NOTES["Fig 1 growth"] = (_h("What this slide says") + _p("The sustainable-finance part of the field and the digital &times; sustainable overlap grow far faster than the field as a whole, and this holds when we count only Scopus or only Q1 journals.") +
                         _h("How to read it") + _p("Four lines per chart, one per filter: light grey all journals, mid grey Scopus listed, dark Scopus excluding discontinued, red Q1. The table below gives the growth multiple from 2015 to 2025 for each filter.") +
                         _h("Numbers to remember") + _ul("Sustainable finance and green bonds: 19&times; in all journals, 42&times; in Q1 (2015 to 2025).", "Digital &times; sustainable intersection: 56&times; in all journals, 137&times; in Q1.", "All six sustainable topics: 3&times; under every filter."))
NOTES["Fig 1 growth"] += (_h("What to say") + _p("&ldquo;The field as a whole tripled in ten years. The finance end grew twenty to forty times. The overlap with digital finance grew more than fifty times. It grew faster in the best journals than in all journals. So the growth is not only in weak journals.&rdquo;") +
                          _h("If asked") + _qa(("Why is Q1 growth higher than all-journal growth?", "Because in 2015 almost no Q1 journal published on sustainable finance; it started from a very small base. It also means top journals have taken the topic seriously."),
                                               ("Is growth just more papers everywhere?", "Science as a whole grows about 4 to 5% a year. Sustainable finance grew about 30% a year. The difference is real.")))
NOTES["Fig 2 themes"] = (_h("What this slide says") + _p("The keywords show three changes. Green finance became the main label: from 23% to 36% of papers in all journals, and from 10% to 31% in Q1. Climate finance and climate mitigation fell. Transition risk, greenwashing and ESG ratings are new, but each is only 3 to 5% of papers.") +
                         _h("How to read it") + _p("Each pair of bars is one keyword: grey = share of papers carrying it in 2015-18, red = in 2023-26. Left chart all journals, right chart Q1 journals.") +
                         _h("Concepts") + _ul("<b>Climate finance</b>: money for climate action, mostly public and international. <b>Climate risk</b>: the financial risk to firms and banks from climate change. <b>Transition risk</b>: the risk from the move to a low-carbon economy (stranded assets, carbon prices).",
                                              "<b>ESG ratings</b>: scores given to firms on environmental, social and governance performance by agencies such as MSCI. <b>Greenwashing</b>: claiming to be greener than you are. <b>Green credit</b>: bank lending tied to green purposes.") +
                         _h("What to say") + _p("&ldquo;Green finance is now the main label. Risk, ratings and greenwashing are new and growing, but still small. These new topics are close to central-bank work.&rdquo;") +
                         _h("Be careful") + _p("Do not say research moved to climate risk. Climate risk rose from 4% to 7% in all journals, and only from 8% to 9% in Q1. The early Q1 sample has only 217 papers, so its shares are uncertain. China-related papers rose from 3% to 14% in Q1; much of the green-finance growth comes from China."))
NOTES["Fig 3 intersection"] = (_h("What this slide says") + _p("Papers that combine digital and sustainable finance are few but growing fastest, and no journal is built for them. JDSE&rsquo;s name already names this topic.") +
                               _h("Examples of intersection papers") + _ul("Fintech and green credit; digital finance and carbon emissions; blockchain for carbon markets and ESG data; mobile money and climate resilience; digital payment data for ESG measurement.") +
                               _h("Numbers to remember") + _ul("4,640 papers in all journals 2010-2026; 1,977 in Q1.", "The largest topic inside it in Q1 is energy, environment and growth (641 papers): mostly studies of whether digital finance lowers emissions.") +
                               _h("What to say") + _p("&ldquo;The journal&rsquo;s name already names this topic. No journal specialises in it yet. The first journal that does can become the main journal for it.&rdquo;"))
NOTES["Fig 4 top cited"] = (_h("What this slide says") + _p("The most cited papers in sustainable finance are in the top five finance journals: Journal of Financial Economics, Review of Financial Studies, Journal of Finance.") +
                            _h("Why it matters") + _p("JDSE will not compete for those papers. It competes for the applied, empirical and policy work one level below, which is most of the field and almost all of the emerging-market part.") +
                            _h("If asked") + _qa(("Should JDSE aim to publish papers like Bolton and Kacperczyk?", "Eventually, through invited special issues. At launch, aim for the best applied emerging-market work, which these journals rarely publish.")))
NOTES["Part II"] = _p("Part II answers: which journals carry the field, what they charge, how fast new journals were indexed, and what a central-bank journal looks like today.")
NOTES["Fig 5 venues"] = (_h("What this slide says") + _p("The largest outlets for the sustainable topics: one megajournal (Sustainability, MDPI) and then established Elsevier and Wiley journals, almost all Scopus Q1. Most are subscription journals: authors publish for free, and pay $3,450 to $4,660 only if they want open access. Sustainability (MDPI) is fully open access and charges every author $2,896.") +
                         _h("Concepts") + _ul("<b>Megajournal</b>: a very large open-access journal that publishes many papers across topics with fast review (MDPI&rsquo;s Sustainability published 4,194 papers in these topics).", "<b>Index status</b> column: whether the journal is in Scopus and its quartile, from the September 2026 list.") +
                         _h("What to say") + _p("&ldquo;The main journals belong to large publishers. Most are free to publish in but closed to readers. Sustainability is open but charges every author. There is room for a good journal that is free for both.&rdquo;"))
NOTES["Fig 6 core venues"] = (_h("What this slide says") + _p("In sustainable finance proper, the work is spread across general finance journals; only one specialist journal (Journal of Sustainable Finance &amp; Investment) is in the top ten.") +
                              _h("Why it matters") + _p("When a field has no specialist journal, a new specialist journal can grow quickly.") +
                              _h("How &lsquo;specialist&rsquo; is measured") + _p("Topic share = the journal&rsquo;s papers in the sustainable-finance topic divided by all its papers, 2016-2026. Journal of Sustainable Finance &amp; Investment: 37%. All the others: 5% or less. The rule: above 25% is a specialist. Any cut-off between 6% and 36% gives the same answer.") +
                              _h("If asked") + _qa(("Why only 37% for a specialist journal?", "Many of its other papers are in close topics, such as ESG and CSR reporting, which OpenAlex classifies separately.")))
NOTES["Fig 7 launches"] = (_h("What this slide says") + _p("Journals launched since 2010 in this field were indexed in Scopus within zero to one year when a large publisher carried them, three years in the best institution-hosted case, and five years for others.") +
                           _h("Concepts") + _ul("<b>Years to index</b>: the gap between the journal&rsquo;s first year of papers and the first year of its Scopus coverage. Scopus often indexes back to the first issue once a journal is accepted, so a gap of 0 means the publisher&rsquo;s journals enter with coverage from volume 1.") +
                           _h("The model to cite") + _p("<b>Financial Innovation</b>: hosted by Southwestern University of Finance and Economics (Chengdu), published with Springer, no APC; indexed after three years; now Q1 with h-index 83 and two-year citedness 10.3.") +
                           _h("If asked") + _qa(("How long does Scopus usually take?", "Scopus asks for at least two years of regular publication before an application. Then review takes months. So three years from launch is fast but achievable."),
                                                ("Should BI partner with a big publisher?", "It is the fastest route to indexing and visibility. The cost is control and possibly fees. A middle path: publisher hosting with BI paying, so authors pay no APC.")))
NOTES["Fig 8 benchmarks"] = (_h("What this slide says") + _p("BI already has a journal: the Bulletin of Monetary Economics and Banking (BMEB). Its numbers are the baseline JDSE must beat.") +
                             _h("Numbers to remember") + _ul("BMEB: in Scopus (Q2), h-index 33, two citations per paper in two years, 43% Indonesian authors, no sustainable-finance topic among its main topics.", "International Journal of Central Banking: h-index 22 after twenty years, even with central-bank backing.", "Borsa Istanbul Review and Financial Innovation: institution-hosted journals that reached Q1.") +
                             _h("What to say") + _p("&ldquo;Being hosted by a central bank does not by itself make a journal reputable. What did it for Borsa Istanbul Review and Financial Innovation was a publisher partner, a clear niche, and international authors.&rdquo;") +
                             _h("Be careful") + _p("BMEB is BINS&rsquo;s own journal; present it as a baseline, not a criticism."))
NOTES["Fig 9 open access"] = (_h("What this slide says") + _p("Diamond open access is common outside Scopus (28% of all papers) and rare inside Q1 (2%). Most Q1 papers are behind a paywall or paid by the author.") +
                              _h("Concepts") + _ul("<b>Closed</b>: subscription only. <b>Hybrid</b>: subscription journal, author can pay to open one paper. <b>Gold</b>: open, author pays APC. <b>Green</b>: author posts a free copy in a repository. <b>Bronze</b>: free to read on the publisher site without a clear licence. <b>Diamond</b>: open and free for authors; an institution pays.") +
                              _h("What to say") + _p("&ldquo;A Q1-quality diamond journal in sustainable finance hardly exists. A central bank is one of the few institutions that can afford to run one. This is JDSE&rsquo;s clearest opportunity.&rdquo;"))
NOTES["Part III"] = _p("Part III answers: how much Indonesia publishes on these themes, where, and how much of it the world sees.")
NOTES["Fig 10 journal model"] = (_h("What this slide says") + _p("Journals have different business models. In a subscription journal, the author publishes for free and the reader pays. The author can pay a fee (hybrid) to make one paper open. In an open-access journal, the reader pays nothing; the author pays an APC, unless the journal is diamond.") +
                                _h("Numbers to remember") + _ul("73% of the world&rsquo;s Q1 papers are in subscription journals. 72% of those papers paid no open-access fee.", "Indonesia: 36% of its Q1 papers are in open-access journals that charge every author, against 25% for the world.", "Among Indonesia&rsquo;s Q1 papers in subscription journals, only 15% paid the hybrid fee; the world figure is 28%.") +
                                _h("Why it matters for developing countries") + _p("For authors, the subscription route is free, so the APC is not the only way into Q1. For readers, subscription papers are closed; many universities in developing countries cannot pay. A diamond journal removes both costs.") +
                                _h("Be careful") + _p("&lsquo;Fee not known&rsquo; is large for Indonesia in all journals (56%). These are mostly small open-access journals outside Scopus that OpenAlex has no APC record for. Many of them charge a small local fee.") +
                                _h("If asked") + _qa(("Is the APC in the Figure 5 table always paid?", "No. For subscription journals the APC is optional. The table marks it &lsquo;optional&rsquo;."), ("Where do the models come from?", "OpenAlex journal records: whether the journal is fully open access, its APC, and DOAJ listing.")))
NOTES["Fig 11 share"] = (_h("What this slide says") + _p("Indonesia writes 14% of the world&rsquo;s papers on these themes in all journals, but 1.5% in Q1. By count it is second in the world; in Q1 it is 32nd.") +
                         _h("How to read it") + _p("Left chart: Indonesia&rsquo;s share of the world per year, four filters. Right chart: the same without CSR reporting. The gap between the light grey line and the red line shows volume versus visibility.") +
                         _h("What to say") + _p("&ldquo;Indonesia does not lack researchers on these themes. It lacks papers in the journals the world reads.&rdquo;") +
                         _h("If asked") + _qa(("Why so much CSR?", "CSR disclosure studies of listed firms are easy to do with annual-report data and are a standard thesis topic in accounting programmes. 85% of Indonesia&rsquo;s papers in the six topics are in that one topic.")))
NOTES["Fig 12 countries"] = (_h("What this slide says") + _p("The country ranking changes completely with the filter. China leads under all four. Indonesia is 2nd in all journals, then falls out of the top ten under every Scopus filter.") +
                             _h("Why it matters") + _p("If BINS wants international authors, the countries that publish in Q1 are China, the United States, the United Kingdom, Germany, Australia, Italy and the Netherlands. For emerging-market authors: India, Malaysia, Vietnam, Pakistan."))
NOTES["Fig 13 Indonesian venues"] = (_h("What this slide says") + _p("An active Scopus journal holds 47% of the world&rsquo;s papers on these themes, 23% of ASEAN-6&rsquo;s, and 8% of Indonesia&rsquo;s. When Indonesian authors do reach Q1, they use the same international journals as everyone else; no Indonesian journal is among them.") +
                                     _h("What to say") + _p("&ldquo;Indonesian authors already write on these themes. What they lack is a reachable, indexed journal close to home. If JDSE keeps quality high, it can be that journal.&rdquo;"))
NOTES["Fig 14 institutions"] = (_h("What this slide says") + _p("The Indonesian institutions that publish most on these themes (Trisakti, Udayana, Brawijaya) are not the ones that publish most in Q1 (Airlangga, UI, Sebelas Maret, UGM, IPB). These are the two halves of JDSE&rsquo;s home author base.") +
                                _h("How to use it") + _p("The volume authors will submit first. The Q1 authors must be recruited as authors, reviewers and editors. They make the journal credible."))
NOTES["Part IV"] = _p("Part IV applies six standard tests from the bibliometric literature to say which themes JDSE should prioritise.")
NOTES["Fig 15 growth x impact"] = (_h("What this slide says") + _p("The themes that are both growing fast and well cited are firm- and market-level ESG and green-finance questions. Large climate-policy themes are cited but mature. Some fast-growing labels are little cited.") +
                                   _h("How to read it") + _p("Each bubble is a keyword. Right = grows faster; up = cited more than average. The dashed vertical line is the growth of the whole field; the dashed horizontal line is average citation (1). Top right is the promising quadrant. Bubble size = recent papers. Red bubbles are above both lines.") +
                                   _h("Numbers to remember") + _ul("ESG performance: grows 100% a year, cited 3.1&times; average.", "ESG ratings 3.0&times;; ESG disclosure 2.5&times;; green finance 1.7&times;.", "Green economy and environmental accounting: cited at 0.4 of average.") +
                                   _h("What to say") + _p("&ldquo;Growth alone can pick short-lived topics. Growth plus citations shows what researchers actually use. That points to ESG measurement, green finance and climate risk at firm and bank level.&rdquo;"))
NOTES["Fig 16 Q1 share"] = (_h("What this slide says") + _p("For each theme, the share of its papers that appear in Q1 journals. Climate, energy-transition and carbon-pricing papers reach Q1 at about 45-50%; CSR, disclosure and green-economy papers at 7-22%. The field average is 33%.") +
                            _h("Why it matters") + _p("Themes with a high Q1 share are where good authors already send their work; JDSE must offer them something to compete. Themes with a low Q1 share are where JDSE will receive many weak submissions and must be selective."))
NOTES["Fig 17 co-word"] = (_h("What this slide says") + _p("The field&rsquo;s keywords group into nine themes in each filter. The map shows which themes are central and cohesive (motor themes), which are broad and loose (basic), and which are small and young.") +
                           _h("How to read a strategic diagram") + _ul("<b>Top right, motor themes</b>: well developed and connected to the rest; they are the main themes of the field.", "<b>Bottom right, basic and transversal</b>: connected to everything but loose inside; general themes.", "<b>Top left, niche</b>: well developed but isolated; specialist.", "<b>Bottom left, emerging or declining</b>: weak and isolated; check the growth column to tell which.") +
                           _h("Key reading") + _p("In Q1, the firm-finance cluster (state-owned enterprises, financial constraints, green innovation) and the carbon pricing and emissions trading cluster are central. ESG ratings, climate risk and sustainable investment form a small, young cluster growing 2.2&times;: a good subject for the journal&rsquo;s first special issue.") +
                           _h("If asked") + _qa(("Why do the two maps differ?", "Q1 journals publish a different mix: more climate policy and firm finance, less CSR disclosure. The difference shows where the best work is.")))
NOTES["Fig 18 bursts"] = (_h("What this slide says") + _p("Burst detection finds keywords whose share jumped suddenly. All strong bursts are recent and still continuing. This is typical of a young field. The bursts are ESG performance and ratings, green finance and bonds, financial constraints, green innovation, greenwashing and carbon neutrality.") +
                          _h("Concepts") + _ul("<b>Burst</b>: a period where a keyword appears much more often than its long-run rate, estimated by Kleinberg&rsquo;s model. <b>Strength</b>: how strong the evidence is that the jump is real.", "<b>Carbon neutrality</b> and <b>state-owned enterprises</b>: keywords from Chinese studies of carbon peaking and firm finance. Their appearance in Q1 shows China&rsquo;s weight.") +
                          _h("What to say") + _p("&ldquo;These are the themes for the first call for papers: the topics rising now, not five years ago.&rdquo;"))
NOTES["Fig 19 activity"] = (_h("What this slide says") + _p("Indonesia specialises in disclosure and governance variables that the world cites little, is almost absent from the climate and carbon themes the world cites more, and in nearly every theme its own papers are cited below the world average.") +
                            _h("How to read it") + _p("Right of the dashed vertical line: Indonesia publishes more on the theme than its size predicts. Above the horizontal line: the world cites the theme above average. Bubble size: Indonesian papers.") +
                            _h("Numbers to remember") + _ul("Independent commissioners: activity index 8.9; world citation score 0.25.", "Climate policy: activity index 0.2; climate adaptation 0.2; carbon pricing 0.4.", "In 95% of themes Indonesian papers are cited below the world average of the theme; median gap 0.6.") +
                            _h("What to say") + _p("&ldquo;JDSE can help move Indonesian research from disclosure counting toward the climate-risk and finance questions the world reads, through its calls, its reviewers and its special issues.&rdquo;") +
                            _h("Be careful") + _p("Say this as an opportunity, not a criticism of Indonesian scholars. Many in the room supervise this work."))
NOTES["Fig 20 geography"] = (_h("What this slide says") + _p("Some themes are open (no country writes more than a quarter of Q1 papers): energy transition, sustainability reporting, SDGs, Paris Agreement, climate mitigation. Some are closed: in green finance, emissions trading, ESG performance, state-owned enterprises and financial constraints, China writes more than half of Q1 papers.") +
                             _h("Why it matters") + _p("Open themes are easier for ASEAN authors to enter. Closed themes need Chinese authors and reviewers if JDSE wants to cover them well. ASEAN-6 authors hold 3-11% of Q1 papers in every theme; Indonesia under 4%."))
NOTES["Implications"] = (_h("What this slide says") + _p("Six recommendations, each tied to a figure. This is your closing slide; read the six headings slowly.") +
                         _h("Short version to say") + _ul("Own the digital &times; sustainable intersection.", "Follow the themes that rose in Q1: climate and transition risk, financial stability, ESG ratings, greenwashing, green credit.", "Serve emerging-market authors, starting with ASEAN.", "Be diamond open access and get indexed fast, with a publisher partner if needed.", "Require data and code; publish policy briefs.", "Measure the journal from day one and report against BMEB&rsquo;s baseline.") +
                         _h("Likely questions") + _qa(("Should the journal be in English?", "Yes. Every indexing target in the TOR beyond SINTA and Garuda requires it, and the authors it must recruit publish in English."),
                                                      ("How many issues a year?", "Two issues of 8 to 10 papers at launch is realistic; regularity matters more to Scopus than size."),
                                                      ("Who should be on the editorial board?", "International names from the top-right themes in Figure 15 and the Q1 institutions in Figure 14, plus ASEAN central-bank researchers. The co-word clusters give the list of fields to cover.")))
NOTES["References"] = _p("All method references are standard in bibliometrics. If asked for one book: Aria and Cuccurullo (2017) describe the bibliometrix toolkit that implements most of these methods.")


def _with_note(f, note):
    def g():
        html = f()
        if not note or "panel cover" in html or "panel divider" in html: return html
        det = f'<details class="study"><summary>Study note</summary><div class="study-body">{note}</div></details>'
        i = html.rfind("</section>")
        return html[:i] + det + html[i:] if i >= 0 else html
    return g


if os.environ.get("V2"):
    _ack = ('<p class="aiack"><b>Acknowledgement of AI use.</b> Claude (Anthropic) helped write the code for data download and analysis, and helped draft the slides. '
            'Midjourney generated the illustrations. The author checked the results and is responsible for all content.</p>')
    SLIDES = [(divider("", "Thank you", "Arief Anshory Yusuf &middot; Universitas Padjadjaran</p>" + REPL_LINK + _ack + "<p hidden>", "thanks", "A figure placing the first volume on an empty shelf"), lab) if lab == "Thank you" else (f, lab) for f, lab in SLIDES]
else:
    SLIDES = [(_with_note(f, NOTES.get(lab)), lab) for f, lab in SLIDES]




# =====================================================================================================
# Write every chart as a standalone SVG file and every table as a CSV file into ../figures
# =====================================================================================================
import csv as _csv, html as _html, re as _re
FIGDIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "figures")
os.makedirs(FIGDIR, exist_ok=True)
COLORS = {'--baseline': '#c3b6aa', '--border': 'rgba(51,48,46,0.13)', '--c1': '#0f5499', '--c2': '#00994d', '--c3': '#c05c7e', '--c4': '#b86b25', '--c5': '#0d7680', '--c6': '#ff8833', '--c7': '#593380', '--c8': '#cc0000', '--c9': '#262a33', '--muted': '#8b8480', '--surface-1': '#fff9f2', '--text-primary': '#33302e', '--text-secondary': '#66605c', '--grid': '#e6d9ce', '--blue-dark': '#0f5499'}
STYLE = ("<style>text{font-family:system-ui,'Segoe UI',Arial,sans-serif}.g{stroke:#e6d9ce;stroke-width:1}"
         ".ph{font-size:16px;font-weight:650;fill:#66605c}.ax{font-size:15px;fill:#8b8480}.lab{font-size:16px}.val{font-size:16px}"
         ".tick{font-size:13.5px}.end{text-anchor:end}.mid{text-anchor:middle}tspan.rk{fill:#8b8480;font-weight:400}</style>")


def _ent(m):
    if m.group(1) in ("amp", "lt", "gt", "quot", "apos"): return m.group(0)
    return "".join(f"&#{ord(c)};" for c in _html.unescape(m.group(0)))


def _standalone(svg):
    svg = _re.sub(r"var\((--[a-z0-9-]+)\)", lambda m: COLORS.get(m.group(1), "#888888"), svg)
    svg = _re.sub(r"&([A-Za-z][A-Za-z0-9]*);", _ent, svg)
    m = _re.match(r"<svg([^>]*)>", svg)
    vb = _re.search(r'viewBox="0 0 ([\d.]+) ([\d.]+)"', m.group(1))
    head = f'<svg xmlns="http://www.w3.org/2000/svg"{m.group(1)}' + (f' width="{vb.group(1)}" height="{vb.group(2)}"' if vb else "") + ">"
    bg = f'<rect width="100%" height="100%" fill="#fff9f2"/>'
    return head + STYLE + bg + svg[m.end():]


def _cells(row):
    return [_html.unescape(_re.sub(r"<[^>]+>", "", c)).strip() for c in _re.findall(r"<t[hd][^>]*>(.*?)</t[hd]>", row, _re.S)]


index = []
for f, lab in SLIDES:
    if not (lab.startswith("Fig ") or lab == "Four filters"): continue
    h = f()
    num = lab.split()[1] if lab.startswith("Fig ") else "filters"
    stem = f"fig{int(num):02d}" if num.isdigit() else "table_filters"
    title = _re.search(r"<h2[^>]*>(.*?)</h2>", h, _re.S)
    title = _html.unescape(_re.sub(r"<[^>]+>", "", title.group(1))).strip() if title else lab
    files = []
    for i, svg in enumerate(_re.findall(r"<svg.*?</svg>", h, _re.S), 1):
        fn = f"{stem}_chart{i}.svg"; open(os.path.join(FIGDIR, fn), "w", encoding="utf-8").write(_standalone(svg)); files.append(fn)
    for i, tb in enumerate(_re.findall(r"<table.*?</table>", h, _re.S), 1):
        fn = f"{stem}_table{i}.csv"
        with open(os.path.join(FIGDIR, fn), "w", encoding="utf-8-sig", newline="") as g:
            w = _csv.writer(g)
            for row in _re.findall(r"<tr[^>]*>(.*?)</tr>", tb, _re.S): w.writerow(_cells(row))
        files.append(fn)
    if "tlegend" in h:
        files.append("(line colours: light grey = All OpenAlex journals; mid grey = Scopus, all listed; dark = Scopus, excl. discontinued; red = Scopus Q1, excl. discontinued)")
    index.append((stem, title, files))
with open(os.path.join(FIGDIR, "index.txt"), "w", encoding="utf-8") as g:
    for stem, title, files in index:
        g.write(title + "\n" + "".join(f"    {x}\n" for x in files) + "\n")
import xml.etree.ElementTree as _ET
for _f in os.listdir(FIGDIR):
    if _f.endswith(".svg"): _ET.parse(os.path.join(FIGDIR, _f))  # every SVG must be valid XML
print("figures written:", sum(1 for x in index for y in x[2] if not y.startswith("(")), "files for", len(index), "figures; all SVG files are valid XML")
