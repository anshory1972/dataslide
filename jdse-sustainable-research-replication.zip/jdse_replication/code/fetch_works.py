# Per-work downloads so every journal can be classified (All OpenAlex / Scopus all / Scopus active / Q1 active).
# S = primary topic in the six sustainable topics; D = any topic in the five digital topics. 2010-2026, articles and reviews.
# One thread per (set, year), cursor paging; each work reduced to the fields the deck needs, written as gzipped JSON lines.
import os as _os, sys as _sys
ROOT = _os.path.dirname(_os.path.dirname(_os.path.abspath(__file__)))  # package root
_sys.stdout.reconfigure(encoding='utf-8', errors='replace')
import gzip, json, os, sys, time, urllib.parse, urllib.request
from concurrent.futures import ThreadPoolExecutor

KEY = _os.environ.get("OPENALEX_API_KEY", "")
OUT = ROOT + "/data/works/"
os.makedirs(OUT, exist_ok=True)
SUST = "T13146|T10471|T10119|T12013|T12883|T10115"
DIGI = "T11995|T13346|T10987|T10270|T12958"
SUST_SET = set(SUST.split("|")); DIGI_SET = set(DIGI.split("|"))
SETS = {
    "S": (f"primary_topic.id:{SUST}", "id,publication_year,primary_location,primary_topic,topics,keywords,authorships,open_access,cited_by_count"),
    "D": (f"topics.id:{DIGI}", "id,publication_year,primary_location,primary_topic,topics"),
}


def tid(t): return (t or {}).get("id", "").split("/")[-1]


def reduce(w, full):
    src = (((w.get("primary_location") or {}).get("source")) or {})
    topics = [tid(t) for t in (w.get("topics") or [])]
    r = {"y": w.get("publication_year"), "s": src.get("id", "").split("/")[-1] or None, "pt": tid(w.get("primary_topic")), "t": topics,
         "inter": bool(set(topics) & SUST_SET) and bool(set(topics) & DIGI_SET)}
    if full:
        r["kw"] = [k.get("display_name") for k in (w.get("keywords") or [])]
        cs, inst = set(), {}
        for a in (w.get("authorships") or []):
            for c in (a.get("countries") or []): cs.add(c)
            for i in (a.get("institutions") or []):
                for lid in (i.get("lineage") or [i.get("id")]):
                    if lid: inst[lid.split("/")[-1]] = i.get("display_name") if lid == i.get("id") else inst.get(lid.split("/")[-1])
        r["c"] = sorted(cs)
        r["i"] = inst if "ID" in cs else {}
        r["oa"] = (w.get("open_access") or {}).get("oa_status")
        r["cit"] = w.get("cited_by_count")
        r["id"] = w.get("id", "").split("/")[-1]
    return r


def get(url, tries=6):
    for t in range(tries):
        try:
            with urllib.request.urlopen(urllib.request.Request(url, headers={"User-Agent": "aay-jdse"}), timeout=120) as r:
                return json.load(r)
        except Exception as e:
            print("retry", t, str(e)[:80], file=sys.stderr, flush=True); time.sleep(4 * (t + 1))
    raise RuntimeError(url)


def job(setname, year):
    path = f"{OUT}{setname}_{year}.jsonl.gz"
    if os.path.exists(path) and os.path.getsize(path) > 0 and os.path.exists(path + ".done"):
        return setname, year, "skip"
    filt, sel = SETS[setname]
    full = setname == "S"
    cursor, n = "*", 0
    with gzip.open(path, "wt", encoding="utf-8") as f:
        while cursor:
            url = (f"https://api.openalex.org/works?filter={filt},publication_year:{year},type:article|review"
                   f"&per_page=200&cursor={urllib.parse.quote(cursor)}&select={sel}&api_key={KEY}")
            d = get(url)
            for w in d["results"]:
                f.write(json.dumps(reduce(w, full), ensure_ascii=False) + "\n"); n += 1
            cursor = d["meta"].get("next_cursor")
            if not d["results"]: break
    open(path + ".done", "w").write(str(n))
    return setname, year, n


if __name__ == "__main__":
    jobs = [(s, y) for s in ("S", "D") for y in range(2010, 2027)]
    with ThreadPoolExecutor(max_workers=12) as ex:
        for s, y, n in ex.map(lambda a: job(*a), jobs):
            print(s, y, n, flush=True)
    print("done")
