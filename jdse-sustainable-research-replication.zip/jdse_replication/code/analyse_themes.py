# Six standard theme analyses on the per-work data (six sustainable topics, keyword level), by journal filter.
#  1 growth x impact      CAGR 2020-25, acceleration, field-normalised citation score (cites / same-year mean in the lens, works 2018-2023)
#  2 Q1 share per theme   share of a keyword's 2016-26 papers (all journals) that sit in Scopus Q1 excl. discontinued
#  3 co-word diagram      keyword co-occurrence, equivalence index, Louvain clusters, Callon centrality and density, 2021-2026
#  4 burst detection      Kleinberg two-state model on yearly keyword shares, 2010-2025
#  5 Indonesia activity   activity index (ID share of theme / ID share of field) and ID citation score per theme, 2016-26
#  6 geography            number of countries, leading country and its share, China and ASEAN-6 shares per theme, 2016-26
import os as _os, sys as _sys
ROOT = _os.path.dirname(_os.path.dirname(_os.path.abspath(__file__)))  # package root
_sys.stdout.reconfigure(encoding='utf-8', errors='replace')
import csv, glob, gzip, json, math, sys
from collections import Counter, defaultdict
import networkx as nx
from networkx.algorithms.community import louvain_communities
sys.path.insert(0, _os.path.dirname(_os.path.abspath(__file__)))
from classify_sources import norm_issn
from scopus_list import load as load_scopus_list

D = ROOT + "/data/"
REPO_WORDS = ("zenodo", "repositor", "doaj", "repec", "dialnet", "cairn", "figshare", "ssrn", "agecon", "referencia", "irdb", "scielo", "osf", "eprints", "arxiv", "research square", "econstor", "hal (")
sj = {}
with open(ROOT + "/data/inputs/scimagojr 2025.csv", encoding="utf-8-sig") as f:
    for r in csv.DictReader(f, delimiter=";"):
        for i in (r.get("Issn") or "").split(","):
            i = norm_issn(i.strip())
            if i: sj[i] = r["SJR Best Quartile"]
SL = load_scopus_list(); LISTED = SL["sources"]; DISC = set(SL["discontinued"])
META = json.load(open(D + "sources_meta.json", encoding="utf-8")); TIER = {}


def tiers_of(sid):
    if not sid: return set()
    if sid in TIER: return TIER[sid]
    s = META.get(sid); t = set()
    if s and s.get("type") == "journal" and not any(w in (s.get("display_name") or "").lower() for w in REPO_WORDS):
        t.add("all")
        iss = [norm_issn(i) for i in (s.get("issn") or [])] + [norm_issn(s.get("issn_l") or "")]; iss = [i for i in iss if i]
        listed = any(i in LISTED or i in DISC for i in iss); dl = any(i in DISC for i in iss); q = next((sj[i] for i in iss if i in sj), None)
        if listed: t.add("scopus")
        if listed and not dl: t.add("active")
        if listed and not dl and q == "Q1": t.add("q1")
    TIER[sid] = t; return t


STOP = {"China", "Indonesia", "India", "COVID-19 pandemic", "moderating effect", "mediating effect", "firm size", "research trends", "agency theory", "signaling theory", "stakeholder theory", "legitimacy theory",
        "institutional theory", "leverage", "profitability", "return on assets", "return on equity", "Tobin's Q", "listed companies", "Chinese listed companies", "Indonesia Stock Exchange", "Indonesia Stock Exchange listed companies",
        "manufacturing companies", "mining companies", "energy companies", "non-financial firms", "sustainability", "sustainable development", "climate change", "panel data", "content analysis", "systematic literature review",
        "bibliometric analysis", "firm performance", "financial performance", "firm value", "board size", "ownership structure", "institutional ownership", "sustainability reports", "developing countries", "transparency"}
ASEAN = {"ID", "MY", "TH", "VN", "PH", "SG"}
LENSES = ["all", "active", "q1"]

works = []
for f in sorted(glob.glob(D + "works/S_*.jsonl.gz")):
    with gzip.open(f, "rt", encoding="utf-8") as g:
        for line in g:
            w = json.loads(line); ts = tiers_of(w.get("s"))
            if not ts: continue
            works.append((w["y"], ts, set(k for k in (w.get("kw") or []) if k and k not in STOP), set(w.get("c") or []), w.get("cit") or 0, w["pt"]))
print("works with a journal", len(works), flush=True)

# vocabulary: keywords with >= 300 papers 2019-2026 in all journals
voc = Counter()
for y, ts, kw, c, cit, pt in works:
    if 2019 <= y <= 2026:
        for k in kw: voc[k] += 1
VOC = [k for k, v in voc.items() if v >= 300]
print("vocabulary", len(VOC), flush=True)
VS = set(VOC)

# per-lens year means and 90th percentiles of citations, for normalisation
cits = defaultdict(list)
for y, ts, kw, c, cit, pt in works:
    for L in ts: cits[(L, y)].append(cit)
mean_c = {k: (sum(v) / len(v) if v else 0) for k, v in cits.items()}
p90 = {k: sorted(v)[int(0.9 * (len(v) - 1))] if v else 0 for k, v in cits.items()}

cnt = {L: defaultdict(Counter) for L in LENSES}; tot = {L: Counter() for L in LENSES}
ncs = {L: defaultdict(list) for L in LENSES}; top10 = {L: defaultdict(list) for L in LENSES}
q1share = defaultdict(lambda: [0, 0, 0])            # all, active, q1 counts 2016-26
idA = {L: Counter() for L in LENSES}; idT = {L: 0 for L in LENSES}; wA = {L: Counter() for L in LENSES}; wT = {L: 0 for L in LENSES}
idncs = {L: defaultdict(list) for L in LENSES}
geo = {L: defaultdict(Counter) for L in LENSES}; geoN = {L: Counter() for L in LENSES}
for y, ts, kw, c, cit, pt in works:
    k_in = kw & VS
    for L in ts:
        if L not in cnt: continue
        tot[L][y] += 1
        for k in k_in: cnt[L][k][y] += 1
        if 2018 <= y <= 2023 and mean_c.get((L, y)):
            nc = cit / mean_c[(L, y)]; t10 = 1 if cit >= p90[(L, y)] and cit > 0 else 0
            for k in k_in: ncs[L][k].append(nc); top10[L][k].append(t10)
            if "ID" in c:
                for k in k_in: idncs[L][k].append(nc)
        if 2016 <= y <= 2026:
            wT[L] += 1
            for k in k_in: wA[L][k] += 1
            if "ID" in c:
                idT[L] += 1
                for k in k_in: idA[L][k] += 1
            for k in k_in:
                geoN[L][k] += 1
                for cc in c: geo[L][k][cc] += 1
    if 2016 <= y <= 2026 and "all" in ts:
        for k in k_in:
            q1share[k][0] += 1
            if "active" in ts: q1share[k][1] += 1
            if "q1" in ts: q1share[k][2] += 1


def cagr(a, b, yrs): return (b / a) ** (1 / yrs) - 1 if a > 0 and b > 0 else None


out = {"vocab_n": len(VOC), "lenses": LENSES}
# 1 growth x impact
G = {}
for L in LENSES:
    rows = []
    for k in VOC:
        c = cnt[L][k]
        if c[2020] < 10 or sum(c[y] for y in range(2023, 2026)) < 30: continue
        g = cagr(c[2020], c[2025], 5); g1 = cagr(c[2019], c[2022], 3) if c[2019] >= 5 else None; g2 = cagr(c[2022], c[2025], 3)
        sh20 = c[2020] / tot[L][2020]; sh25 = c[2025] / tot[L][2025]
        v = ncs[L][k]
        rows.append({"kw": k, "c2020": c[2020], "c2025": c[2025], "recent": sum(c[y] for y in range(2023, 2026)), "cagr": g, "accel": (g2 - g1) if (g1 is not None and g2 is not None) else None,
                     "share2020": sh20, "share2025": sh25, "share_ratio": sh25 / sh20 if sh20 else None, "ncs": sum(v) / len(v) if len(v) >= 20 else None, "top10": sum(top10[L][k]) / len(top10[L][k]) if len(top10[L][k]) >= 20 else None})
    G[L] = rows
out["growth_impact"] = G
# field growth reference
out["field_cagr"] = {L: cagr(tot[L][2020], tot[L][2025], 5) for L in LENSES}
# 2 Q1 share
out["q1share"] = sorted([{"kw": k, "n_all": v[0], "share_active": v[1] / v[0], "share_q1": v[2] / v[0]} for k, v in q1share.items() if v[0] >= 600], key=lambda r: -r["n_all"])
fa = sum(1 for y, ts, kw, c, cit, pt in works if 2016 <= y <= 2026 and "all" in ts); fq = sum(1 for y, ts, kw, c, cit, pt in works if 2016 <= y <= 2026 and "q1" in ts)
out["q1share_field"] = fq / fa


# 3 co-word strategic diagram
def coword(L, y0=2021, y1=2026, topn=90):
    vc = Counter(); docs = []
    for y, ts, kw, c, cit, pt in works:
        if L in ts and y0 <= y <= y1:
            kk = kw & VS
            if kk: docs.append(kk); vc.update(kk)
    top = [k for k, _ in vc.most_common(topn)]; T = set(top)
    co = Counter()
    for kk in docs:
        kk = sorted(kk & T)
        for i in range(len(kk)):
            for j in range(i + 1, len(kk)): co[(kk[i], kk[j])] += 1
    Gx = nx.Graph()
    for (a, b), v in co.items():
        e = v * v / (vc[a] * vc[b])
        if v >= 5: Gx.add_edge(a, b, weight=e)
    for k in top: Gx.add_node(k)
    comms = louvain_communities(Gx, weight="weight", seed=7, resolution=1.6)
    cl = {}
    for i, cm in enumerate(comms):
        for k in cm: cl[k] = i
    res = []
    for i, cm in enumerate(comms):
        if len(cm) < 2: continue
        internal = sum(d["weight"] for a, b, d in Gx.edges(data=True) if cl[a] == i and cl[b] == i)
        external = sum(d["weight"] for a, b, d in Gx.edges(data=True) if (cl[a] == i) != (cl[b] == i))
        members = sorted(cm, key=lambda k: -vc[k])
        early = sum(1 for (y, ts, kw, c, cit, pt) in works if L in ts and 2021 <= y <= 2023 and kw & set(cm))
        late = sum(1 for (y, ts, kw, c, cit, pt) in works if L in ts and 2024 <= y <= 2026 and kw & set(cm))
        res.append({"members": members, "label": ", ".join(members[:3]), "density": 100 * internal / len(cm), "centrality": 10 * external, "papers": sum(vc[k] for k in cm), "growth": late / early if early else None})
    return res
out["coword"] = {L: coword(L) for L in ["all", "q1"]}


# 4 Kleinberg two-state burst detection on yearly shares
def bursts(L, s=2.0, gamma=1.0, years=range(2010, 2026)):
    Y = list(years); dtot = [tot[L][y] for y in Y]; R = sum(dtot)
    res = []
    for k in VOC:
        r = [cnt[L][k][y] for y in Y]
        if sum(r) < 60: continue
        p0 = sum(r) / R; p1 = min(s * p0, 0.9999)
        def cost(p, rt, dt): return -(rt * math.log(p) + (dt - rt) * math.log(1 - p)) if dt else 0
        n = len(Y); tc = gamma * math.log(n)
        C = [[0, 0] for _ in range(n)]; back = [[0, 0] for _ in range(n)]
        C[0] = [cost(p0, r[0], dtot[0]), cost(p1, r[0], dtot[0]) + tc]
        for t in range(1, n):
            for st, p in ((0, p0), (1, p1)):
                opts = [C[t - 1][0] + (tc if st == 1 else 0), C[t - 1][1]]
                b = 0 if opts[0] <= opts[1] else 1
                C[t][st] = opts[b] + cost(p, r[t], dtot[t]); back[t][st] = b
        st = 0 if C[-1][0] <= C[-1][1] else 1; states = [st]
        for t in range(n - 1, 0, -1): st = back[t][st]; states.append(st)
        states = states[::-1]
        t = 0
        while t < n:
            if states[t] == 1:
                u = t
                while u + 1 < n and states[u + 1] == 1: u += 1
                w = sum(cost(p0, r[i], dtot[i]) - cost(p1, r[i], dtot[i]) for i in range(t, u + 1))
                res.append({"kw": k, "start": Y[t], "end": Y[u], "strength": w, "ongoing": Y[u] == Y[-1]})
                t = u + 1
            else: t += 1
    return sorted(res, key=lambda b: -b["strength"])
out["bursts"] = {L: bursts(L) for L in ["all", "q1"]}

# 5 Indonesia activity index
A = {}
for L in ["all", "active"]:
    rows = []
    for k in VOC:
        if idA[L][k] < (20 if L == "all" else 8) or not wA[L][k]: continue
        ai = (idA[L][k] / idT[L]) / (wA[L][k] / wT[L]); v = idncs[L][k]
        wv = ncs[L][k]
        rows.append({"kw": k, "id_n": idA[L][k], "world_n": wA[L][k], "ai": ai, "id_ncs": sum(v) / len(v) if len(v) >= 8 else None, "world_ncs": sum(wv) / len(wv) if wv else None})
    A[L] = rows
out["activity"] = A; out["id_total"] = idT; out["world_total"] = wT
# 6 geography
GEO = {}
for L in ["all", "q1"]:
    rows = []
    for k in VOC:
        N = geoN[L][k]
        if N < (400 if L == "all" else 150): continue
        g = geo[L][k]; lead, lv = g.most_common(1)[0]
        rows.append({"kw": k, "n": N, "countries": len(g), "leader": lead, "leader_share": lv / N, "cn": g.get("CN", 0) / N, "asean": sum(g.get(a, 0) for a in ASEAN) / N, "id": g.get("ID", 0) / N,
                     "hhi": sum((v / N) ** 2 for v in g.values())})
    GEO[L] = sorted(rows, key=lambda r: -r["n"])
out["geography"] = GEO
json.dump(out, open(D + "deck_data_themes.json", "w", encoding="utf-8"), ensure_ascii=False, indent=1)

# ---- printout
print("field CAGR 2020-25", {L: round(100 * v, 1) for L, v in out["field_cagr"].items()})
for L in ["all", "q1"]:
    rows = [r for r in G[L] if r["ncs"] is not None]
    print(f"\n[1 {L}] top by recent volume: kw | cagr | accel | ncs | top10")
    for r in sorted(rows, key=lambda r: -r["recent"])[:30]:
        print(f"   {r['kw'][:38]:<38} {100*r['cagr']:>6.1f}% {100*(r['accel'] or 0):>6.1f} {r['ncs']:>5.2f} {100*(r['top10'] or 0):>5.1f}% n={r['recent']}")
print("\n[2] Q1 share field", round(100 * out["q1share_field"], 1))
for r in out["q1share"][:30]: print(f"   {r['kw'][:40]:<40} n={r['n_all']:>6} q1 {100*r['share_q1']:>5.1f}%  active {100*r['share_active']:>5.1f}%")
for L in ["all", "q1"]:
    print(f"\n[3 {L}] clusters: label | density | centrality | papers | growth")
    for c in sorted(out["coword"][L], key=lambda c: -c["papers"]): print(f"   {c['label'][:60]:<60} d={c['density']:.2f} c={c['centrality']:.2f} n={c['papers']} g={c['growth'] and round(c['growth'],2)}")
for L in ["all", "q1"]:
    print(f"\n[4 {L}] bursts starting 2018+:")
    for b in [b for b in out["bursts"][L] if b["start"] >= 2018][:18]: print(f"   {b['kw'][:40]:<40} {b['start']}-{b['end']} strength {b['strength']:.0f} {'ongoing' if b['ongoing'] else ''}")
for L in ["all", "active"]:
    print(f"\n[5 {L}] Indonesia total {idT[L]} of {wT[L]}; themes by activity index:")
    for r in sorted(out["activity"][L], key=lambda r: -r["ai"])[:14]: print(f"   {r['kw'][:40]:<40} AI {r['ai']:.2f} n={r['id_n']} id_ncs={r['id_ncs'] and round(r['id_ncs'],2)} world_ncs={r['world_ncs'] and round(r['world_ncs'],2)}")
    print("   lowest AI among big themes:")
    for r in sorted([r for r in out["activity"][L] if r["world_n"] > 2000], key=lambda r: r["ai"])[:8]: print(f"   {r['kw'][:40]:<40} AI {r['ai']:.2f} n={r['id_n']}")
for L in ["all", "q1"]:
    print(f"\n[6 {L}] geography: kw | n | countries | leader share | CN | ASEAN | ID")
    for r in GEO[L][:22]: print(f"   {r['kw'][:36]:<36} {r['n']:>6} {r['countries']:>4} {r['leader']} {100*r['leader_share']:>5.1f}% CN {100*r['cn']:>5.1f}% ASEAN {100*r['asean']:>5.1f}% ID {100*r['id']:>5.1f}%")
print("saved deck_data_themes.json")
