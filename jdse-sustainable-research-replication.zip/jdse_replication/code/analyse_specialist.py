# Share of each journal's papers (2016-2026) whose primary topic is Sustainable finance and green bonds (T13146).
# Topic papers from the per-work downloads; journal totals from OpenAlex counts_by_year. Output: data/deck_data_specialist.json
import os as _os, sys as _sys
ROOT = _os.path.dirname(_os.path.dirname(_os.path.abspath(__file__)))  # package root
_sys.stdout.reconfigure(encoding='utf-8', errors='replace')
import glob, gzip, json
from collections import Counter
D = ROOT + "/data/"
M = json.load(open(D + "sources_meta.json", encoding="utf-8"))
dd = json.load(open(D + "deck_data.json", encoding="utf-8"))
names = [r["name"] for r in dd["venues_T13146"][:12]]
byname = {}
for sid, m in M.items():
    k = m.get("display_name")
    if k in names and (k not in byname or (m.get("works_count") or 0) > (M[byname[k]].get("works_count") or 0)): byname[k] = sid
ids = set(byname.values()); c = Counter()
for f in glob.glob(D + "works/S_*.jsonl.gz"):
    if not 2016 <= int(f.split("_")[-1][:4]) <= 2026: continue
    for line in gzip.open(f, "rt", encoding="utf-8"):
        w = json.loads(line)
        if w["s"] in ids and w["pt"] == "T13146": c[w["s"]] += 1
out = {}
for nm, sid in byname.items():
    tot = sum(x["works_count"] for x in M[sid].get("counts_by_year", []) if 2016 <= x["year"] <= 2026)
    out[nm] = {"topic": c[sid], "total": tot, "share": 100 * c[sid] / max(tot, 1)}
json.dump(out, open(D + "deck_data_specialist.json", "w", encoding="utf-8"), ensure_ascii=False, indent=1)
print(len(out))
