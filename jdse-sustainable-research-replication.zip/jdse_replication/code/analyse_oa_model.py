# Journal business model (subscription with optional OA, OA with APC, OA without APC) by filter.
# Same tier lookup as analyse_tiers.py.
#   all    = every OpenAlex journal (repositories, preprint servers and works without a source excluded)
#   scopus = ISSN on the Scopus Source List, September 2026 (sources sheet or discontinued sheet)
#   active = listed and not discontinued by Scopus (Active or Inactive status both kept)
#   q1     = listed, not discontinued, and SCImago 2025 best quartile Q1
# Each tier is a subset of the one before. Output: data/deck_data_tiers.json
import os as _os, sys as _sys
ROOT = _os.path.dirname(_os.path.dirname(_os.path.abspath(__file__)))  # package root
_sys.stdout.reconfigure(encoding='utf-8', errors='replace')
import csv, glob, gzip, json, re, sys
from collections import Counter, defaultdict
sys.path.insert(0, _os.path.dirname(_os.path.abspath(__file__)))
from classify_sources import norm_issn
from scopus_list import load as load_scopus_list

D = ROOT + "/data/"
TIERS = ["all", "scopus", "active", "q1"]
TIER_NAME = {"all": "All OpenAlex journals", "scopus": "Scopus, all listed", "active": "Scopus, excl. discontinued", "q1": "Scopus Q1, excl. discontinued"}
SUST = ["T13146", "T10471", "T10119", "T12013", "T12883", "T10115"]
ASEAN = {"ID", "MY", "TH", "VN", "PH", "SG"}
REPO_WORDS = ("zenodo", "repositor", "doaj", "repec", "dialnet", "cairn", "figshare", "ssrn", "agecon", "referencia", "irdb", "scielo", "osf", "eprints", "arxiv", "research square", "econstor", "hal (")

# ---- journal tier lookup
sj = {}
with open(ROOT + "/data/inputs/scimagojr 2025.csv", encoding="utf-8-sig") as f:
    for r in csv.DictReader(f, delimiter=";"):
        for i in (r.get("Issn") or "").split(","):
            i = norm_issn(i.strip())
            if i: sj[i] = r["SJR Best Quartile"]
SL = load_scopus_list(); LISTED = SL["sources"]; disc = set(SL["discontinued"])
META = json.load(open(D + "sources_meta.json", encoding="utf-8"))
TIER_OF = {}


def tiers_of(sid):
    if sid in TIER_OF: return TIER_OF[sid]
    s = META.get(sid)
    t = set()
    if s and s.get("type") == "journal" and not any(w in (s.get("display_name") or "").lower() for w in REPO_WORDS):
        t.add("all")
        issns = [norm_issn(i) for i in (s.get("issn") or [])] + [norm_issn(s.get("issn_l") or "")]
        issns = [i for i in issns if i]
        listed = any(i in LISTED or i in disc for i in issns)
        dl = any(i in disc for i in issns)
        q = next((sj[i] for i in issns if i in sj), None)
        if listed: t.add("scopus")
        if listed and not dl: t.add("active")
        if listed and not dl and q == "Q1": t.add("q1")
    TIER_OF[sid] = t
    return t


def load(prefix):
    for f in sorted(glob.glob(D + f"works/{prefix}_*.jsonl.gz")):
        with gzip.open(f, "rt", encoding="utf-8") as g:
            for line in g:
                yield json.loads(line)



def model(sid):
    s = META.get(sid) or {}
    if not s.get("is_oa"): return "sub"
    apc = s.get("apc_usd")
    if apc and apc > 0: return "oa_apc"
    if apc == 0 or s.get("is_in_doaj"): return "oa_free"
    return "oa_unknown"


M = ["sub", "oa_apc", "oa_free", "oa_unknown"]
share = {g: {t: Counter() for t in TIERS} for g in ["world", "ID", "ASEAN"]}
subpaid = {g: {t: Counter() for t in TIERS} for g in ["world", "ID"]}
ven = defaultdict(Counter)
for w in load("S"):
    if w["pt"] not in SUST or not (2016 <= w["y"] <= 2026): continue
    ts = tiers_of(w["s"]) if w.get("s") else set()
    if not ts: continue
    m = model(w["s"]); c = set(w.get("c") or [])
    groups = ["world"] + (["ID"] if "ID" in c else []) + (["ASEAN"] if c & ASEAN else [])
    for t in ts:
        for g in groups:
            share[g][t][m] += 1
            if m == "sub" and g in subpaid: subpaid[g][t][w.get("oa") or "closed"] += 1
    ven[w["s"]][w.get("oa") or "closed"] += 1; ven[w["s"]]["n"] += 1
out = {"models": M, "share": share, "subpaid": subpaid,
       "venues": {sid: {"name": META[sid]["display_name"], "model": model(sid), "apc": META[sid].get("apc_usd"), "doaj": META[sid].get("is_in_doaj"), **ven[sid]} for sid in ven if ven[sid]["n"] >= 100 and sid in META}}
json.dump(out, open(D + "deck_data_oamodel.json", "w", encoding="utf-8"), ensure_ascii=False, indent=1)
for g in share:
    for t in TIERS:
        n = sum(share[g][t].values()); print(g, t, n, {m: round(100 * share[g][t][m] / n, 1) for m in M})
for g in subpaid:
    for t in TIERS:
        n = sum(subpaid[g][t].values()); print("sub papers", g, t, n, {k: round(100 * v / n, 1) for k, v in subpaid[g][t].most_common()})

