# Four-tier analysis on the per-work downloads.
#   all    = every OpenAlex journal (repositories, preprint servers and works without a source excluded)
#   scopus = ISSN on the Scopus Source List, September 2026 (sources sheet or discontinued sheet)
#   active = listed and not discontinued by Scopus (Active or Inactive status both kept)
#   q1     = listed, not discontinued, and SCImago 2025 best quartile Q1
# Each tier is a subset of the one before. Output: data/deck_data_tiers.json
import os as _os, sys as _sys
ROOT = _os.path.dirname(_os.path.dirname(_os.path.abspath(__file__)))  # package root
_sys.stdout.reconfigure(encoding='utf-8', errors='replace')
import csv, glob, gzip, json, re, sys
from collections import Counter, defaultdict
sys.path.insert(0, _os.path.dirname(_os.path.abspath(__file__)))
from classify_sources import norm_issn
from scopus_list import load as load_scopus_list

D = ROOT + "/data/"
TIERS = ["all", "scopus", "active", "q1"]
TIER_NAME = {"all": "All OpenAlex journals", "scopus": "Scopus, all listed", "active": "Scopus, excl. discontinued", "q1": "Scopus Q1, excl. discontinued"}
SUST = ["T13146", "T10471", "T10119", "T12013", "T12883", "T10115"]
ASEAN = {"ID", "MY", "TH", "VN", "PH", "SG"}
REPO_WORDS = ("zenodo", "repositor", "doaj", "repec", "dialnet", "cairn", "figshare", "ssrn", "agecon", "referencia", "irdb", "scielo", "osf", "eprints", "arxiv", "research square", "econstor", "hal (")

# ---- journal tier lookup
sj = {}
with open(ROOT + "/data/inputs/scimagojr 2025.csv", encoding="utf-8-sig") as f:
    for r in csv.DictReader(f, delimiter=";"):
        for i in (r.get("Issn") or "").split(","):
            i = norm_issn(i.strip())
            if i: sj[i] = r["SJR Best Quartile"]
SL = load_scopus_list(); LISTED = SL["sources"]; disc = set(SL["discontinued"])
META = json.load(open(D + "sources_meta.json", encoding="utf-8"))
TIER_OF = {}


def tiers_of(sid):
    if sid in TIER_OF: return TIER_OF[sid]
    s = META.get(sid)
    t = set()
    if s and s.get("type") == "journal" and not any(w in (s.get("display_name") or "").lower() for w in REPO_WORDS):
        t.add("all")
        issns = [norm_issn(i) for i in (s.get("issn") or [])] + [norm_issn(s.get("issn_l") or "")]
        issns = [i for i in issns if i]
        listed = any(i in LISTED or i in disc for i in issns)
        dl = any(i in disc for i in issns)
        q = next((sj[i] for i in issns if i in sj), None)
        if listed: t.add("scopus")
        if listed and not dl: t.add("active")
        if listed and not dl and q == "Q1": t.add("q1")
    TIER_OF[sid] = t
    return t


def load(prefix):
    for f in sorted(glob.glob(D + f"works/{prefix}_*.jsonl.gz")):
        with gzip.open(f, "rt", encoding="utf-8") as g:
            for line in g:
                yield json.loads(line)


YEARS = list(range(2010, 2027))
out = {"tier_names": TIER_NAME, "years": YEARS}
# ---- S corpus
yS = {t: Counter() for t in TIERS}; yT = {t: Counter() for t in TIERS}; yNo = {t: Counter() for t in TIERS}
yID = {t: Counter() for t in TIERS}; yIDno = {t: Counter() for t in TIERS}; yCN = {t: Counter() for t in TIERS}
kw_e = {t: Counter() for t in TIERS}; kw_l = {t: Counter() for t in TIERS}; n_e = Counter(); n_l = Counter()
oa = {t: Counter() for t in TIERS}
cty = {t: Counter() for t in TIERS}; ctyT = {t: Counter() for t in TIERS}
idtopic = {t: Counter() for t in TIERS}; idinst = {t: Counter() for t in TIERS}; instname = {}
idven = {t: Counter() for t in TIERS}; wven = {t: Counter() for t in TIERS}; wvenT = {t: Counter() for t in TIERS}
funnel = {k: Counter() for k in ["S", "T13146", "S_ID", "S_ID_noCSR", "S_ASEAN", "S_ID_T13146"]}
nosrc = Counter()
for w in load("S"):
    y = w["y"]; ts = tiers_of(w["s"]) if w.get("s") else set()
    if not ts: nosrc["S"] += 1
    c = set(w.get("c") or []); pt = w["pt"]
    for t in ts:
        yS[t][y] += 1
        if pt == "T13146": yT[t][y] += 1
        if pt != "T10115": yNo[t][y] += 1
        if "ID" in c:
            yID[t][y] += 1
            if pt != "T10115": yIDno[t][y] += 1
        if "CN" in c: yCN[t][y] += 1
        if 2016 <= y <= 2026:
            funnel["S"][t] += 1
            if pt == "T13146": funnel["T13146"][t] += 1
            oa[t][w.get("oa")] += 1
            for k in c: cty[t][k] += 1
            if pt == "T13146":
                for k in c: ctyT[t][k] += 1
            wven[t][w["s"]] += 1
            if pt == "T13146": wvenT[t][w["s"]] += 1
            if c & ASEAN: funnel["S_ASEAN"][t] += 1
            if "ID" in c:
                funnel["S_ID"][t] += 1
                if pt != "T10115": funnel["S_ID_noCSR"][t] += 1
                if pt == "T13146": funnel["S_ID_T13146"][t] += 1
                idtopic[t][pt] += 1; idven[t][w["s"]] += 1
                for iid, nm in (w.get("i") or {}).items():
                    idinst[t][iid] += 1
                    if nm: instname[iid] = nm
        if pt == "T13146":
            if 2015 <= y <= 2018:
                n_e[t] += 1
                for k in set(w.get("kw") or []): kw_e[t][k] += 1
            if 2023 <= y <= 2026:
                n_l[t] += 1
                for k in set(w.get("kw") or []): kw_l[t][k] += 1
# ---- D corpus
yD = {t: Counter() for t in TIERS}; yI = {t: Counter() for t in TIERS}; itop = {t: Counter() for t in TIERS}; iven = {t: Counter() for t in TIERS}
for w in load("D"):
    y = w["y"]; ts = tiers_of(w["s"]) if w.get("s") else set()
    for t in ts:
        yD[t][y] += 1
        if w.get("inter"):
            yI[t][y] += 1
            if 2010 <= y <= 2026: itop[t][w["pt"]] += 1; iven[t][w["s"]] += 1; funnel.setdefault("inter", Counter())[t] += 1

ser = lambda C: {t: [C[t].get(y, 0) for y in YEARS] for t in TIERS}
out["series"] = {"S": ser(yS), "T13146": ser(yT), "noCSR": ser(yNo), "ID": ser(yID), "ID_noCSR": ser(yIDno), "CN": ser(yCN), "D": ser(yD), "inter": ser(yI)}
out["funnel"] = {k: dict(v) for k, v in funnel.items()}
TOPIC_NAMES = {"T13146": "Sustainable finance and green bonds", "T10471": "Climate change policy and economics", "T10119": "Sustainability and climate governance", "T12013": "Sustainable development and environmental policy",
               "T12883": "Sustainable development and environmental management", "T10115": "CSR and ESG reporting"}
PICK = ["green finance", "green bonds", "sustainable finance", "climate finance", "climate change mitigation", "green banking", "climate risk", "transition risk", "greenwashing", "ESG ratings", "green credit",
        "financial stability", "emerging markets", "China", "environmental regulation", "green innovation", "carbon pricing", "central banks", "monetary policy", "fintech"]
out["kw"] = {t: {"n_early": n_e[t], "n_late": n_l[t], "rows": [{"kw": k, "early": round(100 * kw_e[t][k] / max(n_e[t], 1), 1), "late": round(100 * kw_l[t][k] / max(n_l[t], 1), 1)} for k in PICK]} for t in TIERS}
out["oa"] = {t: dict(oa[t]) for t in TIERS}
out["countries"] = {t: cty[t].most_common(15) for t in TIERS}
out["countries_T13146"] = {t: ctyT[t].most_common(15) for t in TIERS}
out["country_rank_ID"] = {t: next((i + 1 for i, (k, _) in enumerate(cty[t].most_common()) if k == "ID"), None) for t in TIERS}
out["country_rank_ID_T13146"] = {t: next((i + 1 for i, (k, _) in enumerate(ctyT[t].most_common()) if k == "ID"), None) for t in TIERS}
out["id_topic"] = {t: [(TOPIC_NAMES.get(k, k), v) for k, v in idtopic[t].most_common()] for t in TIERS}
import urllib.request
KEY = _os.environ.get("OPENALEX_API_KEY", "")
cand = set()
for t in TIERS: cand.update(k for k, _ in idinst[t].most_common(80))
cand = sorted(cand); inst_country = {}
for i in range(0, len(cand), 50):
    chunk = cand[i:i + 50]
    with urllib.request.urlopen(f"https://api.openalex.org/institutions?filter=ids.openalex:{'|'.join(chunk)}&per_page=50&select=id,display_name,country_code&api_key={KEY}", timeout=90) as r:
        for s in json.load(r)["results"]:
            inst_country[s["id"].split("/")[-1]] = s.get("country_code"); instname[s["id"].split("/")[-1]] = s.get("display_name")
out["id_inst"] = {t: [(instname.get(k, k), v) for k, v in idinst[t].most_common(80) if inst_country.get(k) == "ID"][:15] for t in TIERS}
nm = lambda s: (META.get(s) or {}).get("display_name", s)
pub = lambda s: (META.get(s) or {}).get("host_organization_name")
out["id_venues"] = {t: [(nm(s), pub(s), v) for s, v in idven[t].most_common(12)] for t in TIERS}
out["world_venues"] = {t: [(nm(s), pub(s), v) for s, v in wven[t].most_common(12)] for t in TIERS}
out["world_venues_T13146"] = {t: [(nm(s), pub(s), v) for s, v in wvenT[t].most_common(12)] for t in TIERS}
out["inter_topics"] = {t: itop[t].most_common(8) for t in TIERS}
out["inter_venues"] = {t: [(nm(s), pub(s), v) for s, v in iven[t].most_common(10)] for t in TIERS}
out["nosrc"] = dict(nosrc)
json.dump(out, open(D + "deck_data_tiers.json", "w", encoding="utf-8"), ensure_ascii=False, indent=1)

# ---- printout
print("funnel (2016-2026 works by tier):")
for k, v in out["funnel"].items(): print(f"  {k:<14}", {t: v.get(t, 0) for t in TIERS})
print("Indonesia rank, six topics:", out["country_rank_ID"], " T13146:", out["country_rank_ID_T13146"])
i15, i25 = YEARS.index(2015), YEARS.index(2025)
for k in ["S", "T13146", "noCSR", "D", "inter", "ID"]:
    print(f"  {k:<8} 2015->2025", {t: f"{out['series'][k][t][i15]}->{out['series'][k][t][i25]}" for t in TIERS})
for t in TIERS:
    print(f"  ID share 2025 [{t}]: {100*out['series']['ID'][t][i25]/max(out['series']['S'][t][i25],1):.1f}%  excl CSR {100*out['series']['ID_noCSR'][t][i25]/max(out['series']['noCSR'][t][i25],1):.1f}%")
print("top countries q1:", out["countries"]["q1"][:8]); print("top ID inst q1:", out["id_inst"]["q1"][:6]); print("top ID inst all:", out["id_inst"]["all"][:6])
print("saved deck_data_tiers.json")
