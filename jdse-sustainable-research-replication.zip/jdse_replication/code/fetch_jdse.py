# OpenAlex pulls for the JDSE session: sustainable economy and finance research, its venues,
# its overlap with digital finance, and Indonesia's place in it. Filter-only queries with group_by.
import os as _os, sys as _sys
ROOT = _os.path.dirname(_os.path.dirname(_os.path.abspath(__file__)))  # package root
_sys.stdout.reconfigure(encoding='utf-8', errors='replace')
import json, os, sys, time, urllib.parse, urllib.request

KEY = _os.environ.get("OPENALEX_API_KEY", "")
OUT = ROOT + "/data/"
os.makedirs(OUT, exist_ok=True)
BASE = "https://api.openalex.org/works"
YEARS = "2010-2026"
TYPES = "type:article|review"

SUST = {"T13146": "Sustainable finance and green bonds", "T10471": "Climate change policy and economics",
        "T10119": "Sustainability and climate change governance", "T12013": "Sustainable development and environmental policy",
        "T12883": "Sustainable development and environmental management", "T10115": "CSR and ESG reporting"}
DIGI = {"T11995": "FinTech, crowdfunding, digital finance", "T13346": "Digital transformation in financial services",
        "T10987": "Microfinance and financial inclusion", "T10270": "Blockchain technology", "T12958": "Digital economy and transformation"}
SUST_IDS = "|".join(SUST); DIGI_IDS = "|".join(DIGI)


def get(params, tries=4):
    url = BASE + "?" + "&".join(f"{k}={urllib.parse.quote(str(v), safe='|:,')}" for k, v in params.items()) + f"&api_key={KEY}"
    for t in range(tries):
        try:
            with urllib.request.urlopen(urllib.request.Request(url, headers={"User-Agent": "aay-jdse"}), timeout=90) as r:
                return json.load(r)
        except Exception as e:
            print("retry", t, e, file=sys.stderr); time.sleep(3 * (t + 1))
    raise RuntimeError(url)


def groupby(filt, key, name, per_page=200):
    d = get({"filter": filt, "group_by": key, "per_page": per_page})
    rows = [{"key": g["key"], "name": g.get("key_display_name"), "count": g["count"]} for g in d["group_by"]]
    json.dump({"filter": filt, "group_by": key, "total": d["meta"]["count"], "rows": rows}, open(OUT + name + ".json", "w", encoding="utf-8"), indent=1)
    print(name, d["meta"]["count"], len(rows)); return rows


# 1. volume by year, per topic (primary topic) and for the whole sustainable set (any topic)
for tid, nm in SUST.items():
    groupby(f"primary_topic.id:{tid},publication_year:{YEARS},{TYPES}", "publication_year", f"year_{tid}")
groupby(f"topics.id:{SUST_IDS},publication_year:{YEARS},{TYPES}", "publication_year", "year_sust_any")
groupby(f"topics.id:{DIGI_IDS},publication_year:{YEARS},{TYPES}", "publication_year", "year_digi_any")
# 2. the intersection: works carrying both a sustainable and a digital topic
groupby(f"topics.id:{SUST_IDS},topics.id:{DIGI_IDS},publication_year:{YEARS},{TYPES}", "publication_year", "year_intersection")
groupby(f"topics.id:{SUST_IDS},topics.id:{DIGI_IDS},publication_year:{YEARS},{TYPES}", "primary_location.source.id", "venue_intersection")
groupby(f"topics.id:{SUST_IDS},topics.id:{DIGI_IDS},publication_year:{YEARS},{TYPES}", "primary_topic.id", "topic_intersection")
# 3. venues: core sustainable-finance topic, and the wider set, 2016-2026
groupby(f"primary_topic.id:T13146,publication_year:2016-2026,{TYPES}", "primary_location.source.id", "venue_T13146")
groupby(f"primary_topic.id:T10471,publication_year:2016-2026,{TYPES}", "primary_location.source.id", "venue_T10471")
groupby(f"primary_topic.id:{SUST_IDS},publication_year:2016-2026,{TYPES}", "primary_location.source.id", "venue_sust_primary")
groupby(f"primary_topic.id:{SUST_IDS},publication_year:2022-2026,{TYPES}", "primary_location.source.id", "venue_sust_primary_2022")
# 4. countries and institutions
groupby(f"primary_topic.id:{SUST_IDS},publication_year:2016-2026,{TYPES}", "authorships.countries", "country_sust")
groupby(f"primary_topic.id:T13146,publication_year:2016-2026,{TYPES}", "authorships.countries", "country_T13146")
groupby(f"primary_topic.id:{SUST_IDS},authorships.countries:id,publication_year:{YEARS},{TYPES}", "publication_year", "year_sust_id")
groupby(f"primary_topic.id:T13146,authorships.countries:id,publication_year:{YEARS},{TYPES}", "publication_year", "year_T13146_id")
groupby(f"primary_topic.id:{SUST_IDS},authorships.countries:id,publication_year:2016-2026,{TYPES}", "primary_location.source.id", "venue_sust_id")
groupby(f"primary_topic.id:{SUST_IDS},authorships.countries:id,publication_year:2016-2026,{TYPES}", "authorships.institutions.lineage", "inst_sust_id")
groupby(f"primary_topic.id:{SUST_IDS},authorships.countries:id,publication_year:2016-2026,{TYPES}", "primary_topic.id", "topic_sust_id")
groupby(f"primary_topic.id:{SUST_IDS},authorships.countries:id|my|th|vn|ph|sg,publication_year:2016-2026,{TYPES}", "authorships.countries", "country_sust_asean")
groupby(f"primary_topic.id:{SUST_IDS},authorships.countries:id|my|th|vn|ph|sg,publication_year:2016-2026,{TYPES}", "primary_location.source.id", "venue_sust_asean")
# 5. rising keywords: 2015-2018 vs 2023-2026 within the sustainable set
groupby(f"primary_topic.id:{SUST_IDS},publication_year:2015-2018,{TYPES}", "keywords.id", "kw_sust_early")
groupby(f"primary_topic.id:{SUST_IDS},publication_year:2023-2026,{TYPES}", "keywords.id", "kw_sust_late")
groupby(f"primary_topic.id:T13146,publication_year:2015-2018,{TYPES}", "keywords.id", "kw_T13146_early")
groupby(f"primary_topic.id:T13146,publication_year:2023-2026,{TYPES}", "keywords.id", "kw_T13146_late")
# 6. open access and type of venue
groupby(f"primary_topic.id:{SUST_IDS},publication_year:2016-2026,{TYPES}", "open_access.oa_status", "oa_sust")
groupby(f"primary_topic.id:{SUST_IDS},publication_year:2016-2026,{TYPES}", "primary_location.source.type", "srctype_sust")
# 7. citation concentration: top cited works in the core topic (for a 'what gets read' slide)
d = get({"filter": f"primary_topic.id:T13146,publication_year:2016-2026,{TYPES}", "sort": "cited_by_count:desc", "per_page": 100,
         "select": "id,doi,display_name,publication_year,cited_by_count,primary_location,authorships"})
json.dump(d["results"], open(OUT + "top_T13146.json", "w", encoding="utf-8"), indent=1)
print("done")
