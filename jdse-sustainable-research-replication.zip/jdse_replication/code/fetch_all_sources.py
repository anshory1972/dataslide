# Source metadata for every source that appears in the downloaded works (S and D), in parallel batches of 50.
import os as _os, sys as _sys
ROOT = _os.path.dirname(_os.path.dirname(_os.path.abspath(__file__)))  # package root
_sys.stdout.reconfigure(encoding='utf-8', errors='replace')
import glob, gzip, json, sys, time, urllib.request
from concurrent.futures import ThreadPoolExecutor

KEY = _os.environ.get("OPENALEX_API_KEY", "")
D = ROOT + "/data/"
meta = json.load(open(D + "sources_meta.json", encoding="utf-8"))
ids = set()
for f in glob.glob(D + "works/*.jsonl.gz"):
    with gzip.open(f, "rt", encoding="utf-8") as g:
        for line in g:
            s = json.loads(line).get("s")
            if s and s.startswith("S"): ids.add(s)
need = sorted(i for i in ids if i not in meta)
print("sources in works", len(ids), "to fetch", len(need), flush=True)
SEL = "id,display_name,issn_l,issn,type,host_organization_name,country_code,is_oa,is_in_doaj,apc_usd,works_count,cited_by_count,summary_stats,counts_by_year"


def get(url, tries=6):
    for t in range(tries):
        try:
            with urllib.request.urlopen(urllib.request.Request(url, headers={"User-Agent": "aay-jdse"}), timeout=120) as r:
                return json.load(r)
        except Exception as e:
            print("retry", t, str(e)[:80], file=sys.stderr, flush=True); time.sleep(4 * (t + 1))
    raise RuntimeError(url)


def batch(chunk):
    d = get(f"https://api.openalex.org/sources?filter=ids.openalex:{'|'.join(chunk)}&per_page=50&select={SEL}&api_key={KEY}")
    out = {}
    for s in d["results"]:
        cy = sorted([c for c in s.get("counts_by_year", []) if c["works_count"] > 0], key=lambda c: c["year"])
        s["first_year_in_counts"] = cy[0]["year"] if cy else None
        s.pop("counts_by_year", None)
        out[s["id"].split("/")[-1]] = s
    return out


chunks = [need[i:i + 50] for i in range(0, len(need), 50)]
done = 0
with ThreadPoolExecutor(max_workers=8) as ex:
    for out in ex.map(batch, chunks):
        meta.update(out); done += 1
        if done % 50 == 0: print(done, "of", len(chunks), flush=True)
json.dump(meta, open(D + "sources_meta.json", "w", encoding="utf-8"))
print("saved", len(meta))
