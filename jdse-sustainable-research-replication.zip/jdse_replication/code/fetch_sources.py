# Source metadata for every venue that appears in the group_by venue lists, plus the world year series on primary topic.
import os as _os, sys as _sys
ROOT = _os.path.dirname(_os.path.dirname(_os.path.abspath(__file__)))  # package root
_sys.stdout.reconfigure(encoding='utf-8', errors='replace')
import json, glob, os, sys, time, urllib.parse, urllib.request

KEY = _os.environ.get("OPENALEX_API_KEY", "")
OUT = ROOT + "/data/"
ids = set()
for f in glob.glob(OUT + "venue_*.json"):
    for r in json.load(open(f, encoding="utf-8"))["rows"]:
        if r["key"] and r["key"].startswith("https://openalex.org/S"): ids.add(r["key"].split("/")[-1])
ids = sorted(ids); print("venues", len(ids))


def get(url, tries=4):
    for t in range(tries):
        try:
            with urllib.request.urlopen(urllib.request.Request(url, headers={"User-Agent": "aay-jdse"}), timeout=90) as r:
                return json.load(r)
        except Exception as e:
            print("retry", t, e, file=sys.stderr); time.sleep(3 * (t + 1))
    raise RuntimeError(url)


sources = {}
SEL = "id,display_name,issn_l,issn,type,host_organization_name,country_code,is_oa,is_in_doaj,apc_usd,works_count,cited_by_count,summary_stats,counts_by_year"
for i in range(0, len(ids), 50):
    chunk = ids[i:i + 50]
    d = get(f"https://api.openalex.org/sources?filter=ids.openalex:{'|'.join(chunk)}&per_page=50&select={SEL}&api_key={KEY}")
    for s in d["results"]:
        cy = sorted([c for c in s.get("counts_by_year", []) if c["works_count"] > 0], key=lambda c: c["year"])
        s["first_year_in_counts"] = cy[0]["year"] if cy else None
        sources[s["id"].split("/")[-1]] = s
    print(i + len(chunk), len(sources), flush=True)
json.dump(sources, open(OUT + "sources_meta.json", "w", encoding="utf-8"), indent=1)

SUST_IDS = "T13146|T10471|T10119|T12013|T12883|T10115"
d = get(f"https://api.openalex.org/works?filter=primary_topic.id:{SUST_IDS},publication_year:2010-2026,type:article|review&group_by=publication_year&per_page=200&api_key={KEY}")
json.dump({"total": d["meta"]["count"], "rows": [{"key": g["key"], "count": g["count"]} for g in d["group_by"]]}, open(OUT + "year_sust_primary.json", "w"), indent=1)
d = get(f"https://api.openalex.org/works?filter=primary_topic.id:{SUST_IDS},authorships.countries:cn,publication_year:2010-2026,type:article|review&group_by=publication_year&per_page=200&api_key={KEY}")
json.dump({"total": d["meta"]["count"], "rows": [{"key": g["key"], "count": g["count"]} for g in d["group_by"]]}, open(OUT + "year_sust_cn.json", "w"), indent=1)
# Indonesia without the CSR-reporting topic, by year and by venue
d = get(f"https://api.openalex.org/works?filter=primary_topic.id:T13146|T10471|T10119|T12013|T12883,authorships.countries:id,publication_year:2010-2026,type:article|review&group_by=publication_year&per_page=200&api_key={KEY}")
json.dump({"total": d["meta"]["count"], "rows": [{"key": g["key"], "count": g["count"]} for g in d["group_by"]]}, open(OUT + "year_sust_noCSR_id.json", "w"), indent=1)
d = get(f"https://api.openalex.org/works?filter=primary_topic.id:T13146|T10471|T10119|T12013|T12883,authorships.countries:id,publication_year:2016-2026,type:article|review&group_by=primary_location.source.id&per_page=200&api_key={KEY}")
json.dump({"total": d["meta"]["count"], "rows": [{"key": g["key"], "name": g.get("key_display_name"), "count": g["count"]} for g in d["group_by"]]}, open(OUT + "venue_sust_noCSR_id.json", "w"), indent=1)
d = get(f"https://api.openalex.org/works?filter=primary_topic.id:T13146|T10471|T10119|T12013|T12883,publication_year:2010-2026,type:article|review&group_by=publication_year&per_page=200&api_key={KEY}")
json.dump({"total": d["meta"]["count"], "rows": [{"key": g["key"], "count": g["count"]} for g in d["group_by"]]}, open(OUT + "year_sust_noCSR_world.json", "w"), indent=1)
print("done")
