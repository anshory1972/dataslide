# Collect the numbers the deck needs into data/deck_data.json, with their sources.
import os as _os, sys as _sys
ROOT = _os.path.dirname(_os.path.dirname(_os.path.abspath(__file__)))  # package root
_sys.stdout.reconfigure(encoding='utf-8', errors='replace')
import json
D = ROOT + "/data/"
A = json.load(open(D + "analysis.json", encoding="utf-8"))
L = lambda n: json.load(open(D + n + ".json", encoding="utf-8"))
yr = lambda n: {int(k): v for k, v in A[n].items()} if n in A else {int(r["key"]): r["count"] for r in L(n)["rows"] if str(r["key"]).isdigit()}
out = {}
years = list(range(2012, 2026))
out["years"] = years
out["series"] = {"T13146": [yr("year_T13146").get(y, 0) for y in years], "sust_primary": [yr("year_sust_primary").get(y, 0) for y in years],
                 "sust_noCSR_world": [yr("year_sust_noCSR_world").get(y, 0) for y in years], "digi_any": [yr("year_digi_any").get(y, 0) for y in years],
                 "intersection": [yr("year_intersection").get(y, 0) for y in years], "id_all": [yr("year_sust_id").get(y, 0) for y in years],
                 "id_noCSR": [yr("year_sust_noCSR_id").get(y, 0) for y in years], "cn": [yr("year_sust_cn").get(y, 0) for y in years],
                 "T13146_id": [yr("year_T13146_id").get(y, 0) for y in years]}
sc = L("scopus_counts")["rows"]
out["scopus"] = {r["year"]: r for r in sc}
# rising keywords in T13146
def kw(n): d = L(n); return d["total"], {r["name"]: r["count"] for r in d["rows"]}
te, e = kw("kw_T13146_early"); tl, l = kw("kw_T13146_late")
pick = ["green finance", "green bonds", "sustainable finance", "climate finance", "climate risk", "transition risk", "greenwashing", "ESG ratings", "ESG investing", "green credit",
        "financial stability", "emerging markets", "China", "green banking", "climate change mitigation", "sustainable investment", "green innovation", "environmental regulation"]
out["kw_T13146"] = {"early_total": te, "late_total": tl, "rows": [{"kw": k, "early": round(100 * e.get(k, 0) / te, 1), "late": round(100 * l.get(k, 0) / tl, 1)} for k in pick]}
# intersection topics and venues
out["intersection_topics"] = [(r["name"], r["count"]) for r in L("topic_intersection")["rows"][:8]]
out["intersection_total"] = L("topic_intersection")["total"]
# venue tables
def vt(name, n=14):
    rows = [r for r in A[name]["rows"] if r["cls"] != "repository"][:n]
    return [{"name": r["name"], "count": r["count"], "cls": r["cls"], "publisher": r.get("publisher"), "apc": r.get("apc"), "h": r.get("h"), "cite2y": r.get("cite2y"), "first_year": r.get("first_year")} for r in rows]
out["venues_sust"] = vt("venue_sust_primary"); out["venues_T13146"] = vt("venue_T13146"); out["venues_inter"] = vt("venue_intersection", 10)
out["venues_id"] = vt("venue_sust_id", 12); out["venues_id_noCSR"] = vt("venue_sust_noCSR_id", 10)
out["class_shares"] = {k: A[k]["by_class"] for k in ["venue_sust_primary", "venue_T13146", "venue_intersection", "venue_sust_id", "venue_sust_noCSR_id", "venue_sust_asean"]}
# countries
out["countries_sust"] = [(r["name"], r["key"], r["count"]) for r in L("country_sust")["rows"][:15]]
out["countries_T13146"] = [(r["name"], r["key"], r["count"]) for r in L("country_T13146")["rows"][:15]]
out["country_totals"] = {"sust": L("country_sust")["total"], "T13146": L("country_T13146")["total"]}
out["inst_id"] = [(r["name"], r["count"]) for r in L("inst_sust_id")["rows"][:12]]
out["topic_id"] = [(r["name"], r["count"]) for r in L("topic_sust_id")["rows"]]
out["oa"] = {r["key"]: r["count"] for r in L("oa_sust")["rows"]}; out["oa_total"] = L("oa_sust")["total"]
# launched journals benchmark (indexed ones, with years to index)
out["launched"] = [{"name": r["name"], "first_year": r["first_year"], "cls": r["cls"], "cov_first": r.get("cov_first"), "apc": r.get("apc"), "h": r.get("h"), "cite2y": r.get("cite2y"), "publisher": r.get("publisher")}
                   for r in A["launched_2010plus"] if r["cls"] in ("Q1", "Q2", "Q3") and r.get("cov_first")]
# journal benchmarks
out["bmeb"] = {"topics": [(r["name"], r["count"]) for r in L("bmeb_topics")["rows"][:8]], "countries": [(r["name"], r["count"]) for r in L("bmeb_countries")["rows"][:6]], "works_2016_26": L("bmeb_topics")["total"]}
out["jsfi_countries"] = [(r["name"], r["count"]) for r in L("jsfi_countries")["rows"][:6]]
out["jcf_countries"] = [(r["name"], r["count"]) for r in L("jcf_countries")["rows"][:6]]
top = json.load(open(D + "top_T13146.json", encoding="utf-8"))
out["top_cited"] = [{"title": w["display_name"], "year": w["publication_year"], "cites": w["cited_by_count"], "venue": ((w.get("primary_location") or {}).get("source") or {}).get("display_name"),
                     "authors": ", ".join(a["author"]["display_name"] for a in w.get("authorships", [])[:3])} for w in top[:12]]
json.dump(out, open(D + "deck_data.json", "w", encoding="utf-8"), indent=1, ensure_ascii=False)
print("ok", {k: (len(v) if hasattr(v, "__len__") else v) for k, v in out.items()})
