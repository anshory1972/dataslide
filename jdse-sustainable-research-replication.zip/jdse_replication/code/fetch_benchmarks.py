# Benchmark journal profiles from OpenAlex (group_by queries, all document types).
#   BMEB  = Bulletin of Monetary Economics and Banking (Bank Indonesia), source S4210240883
#   JSFI  = Journal of Sustainable Finance & Investment, source S4210206470
#   JCF   = Journal of Climate Finance, source S4387285669
# Output: data/bmeb_topics.json, bmeb_years.json, bmeb_countries.json, jsfi_*.json, jcf_*.json
import os as _os, sys as _sys
ROOT = _os.path.dirname(_os.path.dirname(_os.path.abspath(__file__)))  # package root
_sys.stdout.reconfigure(encoding='utf-8', errors='replace')
import json, urllib.request
KEY = _os.environ.get("OPENALEX_API_KEY", "")
D = ROOT + "/data/"


def gb(filt, key, name):
    u = f"https://api.openalex.org/works?filter={filt}&group_by={key}&per_page=200&api_key={KEY}"
    d = json.load(urllib.request.urlopen(u, timeout=90))
    rows = [{"key": g["key"], "name": g.get("key_display_name"), "count": g["count"]} for g in d["group_by"]]
    json.dump({"total": d["meta"]["count"], "rows": rows}, open(D + name + ".json", "w", encoding="utf-8"), indent=1)
    print(name, d["meta"]["count"])


gb("primary_location.source.id:S4210240883,publication_year:2016-2026", "primary_topic.id", "bmeb_topics")
gb("primary_location.source.id:S4210240883,publication_year:2010-2026", "publication_year", "bmeb_years")
gb("primary_location.source.id:S4210240883,publication_year:2016-2026", "authorships.countries", "bmeb_countries")
for sid, nm in [("S4210206470", "jsfi"), ("S4387285669", "jcf")]:
    gb(f"primary_location.source.id:{sid},publication_year:2016-2026", "authorships.countries", nm + "_countries")
    gb(f"primary_location.source.id:{sid},publication_year:2010-2026", "publication_year", nm + "_years")
