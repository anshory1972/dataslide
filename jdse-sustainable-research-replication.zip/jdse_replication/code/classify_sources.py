# Two helpers used by the analysis scripts.
import re

MEGA_PUBLISHERS = {
    "mdpi": "MDPI",
    "multidisciplinary digital publishing": "MDPI",
    "frontiers": "Frontiers",
    "hindawi": "Hindawi",
    "scientific research publishing": "SCIRP",
    "public library of science": "PLOS",
    "faculty of 1000": "F1000",
}

# Broad-scope, high-volume venues that are not identifiable from the publisher. Matched on journal title.
MEGA_JOURNALS = {
    "heliyon", "scientific reports", "ieee access", "peerj", "cureus",
    "sn applied sciences", "results in engineering",
    "social sciences & humanities open", "f1000research",
}


def is_mega_journal(title):
    t = (title or "").strip().lower()
    return t in MEGA_JOURNALS or t.startswith("discover ")


def norm_issn(s):
    """'1542-4863' / '15424863' / ' 1542486x ' -> '1542486X'. '' if unusable."""
    if not s:
        return ""
    s = re.sub(r"[^0-9Xx]", "", str(s)).upper()
    return s if len(s) == 8 else ""
