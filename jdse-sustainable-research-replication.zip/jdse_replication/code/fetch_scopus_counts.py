# Scopus Search API counts by year: sustainable finance keyword set, world and Indonesia. Cross-check for the OpenAlex topic corpus.
import os as _os, sys as _sys
ROOT = _os.path.dirname(_os.path.dirname(_os.path.abspath(__file__)))  # package root
_sys.stdout.reconfigure(encoding='utf-8', errors='replace')
import json, time, urllib.parse, urllib.request

KEY = _os.environ["SCOPUS_API_KEY"]
Q = 'TITLE-ABS-KEY("sustainable finance" OR "green finance" OR "green bond*" OR "climate finance" OR "ESG investing" OR "ESG performance" OR "ESG disclosure" OR "ESG rating*" OR "sustainable banking" OR "transition risk" OR "carbon pricing" OR "green credit")'
OUT = ROOT + "/data/scopus_counts.json"


def count(q):
    url = "https://api.elsevier.com/content/search/scopus?query=" + urllib.parse.quote(q) + "&count=1"
    req = urllib.request.Request(url, headers={"X-ELS-APIKey": KEY, "Accept": "application/json"})
    with urllib.request.urlopen(req, timeout=60) as r:
        return int(json.load(r)["search-results"]["opensearch:totalResults"])


rows = []
for y in range(2010, 2027):
    base = f"{Q} AND PUBYEAR = {y} AND DOCTYPE(ar OR re)"
    w = count(base); time.sleep(0.4)
    i = count(base + " AND AFFILCOUNTRY(Indonesia)"); time.sleep(0.4)
    a = count(base + " AND AFFILCOUNTRY(Indonesia OR Malaysia OR Thailand OR Vietnam OR Philippines OR Singapore)"); time.sleep(0.4)
    rows.append({"year": y, "world": w, "indonesia": i, "asean6": a}); print(y, w, i, a, flush=True)
json.dump({"query": Q, "rows": rows}, open(OUT, "w"), indent=1)
print("done")
