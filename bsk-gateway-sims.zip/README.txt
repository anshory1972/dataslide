BSK IMPORT-GATEWAY SIMULATIONS -- IndoTERM 23 commodities x 7 regions
====================================================================

WHAT THIS IS
------------
Eight comparative-static experiments on the relocation of import
gateways to Bitung (SulUt), Kupang (NTT) and Sorong (PapuaBar):
seven single-commodity runs and one combined run.

Each experiment cuts import LANDINGS by 95 per cent in the non-port
regions and holds the commodity's NATIONAL import volume fixed, so the
displaced volume must enter through the three gateway ports.

The shock is on landings (xtrad_d, the ORG dimension of the trade
matrix), NOT on imports used in a region (ximps). The announced policy
concerns where goods enter the country, not where they are consumed.


CONTENTS
--------
  TERM.exe          the compiled model, ready to run as shipped
  TERM.axs          auxiliary statement files the exe needs at run time
  TERM.axt          (Auxiliary files = term; in every cmf refers to these)
  TERM.min
  TERM.TAB          model source, INCLUDING the fxtrad_d extension
                    (see below) -- only needed if you rebuild
  term0.tab         the unmodified original, for reference/diff only
  aggmod.har        model database, 23 com x 7 reg, WITH the 1 per cent
                    gateway seed already applied
  AGGSETS.HAR       set definitions for the database

  gw_apparel.cmf        Apparel
  gw_tanning.cmf        Tanning (leather tanning)
  gw_leatherprd.cmf     Leather products
  gw_footwear.cmf       Footwear
  gw_cosmetics.cmf      Cosmetics
  gw_ceramics.cmf       Ceramics (ClayCermcPrd)
  gw_electronics.cmf    Electronics
  gw_all7.cmf           all seven together
  mkcmfs.sh             regenerates the eight cmf files at any shock size

  regsupmod1pc.tab  the database-seeding program (1 per cent per port)
  regsupmod1pc.cmf  its command file
  rnregsupmod.bat   driver: backs up regsupp.har, runs TABLO + GEMSIM
                    on regsupmod1pc, then puts regsupp_1pc.har in place
                    (these three are provided so the seeding step is
                    reproducible; they are NOT needed to run the
                    simulations, since aggmod.har is already seeded)


HOW TO RUN
----------
  1. Nothing to build -- TERM.exe and its auxiliary files (axs, axt,
     min) are included. All four must sit in the same folder as the
     cmf files; every cmf begins "Auxiliary files = term;" and the run
     aborts immediately with "Unable to open Auxiliary Statement file"
     if the ax* files are missing.

     Only if you change TERM.TAB, rebuild from a Windows shell with:
         tabltg TERM
     which runs TABLO then LTG. Do not use plain "ltg" -- it deletes
     the exe before checking for the .for file.

  2. Run any experiment:
         TERM -cmf gw_all7.cmf

     Each run writes <name>.sl4 (solution), <name>.log and <name>.slc.
     Solve method is Gragg 8-16-24 with five subintervals; a run takes
     roughly half a minute.

  3. Read results, e.g.:
         sltoht gw_all7.sl4          (makes gw_all7.sol)
         har2txt gw_all7.sol out.txt 0021


VERIFIED RESULTS (as shipped, -95 per cent)
-------------------------------------------
  file              residual     GDP     CPI    Bitung  Kupang  Sorong
  gw_apparel      3.3e-06      -0.10   +0.08    -0.18   -0.27   -0.17
  gw_tanning      3.5e-06      -0.06   +0.00    +0.01   +0.02   +0.01
  gw_leatherprd   2.8e-06      -0.03   +0.05    +0.02   +0.01   +0.00
  gw_footwear     8.3e-07      -0.08   +0.04    -0.06   -0.06   -0.06
  gw_cosmetics    3.5e-05      -0.11   +0.13    -0.05   -0.09   -0.03
  gw_ceramics     3.2e-07      -0.06   +0.06    -0.05   -0.06   -0.09
  gw_electronics  1.5e-04      -2.63   +2.05    +1.82   +2.41   +3.59
  gw_all7         1.6e-06      -3.05   +2.46    +1.52   +1.99   +3.36

  GDP and CPI are national, per cent change; the three port columns are
  regional real GDP. National import volume of each target commodity is
  held exactly fixed (|natximp| = 0.000000 in every run).


THE TERM.TAB EXTENSION
----------------------
Standard TERM cannot hold landings on a chosen path: xtrad is
substituted out of the system, and xtrad_d is backsolved. Two changes:

  1. "Backsolve xtrad_d using E_xtrad_d" is disabled, keeping xtrad_d
     in the condensed system so it can be swapped.
  2. A new variable fxtrad_d(c,s,r) -- a route-cost shifter by origin
     region, uniform over destinations -- is added wherever atrad
     appears, in BOTH E_puse (the price index) and E_xtrad (route
     demand).

The price term is essential. A version that entered the quantity
equation only solved, then failed the use-equals-deliveries check
(RATB): quantities rationed without a price signal drift away from
purchases. Entering exactly like atrad keeps the accounts closed and
makes the instrument an iceberg cost, so GDP losses are an UPPER bound
(a rent-generating instrument would show smaller losses).

Closure additions used by every cmf:
     Exogenous fxtrad_d;
     swap fxtrad_d(...) = xtrad_d(...);      ! positive base cells only
     shock xtrad_d(...) = uniform -95;
     swap tuser_ud(...) = natximp(...);      ! hold national imports


THE DATABASE SEED -- IMPORTANT ASSUMPTION
-----------------------------------------
In the source data, most gateway routes do not exist: base landings of
the announced goods at the three ports are zero or negligible (0.02 to
0.64 per cent of national). A percentage-change CGE model cannot grow
a cell whose base value is zero, so the policy cannot be simulated
without a seeding assumption.

aggmod.har here has been seeded so that EACH port starts with 1 per
cent of national landings of each announced commodity (3 per cent
combined). The seed is applied upstream, to the MSHR port-share matrix
in regsupp.har, so the data pipeline itself rebuilds trade routes,
margins and balances, and the standard checks (CHKMDA/B) certify every
accounting identity. Nothing is edited by hand.

Every result therefore rests on this assumption, and it matters a great
deal -- it fixes how much traffic each gateway can absorb before the
accounting identities break. On this database all eight experiments are
feasible to -95 per cent and beyond (-99 also solves), and the port
provinces gain. Report the seed alongside the results, and treat the
gains as conditional on gateways of that size existing.

The target share is a single editable constant (TARGET in
regsupmod1pc.tab). To test sensitivity, change it, rerun
rnregsupmod.bat, then mkdata.bat and doagg, and rerun the experiments.

Zero cells that remain: Tanning and Cosmetics have exactly zero base
landings in Kalimantan, so that region is excluded from their swap sets
(a zero cell would make the LHS matrix singular). This is why those two
cmf files use a three-region west set.


CAUTION ON DYNAMICS
-------------------
Do not take this straight into RunDynam. Even one-period solves need
Gragg with five subintervals, because reallocations are large relative
to the seeded cells. In a year-on-year sequence those changes compound,
and one assertion failure aborts the whole run. If dynamics is pursued,
aggregating the commodities is a must, and seed larger initial flows.


Model: IndoTERM (TERM family), GEMPACK 12.2, short-run closure.
Data build: COPS tpmh0197 / tpmh0198 packages, sec23_dkem x reg7
aggregation. Prepared 20 August 2026.
