rem  Seed BSK import landings at 1 per cent of national landings per port.
rem  Backs up the original as regsupp_old.har (kept on reruns), implements
rem  regsupmod1pc.tab with TABLO and runs it with GEMSIM:
rem    regsupp_old.har + national.har + sec23_dkem.agg  ->  regsupp_1pc.har
rem  then puts the seeded file in place as regsupp.har.
rem  The target share is the TARGET constant in regsupmod1pc.tab (0.01).
rem  Run BEFORE mkdata.bat / doagg so the pipeline builds on seeded shares.

if not exist regsupp_old.har copy regsupp.har regsupp_old.har
if exist regsupp_1pc.har del regsupp_1pc.har

tablo -pgs regsupmod1pc
if errorlevel 1 goto error

gemsim -cmf regsupmod1pc.cmf
if errorlevel 1 goto error

if not exist regsupp_1pc.har goto error
copy /y regsupp_1pc.har regsupp.har
if errorlevel 1 goto error

echo REGSUPMOD1PC FINISHED OK -- regsupp.har now carries the 1 per cent seed
dir regsupp*.har
goto endbat

:error
echo ###### ERROR: BATCH JOB FAILED #####
echo Check log file; most recent is listed last
dir/od *.log

:endbat
