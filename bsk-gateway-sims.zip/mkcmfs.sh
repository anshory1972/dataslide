#!/bin/sh
# Generate the eight gateway experiment command files on the 1%-seed database:
# seven single-product runs plus one combined run.
# Shock size is set by SHOCK below (the drill found -95% feasible for all).
cd "$(dirname "$0")"
HDR=82
SHOCK=95

# product | westset | filename | pretty name | port(Rp bn each) | national
LIST="Apparel|4|gw_apparel.cmf|Apparel|92.7|9265
Tanning|3|gw_tanning.cmf|Tanning (leather tanning)|59.5|5952
LeatherPrd|4|gw_leatherprd.cmf|Leather products|36.2|3616
Footwear|4|gw_footwear.cmf|Footwear|75.3|7527
Cosmetics|3|gw_cosmetics.cmf|Cosmetics|75.8|7582
ClayCermcPrd|4|gw_ceramics.cmf|Ceramics|75.4|7536
ElectroncPrd|4|gw_electronics.cmf|Electronics|1586.9|158688"

echo "$LIST" | while IFS='|' read PROD W FILE NAME PORTBN NATL; do
  head -n $HDR gateway7.cmf > "$FILE"
  if [ "$W" = "4" ]; then
    WSET='(Sumatra, Jawa, Kalimantan, ROI)'
    WNOTE='all four non-port regions have positive base landings'
  else
    WSET='(Sumatra, Jawa, ROI)'
    WNOTE='Kalimantan excluded: base landings are exactly zero, and a zero
!   cell cannot be swapped (the LHS matrix would be singular)'
  fi
  cat >> "$FILE" <<EOF

! ==================================================================
! GATEWAY EXPERIMENT -- $NAME, single commodity
!
! Cut import LANDINGS of $PROD by $SHOCK per cent in the
! non-port regions, holding the commodity's NATIONAL import volume
! fixed, so the displaced volume must land at Bitung (SulUt),
! Kupang (NTT) or Sorong (PapuaBar).
!
! West set: $WNOTE.
!
! Database: 1 per cent seed per port (regsupmod1pc.tab), so each
! gateway starts from Rp $PORTBN bn of $PROD landings against
! Rp $NATL bn nationally -- 3 per cent combined.
!
! Requires the fxtrad_d extension to TERM.TAB.
! To vary the experiment, change the "uniform" value below.
! ==================================================================
Exogenous fxtrad_d;

xset ONE ($PROD);
xsubset ONE is subset of COM;

xset R3 # Bitung, Kupang, Sorong # (SulUt, NTT, PapuaBar);
xsubset R3 is subset of ORG;
xset WCUT # regions whose landings are cut # $WSET;
xsubset WCUT is subset of ORG;

! quantity of landings becomes exogenous, the route-cost shifter endogenous
swap fxtrad_d(ONE,"imp",WCUT) = xtrad_d(ONE,"imp",WCUT);
shock xtrad_d(ONE,"imp",WCUT) = uniform -$SHOCK;

! hold the national import volume: BSK must absorb the difference
swap tuser_ud(ONE,"imp") = natximp(ONE);
EOF
  echo "wrote $FILE"
done

# ---------------- combined ----------------
FILE=gw_all7.cmf
head -n $HDR gateway7.cmf > "$FILE"
cat >> "$FILE" <<EOF

! ==================================================================
! GATEWAY EXPERIMENT -- all seven announced commodities together
!
! Cut import LANDINGS by $SHOCK per cent in the non-port regions for
! every announced commodity at once, each commodity's NATIONAL import
! volume held fixed, so Bitung, Kupang and Sorong absorb the lot.
!
! Two west sets are needed: Tanning and Cosmetics have exactly zero
! base landings in Kalimantan, so that cell cannot be swapped.
!
! Database: 1 per cent seed per port (regsupmod1pc.tab); every
! commodity starts at 3 per cent combined BSK share.
!
! Requires the fxtrad_d extension to TERM.TAB.
! ==================================================================
Exogenous fxtrad_d;

xset POLICY7 # the announced commodities #
(Apparel, Tanning, LeatherPrd, Footwear, Cosmetics,
 ClayCermcPrd, ElectroncPrd);
xsubset POLICY7 is subset of COM;

xset P4 # positive landings in all four non-port regions #
(Apparel, LeatherPrd, Footwear, ClayCermcPrd, ElectroncPrd);
xsubset P4 is subset of COM;
xset P2 # zero landings in Kalimantan #
(Tanning, Cosmetics);
xsubset P2 is subset of COM;

xset R3 # Bitung, Kupang, Sorong # (SulUt, NTT, PapuaBar);
xsubset R3 is subset of ORG;
xset W4 (Sumatra, Jawa, Kalimantan, ROI);
xsubset W4 is subset of ORG;
xset W3 (Sumatra, Jawa, ROI);
xsubset W3 is subset of ORG;

swap fxtrad_d(P4,"imp",W4) = xtrad_d(P4,"imp",W4);
swap fxtrad_d(P2,"imp",W3) = xtrad_d(P2,"imp",W3);

shock xtrad_d(P4,"imp",W4) = uniform -$SHOCK;
shock xtrad_d(P2,"imp",W3) = uniform -$SHOCK;

swap tuser_ud(POLICY7,"imp") = natximp(POLICY7);
EOF
echo "wrote $FILE"
