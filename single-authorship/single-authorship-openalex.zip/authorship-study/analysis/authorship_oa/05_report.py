"""Build the report page (one self-contained HTML file) and the replication zip.

Reads the tables from 03_tables.py; makes no API calls.

Outputs:
  out/authorship_oa/single-authorship.html
  out/authorship_oa/single-authorship-og-<hash>.jpg  1200x630 preview image for link sharing
  out/authorship_oa/single-authorship-openalex.zip   code, processed counts, tables

Needs the tables from 03_tables.py and 04_reasons.py.

Title image: assets/hero.jpg if it exists (for example a Midjourney illustration), otherwise a
plain graphic drawn here. The preview image puts the title on the left and the same image on
the right, as on the other Dataslide pages.
"""
from __future__ import annotations

import base64
import hashlib
import io
import json
import zipfile
from pathlib import Path

import pandas as pd
from PIL import Image, ImageDraw, ImageFont

from config import EARLY_WINDOW, MIN_ARTICLES, OUT, PROC, ROOT, WINDOW

TAB = OUT / "tables"
HERE = Path(__file__).resolve().parent
PAGE = OUT / "single-authorship.html"
ZIP = OUT / "single-authorship-openalex.zip"
ZIP_URL = "single-authorship/single-authorship-openalex.zip"   # path on the published site
HERO_FILE = HERE / "assets" / "hero.jpg"
HERO_ALT_FILE = HERE / "assets" / "hero_alt.txt"
HERO_SIZE = (944, 800)                    # width x height, about 6:5
OG_DESC = ("In ten subfields, most of them in the humanities, most articles in top-quarter journals have had one author in "
           "every year since 2000. OpenAlex data, reasons and sources, code to replicate. Arief Anshory Yusuf.")

PAPER, SURFACE, INK, MUTED, ACCENT = "#fffdf9", "#fffdf9", "#14161c", "#6d6a63", "#b4451f"
FONTS = Path("C:/Windows/Fonts")


def font(name: str, size: int):
    for cand in (FONTS / name, Path("/usr/share/fonts/truetype/dejavu") / "DejaVuSans.ttf"):
        if cand.exists():
            return ImageFont.truetype(str(cand), size)
    return ImageFont.load_default()

FOCUS_MIN_YEARS = "all"        # focus subfields: above one half in every year of YEARS


def r(x, n=4):
    return None if pd.isna(x) else round(float(x), n)


def data() -> dict:
    snap = json.loads((PROC / "snapshot.json").read_text())
    bench = pd.read_csv(TAB / "benchmark.csv")
    sub = pd.read_csv(TAB / "subfields.csv")
    reasons = pd.read_csv(TAB / "reasons.csv")
    tx = pd.read_parquet(PROC / "taxonomy.parquet").set_index("subfield_id")
    win = f"{WINDOW[0]}-{WINDOW[1]}"

    bq = bench[(bench.tier == "q1") & (bench.period == win)].iloc[0]

    # subfields where most articles in top-quarter journals have one author, headline window
    q = sub[(sub.tier == "q1") & (sub.pos >= MIN_ARTICLES)].sort_values("share", ascending=False)
    dom = q[q.share > 0.5]
    dominant = [{"s": x.subfield, "f": x.field, "n": int(x.pos), "v": r(x.share), "v5": r(x.share_ref5)}
                for x in dom.itertuples()]

    # yearly shares; focus = dominant subfields above one half in every year
    c = pd.read_parquet(PROC / "counts_subfield.parquet")
    c = c[(c.tier == "q1") & c.variant.isin(["pos", "one"])]
    yr = c.pivot_table(index=["id", "period"], columns="variant", values="n", aggfunc="sum").reset_index()
    yr["share"] = yr.one / yr.pos
    yr["year"] = yr.period.astype(int)
    yr["subfield"] = yr.id.map(tx.subfield)
    always = yr.groupby("subfield").share.min()
    focus_names = [s for s in dom.subfield if always.get(s, 0) > 0.5]

    piv = sub.pivot_table(index="subfield", columns="tier", values=["pos", "share", "share_ref5"])
    focus = []
    for s in focus_names:
        x = piv.loc[s]
        ser = yr[yr.subfield == s].sort_values("year")
        focus.append({"s": s, "n": int(x[("pos", "q1")]), "v": r(x[("share", "q1")]), "v5": r(x[("share_ref5", "q1")]),
                      "all": r(x[("share", "all")]), "core": r(x[("share", "core")]),
                      "series": [[int(z.year), r(z.share), int(z.pos)] for z in ser.itertuples()]})

    rs = reasons.set_index("subfield")
    tot = reasons[["pos", "funded", "multi_inst", "books", "articles_any"]].sum()
    reason = {s: {"funded": r(rs.loc[s, "share_funded"]), "multi_inst": r(rs.loc[s, "share_multi_inst"]),
                  "books": r(rs.loc[s, "share_books"])} for s in focus_names}
    reason["all"] = {"funded": r(tot.funded / tot.pos), "multi_inst": r(tot.multi_inst / tot.pos),
                     "books": r(tot.books / (tot.books + tot.articles_any))}

    from importlib import import_module
    rmod = import_module("04_reasons")
    cy, by = rmod.CITE_YEARS, rmod.BOOK_YEARS
    return {
        "snapshot": snap, "window": win, "min_articles": MIN_ARTICLES,
        "cite_years": f"{cy[0]}-{cy[1]}", "book_years": f"{by[0]}-{by[1]}",
        "bench": {"win": r(bq.share), "win5": r(bq.share_ref5), "n": int(bq.pos)},
        "dominant": dominant, "focus": focus, "reasons": reason, "zip_url": ZIP_URL,
        "fieldOf": {s: sub[sub.subfield == s].field.iloc[0] for s in focus_names},
    }


def drawn_hero(philosophy: float, overall: float) -> Image.Image:
    """Two grids of 100 squares: articles with one author per 100, philosophy and all fields."""
    w, h = HERO_SIZE
    im = Image.new("RGB", (w, h), "#c4512a")
    d = ImageDraw.Draw(im)
    cream, faint = (255, 246, 236), (214, 120, 84)
    cell, gap = 26, 8
    grid = 10 * cell + 9 * gap
    lab, num = font("segoeuib.ttf", 26), font("georgiab.ttf", 64)
    for k, (title, v) in enumerate((("Philosophy", philosophy), ("All fields", overall))):
        x0 = 70 + k * (grid + 90)
        y0 = 260
        filled = round(100 * v)
        for i in range(100):
            r, c = divmod(i, 10)
            x, y = x0 + c * (cell + gap), y0 + r * (cell + gap)
            d.rounded_rectangle([x, y, x + cell, y + cell], 4, fill=cream if i < filled else faint)
        d.text((x0, 120), f"{filled} in 100", font=num, fill=cream)
        d.text((x0, 205), title.upper(), font=lab, fill=cream)
    d.text((70, h - 70), "Articles with one author, top-quarter journals, 2021–2025", font=font("segoeui.ttf", 22), fill=cream)
    return im


def hero_image(d: dict) -> tuple[Image.Image, str]:
    if HERO_FILE.exists():
        im = Image.open(HERO_FILE).convert("RGB")
        alt = HERO_ALT_FILE.read_text(encoding="utf-8").strip() if HERO_ALT_FILE.exists() else "Illustration"
        # centre-crop to the title-image shape
        tw, th = HERO_SIZE
        s = max(tw / im.width, th / im.height)
        im = im.resize((round(im.width * s), round(im.height * s)), Image.LANCZOS)
        l, tp = (im.width - tw) // 2, (im.height - th) // 2
        return im.crop((l, tp, l + tw, tp + th)), alt
    phil = next(x["v"] for x in d["dominant"] if x["s"] == "Philosophy")
    alt = (f"Two grids of 100 squares: {round(100 * phil)} in 100 philosophy articles and "
           f"{round(100 * d['bench']['win'])} in 100 articles in all fields have one author")
    return drawn_hero(phil, d["bench"]["win"]), alt


def og_image(hero: Image.Image) -> Image.Image:
    W, H, left = 1200, 630, 456
    im = Image.new("RGB", (W, H), "#fdf6ef")
    right = hero.copy()
    s = max((W - left) / right.width, H / right.height)
    right = right.resize((round(right.width * s), round(right.height * s)), Image.LANCZOS)
    l, tp = (right.width - (W - left)) // 2, (right.height - H) // 2
    im.paste(right.crop((l, tp, l + W - left, tp + H)), (left, 0))
    d = ImageDraw.Draw(im)
    d.text((50, 150), "DATASLIDE · RESEARCH AND PUBLISHING", font=font("segoeuib.ttf", 16), fill="#9a5a3c")
    d.multiline_text((50, 182), "Single authorship\nis still the norm\nin the humanities", font=font("georgiab.ttf", 40), fill="#1a1410", spacing=6)
    d.rectangle([50, 356, 94, 359], fill=ACCENT)
    d.multiline_text((50, 376), "Most articles have one author,\nevery year since 2000", font=font("segoeui.ttf", 19), fill=ACCENT, spacing=6)
    d.text((50, 478), "Arief Anshory Yusuf", font=font("segoeuib.ttf", 18), fill="#1a1410")
    d.text((50, 504), "SDGs Center, Universitas Padjadjaran", font=font("segoeui.ttf", 15), fill="#6d5f55")
    return im


def jpeg_bytes(im: Image.Image, q: int = 86) -> bytes:
    b = io.BytesIO()
    im.save(b, "JPEG", quality=q, optimize=True, progressive=True)
    return b.getvalue()


def build_zip() -> list[str]:
    files = []
    with zipfile.ZipFile(ZIP, "w", zipfile.ZIP_DEFLATED) as z:
        for p in sorted(HERE.glob("*.py")) + [HERE / "README.md", HERE / "report_template.html"]:
            z.write(p, f"authorship-study/analysis/authorship_oa/{p.name}")
            files.append(f"analysis/authorship_oa/{p.name}")
        z.writestr("authorship-study/requirements.txt", "pandas>=2.2\npyarrow>=15\nrequests>=2.31\n")
        z.writestr("authorship-study/.env.example", "OPENALEX_API_KEY=your_key_here\n")
        files += ["requirements.txt", ".env.example"]
        # processed counts let 03_tables.py and 04_report.py run without any API call;
        # collections.json is left out so a replicator's 01_journals.py makes its own collection
        for p in sorted(PROC.glob("*")):
            if p.name == "collections.json":
                continue
            z.write(p, f"authorship-study/data/authorship_oa/processed/{p.name}")
            files.append(f"data/authorship_oa/processed/{p.name}")
        for p in sorted(TAB.glob("*")):
            z.write(p, f"authorship-study/out/authorship_oa/tables/{p.name}")
            files.append(f"out/authorship_oa/tables/{p.name}")
    return files


def main():
    d = data()
    files = build_zip()
    d["zip_files"] = files
    d["zip_mb"] = round(ZIP.stat().st_size / 1e6, 1)
    hero, alt = hero_image(d)
    hero_b = jpeg_bytes(hero, 84)
    og_b = jpeg_bytes(og_image(hero), 86)
    for old in OUT.glob("single-authorship-og-*.jpg"):
        old.unlink()
    og_name = f"single-authorship-og-{hashlib.sha256(og_b).hexdigest()[:8]}.jpg"   # new name when the image changes
    (OUT / og_name).write_bytes(og_b)
    html = (HERE / "report_template.html").read_text(encoding="utf-8")
    html = (html.replace("/*__DATA__*/null", json.dumps(d, ensure_ascii=False))
                .replace("__HERO_SRC__", "data:image/jpeg;base64," + base64.b64encode(hero_b).decode())
                .replace("__HERO_ALT__", alt.replace('"', "&quot;"))
                .replace("__HERO_W__", str(HERO_SIZE[0])).replace("__HERO_H__", str(HERO_SIZE[1]))
                .replace("__OG_DESC__", OG_DESC).replace("__OG_FILE__", og_name))
    PAGE.write_text(html, encoding="utf-8")
    print(f"wrote {PAGE.name} ({PAGE.stat().st_size / 1e3:.0f} kB), {og_name} ({len(og_b) / 1e3:.0f} kB), "
          f"{ZIP.name} ({d['zip_mb']} MB, {len(files)} files)")


if __name__ == "__main__":
    main()
