"""Why single authorship persists: funding, collaboration, citations and books, by subfield.

All counts are OpenAlex group_by queries by primary-topic subfield.

Articles in top-quarter journals published in CITE_YEARS (old enough to have citations):
  pos           at least one author
  one           exactly one author
  multi         two or more authors
  funded        at least one funder listed (funders.id:!null)
  multi_inst    two or more institutions
  one_cited5    one author and at least 5 citations
  multi_cited5  two or more authors and at least 5 citations
All works (any source) published in BOOK_YEARS:
  books         type book or book-chapter
  articles_any  type article

Output: data/authorship_oa/processed/reasons.parquet, out/authorship_oa/tables/reasons.csv
"""
from __future__ import annotations

import json
import sys

import pandas as pd

import oa
from config import BASE, OUT, PROC, RAW

CITE_YEARS = (2019, 2021)
BOOK_YEARS = (2021, 2025)

Q1_QUERIES = {
    "pos": "authors_count:>0",
    "one": "authors_count:1",
    "multi": "authors_count:>1",
    "funded": "authors_count:>0,funders.id:!null",
    "multi_inst": "authors_count:>0,institutions_distinct_count:>1",
    "one_cited5": "authors_count:1,cited_by_count:>4",
    "multi_cited5": "authors_count:>1,cited_by_count:>4",
}
ALL_QUERIES = {
    "books": "type:book|book-chapter",
    "articles_any": "type:article",
}


def main():
    col = json.loads((PROC / "collections.json").read_text())["q1"]
    q1 = f"{BASE},primary_location.source.id:{col},publication_year:{CITE_YEARS[0]}-{CITE_YEARS[1]}"
    rows = []
    try:
        for k, extra in Q1_QUERIES.items():
            g = oa.group_by_all(f"{q1},{extra}", "primary_topic.subfield.id", RAW / "reasons" / f"q1_{k}.json")
            rows += [(k, oa.short(x["key"]), x["count"]) for x in g]
            print(f"{k:13s} {sum(x['count'] for x in g):10,}  credits {oa.CREDITS}", flush=True)
        for k, f in ALL_QUERIES.items():
            g = oa.group_by_all(f"{f},publication_year:{BOOK_YEARS[0]}-{BOOK_YEARS[1]}",
                                "primary_topic.subfield.id", RAW / "reasons" / f"all_{k}.json")
            rows += [(k, oa.short(x["key"]), x["count"]) for x in g]
            print(f"{k:13s} {sum(x['count'] for x in g):10,}  credits {oa.CREDITS}", flush=True)
    except oa.BudgetExhausted as e:
        print("stopped on the OpenAlex daily budget; rerun after midnight UTC to continue.\n", e)
        sys.exit(2)

    df = pd.DataFrame(rows, columns=["measure", "subfield_id", "n"])
    df.to_parquet(PROC / "reasons.parquet", index=False)
    w = df.pivot_table(index="subfield_id", columns="measure", values="n", fill_value=0).reset_index()
    w.columns.name = None
    tx = pd.read_parquet(PROC / "taxonomy.parquet")
    w = w.merge(tx, on="subfield_id", how="left")
    w["share_single"] = w.one / w.pos
    w["share_funded"] = w.funded / w.pos
    w["share_multi_inst"] = w.multi_inst / w.pos
    w["cited5_single"] = w.one_cited5 / w.one
    w["cited5_multi"] = w.multi_cited5 / w.multi
    w["cite_ratio"] = w.cited5_single / w.cited5_multi        # 1 = no citation gap
    w["share_books"] = w.books / (w.books + w.articles_any)
    w.to_csv(OUT / "tables" / "reasons.csv", index=False)
    print(w.sort_values("share_single", ascending=False).head(15)[
        ["subfield", "pos", "share_single", "share_funded", "share_multi_inst", "cite_ratio", "share_books"]].round(3).to_string(index=False))
    print("credits:", oa.CREDITS)


if __name__ == "__main__":
    main()
