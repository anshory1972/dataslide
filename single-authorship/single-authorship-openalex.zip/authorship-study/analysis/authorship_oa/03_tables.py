"""Single-authorship shares by field, subfield, topic, tier and period.

Share = articles with exactly one author / articles with at least one author.
share_ref5 applies the same ratio to articles with at least five references.

Outputs: out/authorship_oa/tables/*.csv and summary.json
"""
from __future__ import annotations

import json

import pandas as pd

from config import EARLY_WINDOW, MIN_ARTICLES, OUT, PROC, WINDOW, YEARS

TAB = OUT / "tables"
WIN = f"{WINDOW[0]}-{WINDOW[1]}"
EARLY = f"{EARLY_WINDOW[0]}-{EARLY_WINDOW[1]}"

# Theoretical physics has no OpenAlex subfield of its own. It is defined here as these OpenAlex
# topics (theoretical high-energy physics, gravitation and cosmology theory). Topics whose
# names mix theory and experiment ("Particle physics theoretical and experimental studies") are
# left out. Mathematical Physics is reported as a subfield in subfields.csv.
THEORY_TOPICS = {
    "T10025": "Black Holes and Theoretical Physics",
    "T10095": "Cosmology and Gravitation Theories",
    "T11960": "Relativity and Gravitational Theory",
    "T11415": "Noncommutative and Quantum Gravity Theories",
    "T10224": "Quantum Chromodynamics and Particle Interactions",
    "T10591": "Theoretical and Computational Physics",
}


def wide(c: pd.DataFrame, keys: list[str]) -> pd.DataFrame:
    w = c.pivot_table(index=keys, columns="variant", values="n", aggfunc="sum", fill_value=0).reset_index()
    w.columns.name = None
    return w


def shares(w: pd.DataFrame) -> pd.DataFrame:
    w = w.copy()
    w["share"] = w.one / w.pos
    if "pos_ref5" in w:
        w["share_ref5"] = w.one_ref5 / w.pos_ref5
    return w


def by_period(c: pd.DataFrame, keys: list[str], years: tuple[int, int]) -> pd.DataFrame:
    y = c.period.astype(int)
    sub = c[y.between(*years)]
    return shares(wide(sub, keys))


def main():
    tx = pd.read_parquet(PROC / "taxonomy.parquet")
    tp_tx = pd.read_parquet(PROC / "topics.parquet")
    sf = pd.read_parquet(PROC / "counts_subfield.parquet").rename(columns={"id": "subfield_id"})
    sf = sf.merge(tx[["subfield_id", "field", "domain"]], on="subfield_id", how="left")
    sf["subfield"] = sf.subfield_id.map(tx.set_index("subfield_id").subfield)

    # benchmark: every tier, both windows
    bench = []
    for lab, yrs in (("window", WINDOW), ("early", EARLY_WINDOW)):
        b = by_period(sf, ["tier"], yrs)
        b["period"] = f"{yrs[0]}-{yrs[1]}"
        bench.append(b)
    bench = pd.concat(bench)[["tier", "period", "pos", "one", "share", "pos_ref5", "one_ref5", "share_ref5"]]

    def level(keys):
        w = by_period(sf, ["tier"] + keys, WINDOW)
        e = by_period(sf, ["tier"] + keys, EARLY_WINDOW)[["tier"] + keys + ["pos", "share"]]
        e = e.rename(columns={"pos": "pos_early", "share": "share_early"})
        w = w.merge(e, on=["tier"] + keys, how="left")
        w["change_pp"] = 100 * (w.share - w.share_early)
        return w.sort_values(["tier", "share"], ascending=[True, False])

    fields = level(["domain", "field"])
    subfields = level(["domain", "field", "subfield"])

    trend = shares(wide(sf, ["tier", "domain", "field", "period"]))
    trend["year"] = trend.period.astype(int)
    trend = trend.drop(columns="period").sort_values(["tier", "field", "year"])

    # topics
    tc = pd.read_parquet(PROC / "counts_topic.parquet").rename(columns={"id": "topic_id"})
    tw = shares(wide(tc[tc.period == WIN], ["tier", "topic_id"]))
    te = shares(wide(tc[tc.period == EARLY], ["tier", "topic_id"]))[["tier", "topic_id", "pos", "share"]]
    te = te.rename(columns={"pos": "pos_early", "share": "share_early"})
    topics = (tw.merge(te, on=["tier", "topic_id"], how="left")
                .merge(tp_tx, on="topic_id", how="left")
                .sort_values(["tier", "share"], ascending=[True, False]))
    topics["change_pp"] = 100 * (topics.share - topics.share_early)

    theory = tp_tx[tp_tx.topic_id.isin(THEORY_TOPICS)]
    missing = set(THEORY_TOPICS) - set(theory.topic_id)
    if missing:
        raise SystemExit(f"theory topics not in the OpenAlex topic list: {missing}")
    theory.to_csv(TAB / "theory_physics_topics.csv", index=False)
    th = topics[topics.topic_id.isin(theory.topic_id)]
    th_pool = th.groupby("tier")[["pos", "one", "pos_ref5", "one_ref5", "pos_early"]].sum()
    th_pool["share"] = th_pool.one / th_pool.pos
    th_pool["share_ref5"] = th_pool.one_ref5 / th_pool.pos_ref5
    e = th.assign(one_early=th.share_early * th.pos_early).groupby("tier")[["one_early", "pos_early"]].sum()
    th_pool["share_early"] = e.one_early / e.pos_early
    th_pool = th_pool.reset_index()

    out = {"benchmark": bench, "fields": fields, "subfields": subfields, "trend_field": trend,
           "topics": topics, "theory_physics": th, "theory_physics_pooled": th_pool}
    for k, v in out.items():
        v.to_csv(TAB / f"{k}.csv", index=False)

    big = subfields[subfields.pos >= MIN_ARTICLES]
    summary = {t: {"subfields_reported": int((big.tier == t).sum()),
                   "subfields_majority_single": int(((big.tier == t) & (big.share > 0.5)).sum()),
                   "subfields_majority_single_ref5": int(((big.tier == t) & (big.share_ref5 > 0.5)).sum())}
               for t in big.tier.unique()}
    summary["window"] = WIN
    summary["early_window"] = EARLY
    summary["years"] = [YEARS[0], YEARS[-1]]
    (TAB / "summary.json").write_text(json.dumps(summary, indent=1))

    pd.set_option("display.width", 200)
    print(bench.round(3).to_string(index=False))
    for t in ("all", "q1"):
        print(f"\n--- top subfields, tier {t}, {WIN} (min {MIN_ARTICLES:,} articles)")
        print(big[big.tier == t].head(20)[["field", "subfield", "pos", "share", "share_ref5", "share_early"]]
              .round(3).to_string(index=False))
    print("\n--- theoretical physics (pooled topics)")
    print(th_pool.round(3).to_string(index=False))
    print(json.dumps(summary, indent=1))


if __name__ == "__main__":
    main()
