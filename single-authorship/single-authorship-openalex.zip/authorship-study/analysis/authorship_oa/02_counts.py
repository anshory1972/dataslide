"""Article counts by author number, from OpenAlex group_by queries only.

subfield level  every year 2000-2025, every tier and variant
topic level     the headline window and the early window (pos and one only), every tier

Output: data/authorship_oa/processed/counts_subfield.parquet, counts_topic.parquet
Every query is cached under data/authorship_oa/raw/counts, so a stopped run resumes.
"""
from __future__ import annotations

import json
import sys

import pandas as pd

import oa
from config import BASE, EARLY_WINDOW, PROC, RAW, TIERS, VARIANTS, WINDOW, YEARS


def tier_filter(tier: str) -> str:
    if tier == "all":
        return BASE
    if tier == "core":
        return BASE + ",primary_location.source.is_core:true"
    col = json.loads((PROC / "collections.json").read_text())["q1"]
    return BASE + f",primary_location.source.id:{col}"


def run(level: str, group: str, periods: dict, variants: dict) -> pd.DataFrame:
    rows = []
    for tier in TIERS:
        for plabel, (y0, y1) in periods.items():
            for v, extra in variants.items():
                f = f"{tier_filter(tier)},publication_year:{y0}-{y1},{extra}"
                cache = RAW / "counts" / level / f"{tier}_{plabel}_{v}.json"
                fresh = not cache.exists()
                g = oa.group_by_all(f, group, cache)
                rows += [(tier, plabel, v, oa.short(x["key"]), x["name"], x["count"]) for x in g]
                if fresh:
                    print(f"{level:8s} {tier:7s} {plabel:9s} {v:8s} {len(g):5,} groups "
                          f"{sum(x['count'] for x in g):10,} articles  credits {oa.CREDITS}", flush=True)
    return pd.DataFrame(rows, columns=["tier", "period", "variant", "id", "name", "n"])


def main():
    try:
        years = {str(y): (y, y) for y in YEARS}
        sf = run("subfield", "primary_topic.subfield.id", years, VARIANTS)
        sf.to_parquet(PROC / "counts_subfield.parquet", index=False)
        windows = {f"{WINDOW[0]}-{WINDOW[1]}": WINDOW}
        tp = run("topic", "primary_topic.id", windows, VARIANTS)
        early = {f"{EARLY_WINDOW[0]}-{EARLY_WINDOW[1]}": EARLY_WINDOW}
        tp = pd.concat([tp, run("topic", "primary_topic.id", early,
                                {k: VARIANTS[k] for k in ("pos", "one")})])
        tp.to_parquet(PROC / "counts_topic.parquet", index=False)
    except oa.BudgetExhausted as e:
        print("stopped on the OpenAlex daily budget; rerun after midnight UTC to continue.\n", e)
        sys.exit(2)
    print("credits:", oa.CREDITS)


if __name__ == "__main__":
    main()
