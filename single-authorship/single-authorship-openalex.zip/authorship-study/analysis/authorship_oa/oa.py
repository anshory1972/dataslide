"""Small OpenAlex client: API key, retries, credit log, JSON cache."""
from __future__ import annotations

import json
import time
from pathlib import Path

import requests

from config import MAILTO, OPENALEX, OPENALEX_KEY

S = requests.Session()
S.headers["User-Agent"] = f"single-authorship-study (mailto:{MAILTO})" if MAILTO else "single-authorship-study"
if OPENALEX_KEY:
    S.headers["Authorization"] = f"Bearer {OPENALEX_KEY}"

CREDITS = {"used": 0, "remaining": None}


class BudgetExhausted(RuntimeError):
    pass


def _req(method: str, path: str, **kw) -> dict:
    url = path if path.startswith("http") else OPENALEX + path
    for attempt in range(6):
        r = S.request(method, url, timeout=120, **kw)
        used = r.headers.get("X-RateLimit-Credits-Used")
        if used:
            CREDITS["used"] += int(float(used))
        rem = r.headers.get("X-RateLimit-Remaining")
        if rem:
            CREDITS["remaining"] = rem
        if r.status_code == 429:
            body = r.json() if r.headers.get("content-type", "").startswith("application/json") else {}
            if "budget" in str(body).lower():
                raise BudgetExhausted(body.get("message", r.text[:300]))
            time.sleep(2 ** attempt)
            continue
        if r.status_code >= 500:
            time.sleep(2 ** attempt)
            continue
        if r.status_code >= 400:
            raise RuntimeError(f"{r.status_code} {url}\n{r.text[:800]}")
        return r.json() if r.content else {}
    raise RuntimeError(f"gave up after retries: {url}")


def get(path: str, params: dict | None = None) -> dict:
    return _req("GET", path, params=params)


def post(path: str, payload: dict) -> dict:
    return _req("POST", path, json=payload)


def write_json(path: Path, obj) -> None:
    """Write through a temporary file so an interrupted run never leaves a broken cache."""
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(".tmp")
    tmp.write_text(json.dumps(obj))
    tmp.replace(path)


def group_by_all(filter_: str, group: str, cache: Path) -> list[dict]:
    """Every group of a works group_by, following the cursor (1 credit per 200 groups)."""
    if cache.exists():
        return json.loads(cache.read_text())
    groups, cursor = [], "*"
    while cursor:
        d = get("/works", {"filter": filter_, "group_by": group, "per_page": 200, "cursor": cursor})
        groups += [{"key": g["key"], "name": g.get("key_display_name"), "count": g["count"]}
                   for g in d.get("group_by", [])]
        cursor = d.get("meta", {}).get("next_cursor") if d.get("group_by") else None
    write_json(cache, groups)
    return groups


def list_all(path: str, params: dict, cache_dir: Path) -> list[dict]:
    """Every result of a list endpoint, one cached file per page of 200."""
    out, cursor, page = [], "*", 0
    while cursor:
        cache = cache_dir / f"page_{page:05d}.json"
        if cache.exists():
            d = json.loads(cache.read_text())
        else:
            d = get(path, {**params, "per_page": 200, "cursor": cursor})
            write_json(cache, d)
        out += d.get("results", [])
        cursor = d.get("meta", {}).get("next_cursor") if d.get("results") else None
        page += 1
    return out


def short(oa_id: str) -> str:
    return str(oa_id).rsplit("/", 1)[-1]
