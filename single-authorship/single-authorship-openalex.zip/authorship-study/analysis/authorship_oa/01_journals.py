"""Journals, their main subfield, and the top-quarter (q1) tier; plus the topic taxonomy.

Outputs (data/authorship_oa/processed):
  journals.parquet     one row per OpenAlex journal with 50+ works: core flag, main subfield,
                       citedness, rank, q1 flag
  taxonomy.parquet     subfield -> field -> domain
  topics.parquet       topic -> subfield -> field -> domain
  collections.json     {"q1": col_...}  (OpenAlex collection of the q1 journals)
  snapshot.json        download date, OpenAlex counts, thresholds used
"""
from __future__ import annotations

import datetime as dt
import json

import pandas as pd

import oa
from config import MIN_GROUP, MIN_RECENT_WORKS, PROC, Q1_SHARE, RAW


def taxonomy() -> pd.DataFrame:
    rows = []
    for s in oa.list_all("/subfields", {"select": "id,display_name,field,domain"}, RAW / "subfields"):
        rows.append({"subfield_id": oa.short(s["id"]), "subfield": s["display_name"],
                     "field_id": oa.short(s["field"]["id"]), "field": s["field"]["display_name"],
                     "domain": s["domain"]["display_name"]})
    return pd.DataFrame(rows)


def topics() -> pd.DataFrame:
    rows = []
    for t in oa.list_all("/topics", {"select": "id,display_name,subfield,field,domain"}, RAW / "topics"):
        rows.append({"topic_id": oa.short(t["id"]), "topic": t["display_name"],
                     "subfield_id": oa.short(t["subfield"]["id"]), "subfield": t["subfield"]["display_name"],
                     "field": t["field"]["display_name"], "domain": t["domain"]["display_name"]})
    return pd.DataFrame(rows)


def journals(snapshot_year: int) -> pd.DataFrame:
    src = oa.list_all("/sources", {"filter": "type:journal,works_count:>49",
                                   "select": "id,display_name,issn_l,is_core,works_count,summary_stats,"
                                             "counts_by_year,topics"}, RAW / "sources_journals")
    recent = (snapshot_year - 2, snapshot_year - 1)
    rows = []
    for s in src:
        top = (s.get("topics") or [None])[0]
        cby = {c["year"]: c["works_count"] for c in s.get("counts_by_year") or []}
        rows.append({
            "source_id": oa.short(s["id"]), "title": s["display_name"], "issn_l": s.get("issn_l"),
            "is_core": bool(s.get("is_core")),
            "works_count": s.get("works_count"),
            "citedness_2yr": (s.get("summary_stats") or {}).get("2yr_mean_citedness"),
            "recent_works": sum(cby.get(y, 0) for y in recent),
            "field_id": oa.short(top["field"]["id"]) if top else None,
            "field": top["field"]["display_name"] if top else None,
            "subfield_id": oa.short(top["subfield"]["id"]) if top else None,
            "subfield": top["subfield"]["display_name"] if top else None,
        })
    j = pd.DataFrame(rows)
    rankable = j.citedness_2yr.notna() & (j.recent_works >= MIN_RECENT_WORKS) & j.field_id.notna()
    j["rankable"] = rankable
    # Rank within the journal's main subfield, as SJR ranks within a category. Citation levels
    # differ a lot inside a field (History vs History and Philosophy of Science), so a
    # field-wide ranking would push whole subfields out of the top quarter. Subfields with
    # fewer than MIN_GROUP rankable journals are ranked within their field instead.
    n_sub = j[rankable].groupby("subfield_id").source_id.transform("size")
    j["rank_group"] = None
    j.loc[rankable, "rank_group"] = j.loc[rankable, "subfield_id"].where(n_sub >= MIN_GROUP,
                                                                         "field:" + j.loc[rankable, "field_id"])
    j["pct_rank"] = j[rankable].groupby("rank_group").citedness_2yr.rank(pct=True, method="average")
    j["q1"] = j.pct_rank > 1 - Q1_SHARE
    return j


def collection(ids: list[str]) -> str:
    path = PROC / "collections.json"
    cols = json.loads(path.read_text()) if path.exists() else {}
    if "q1" in cols:
        return cols["q1"]
    c = oa.post("/collections", {
        "display_name": f"Journals, top quarter of main subfield by 2-year citedness "
                        f"({dt.date.today().isoformat()})",
        "entity_type": "sources",
        "description": "Single-authorship study (OpenAlex only): OpenAlex journals in the top "
                       "quarter of their main subfield (field if the subfield has fewer than ten "
                       "ranked journals) by 2yr_mean_citedness.",
        "member_ids": ids[:10000]})
    cid = oa.short(c["id"])
    for i in range(10000, len(ids), 10000):
        oa.post(f"/collections/{cid}/members", {"member_ids": ids[i:i + 10000]})
    cols["q1"] = cid
    path.write_text(json.dumps(cols, indent=1))
    return cid


def main():
    # Keep the original download date while the raw cache is in use, so the citedness years
    # match the cached journal data. A run without the cache starts a new snapshot.
    cached = (RAW / "sources_journals").exists()
    snap = json.loads((PROC / "snapshot.json").read_text()) if (PROC / "snapshot.json").exists() and cached else {}
    date = snap.get("downloaded", dt.date.today().isoformat())
    year = int(date[:4])

    tx = taxonomy()
    tx.to_parquet(PROC / "taxonomy.parquet", index=False)
    topics().to_parquet(PROC / "topics.parquet", index=False)

    j = journals(year)
    j.to_parquet(PROC / "journals.parquet", index=False)
    q1 = sorted(j[j.q1].source_id)
    cid = collection(q1)

    snap.update({"downloaded": date, "journals_50plus_works": int(len(j)),
                 "core_journals": int(j.is_core.sum()), "rankable": int(j.rankable.sum()),
                 "q1_journals": len(q1), "q1_core_journals": int((j.q1 & j.is_core).sum()),
                 "q1_collection": cid,
                 "citedness_years": [year - 2, year - 1], "min_recent_works": MIN_RECENT_WORKS,
                 "q1_share": Q1_SHARE})
    (PROC / "snapshot.json").write_text(json.dumps(snap, indent=1))
    print(json.dumps(snap, indent=1))
    print(j[j.rankable].groupby("field").agg(journals=("source_id", "size"), q1=("q1", "sum"),
                                             core=("is_core", "sum")).to_string())
    print("credits:", oa.CREDITS)


if __name__ == "__main__":
    main()
