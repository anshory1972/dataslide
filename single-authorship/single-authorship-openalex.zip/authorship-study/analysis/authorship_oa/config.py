"""Configuration for the OpenAlex-only single-authorship analysis."""
from __future__ import annotations

import os
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
DATA = ROOT / "data" / "authorship_oa"
RAW = DATA / "raw"          # cached API responses; delete to re-pull
PROC = DATA / "processed"
OUT = ROOT / "out" / "authorship_oa"
for p in (RAW, PROC, OUT / "tables"):
    p.mkdir(parents=True, exist_ok=True)

OPENALEX = "https://api.openalex.org"

# ---------------------------------------------------------------- periods
YEARS = list(range(2000, 2026))        # per-year counts at subfield level
WINDOW = (2021, 2025)                  # headline window
EARLY_WINDOW = (2001, 2005)            # comparison window

# ---------------------------------------------------------------- journal tiers
# all     : articles whose primary location is a journal
# q1      : the journal is in the top quarter of journals in its main OpenAlex subfield (the
#           subfield of its largest topic), ranked by 2-year mean citedness (OpenAlex
#           summary_stats, snapshot at download); subfields with fewer than MIN_GROUP ranked
#           journals are ranked within their field
# core    : robustness tier; the journal is flagged is_core in OpenAlex (CWTS Leiden "core"
#           international scientific journals). It leaves out most humanities journals
#           (History keeps about 9% of its articles), so it is not the main quality tier.
TIERS = ("all", "q1", "core")
Q1_SHARE = 0.25
MIN_GROUP = 10
# a journal enters the ranking only with this many works in the two years the citedness is
# computed on (the two years before the snapshot year), so tiny journals do not rank on noise
MIN_RECENT_WORKS = 20

# ---------------------------------------------------------------- article filters
BASE = "type:article,primary_location.source.type:journal"
VARIANTS = {
    "pos": "authors_count:>0",                                     # at least one author
    "one": "authors_count:1",                                      # exactly one author
    "pos_ref5": "authors_count:>0,referenced_works_count:>4",      # screens book reviews,
    "one_ref5": "authors_count:1,referenced_works_count:>4",       # editorials, short notes
}
MIN_ARTICLES = 1000          # a subfield or topic is reported only with this many articles


def _load_env() -> None:
    env = ROOT / ".env"
    if env.exists():
        for line in env.read_text().splitlines():
            line = line.strip()
            if line and not line.startswith("#") and "=" in line:
                k, v = line.split("=", 1)
                os.environ.setdefault(k.strip(), v.strip())


_load_env()
OPENALEX_KEY = os.environ.get("OPENALEX_API_KEY", "")
# optional contact address sent in the User-Agent, as OpenAlex asks (OPENALEX_MAILTO in .env)
MAILTO = os.environ.get("OPENALEX_MAILTO", "")
