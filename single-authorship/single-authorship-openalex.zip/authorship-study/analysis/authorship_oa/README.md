# Single authorship across fields — OpenAlex only

Question: in which fields is single authorship common, or the norm, once low-quality journals
are excluded? This version uses only the OpenAlex API, so anyone can rerun it with a free key.

## Design

- **Articles.** OpenAlex works of type `article` whose primary location is a journal.
- **Field.** Each article's own primary topic in the OpenAlex classification: 4 domains,
  26 fields, 252 subfields, about 4,500 topics. Journals are not classified; articles are.
- **Share.** Articles with exactly one author divided by articles with at least one author
  (`authors_count`).
- **Quality tiers.**
  - `all`: every journal article.
  - `q1` (main quality tier): the journal is in the top quarter of its main OpenAlex subfield
    by 2-year mean citedness (`summary_stats.2yr_mean_citedness`), as SJR ranks within a
    category. A journal's main subfield is the subfield of its largest topic. Subfields with
    fewer than ten ranked journals are ranked within their field. Only journals with 50 or more
    works in total and 20 or more works in the two citedness years are ranked.
  - `core` (robustness tier): the journal is flagged `is_core` in OpenAlex (CWTS Leiden "core"
    international scientific journals, about 33,000). This flag leaves out most humanities
    journals (History keeps about 9% of its articles, Classics about 2%), so it is not used as
    the main quality tier.
- **Periods.** Per year 2000–2025 at subfield level; topics for 2021–2025 and 2001–2005.
- **Book-review screen.** Every share is also computed for articles with at least five
  references (`share_ref5`), which removes most book reviews, editorials and short notes that
  OpenAlex types as articles.
- **Theoretical physics.** No subfield of its own. It is defined as six named OpenAlex topics
  (black holes, cosmology and gravitation, relativity, quantum gravity, QCD, theoretical and
  computational physics), listed in `THEORY_TOPICS` in `03_tables.py`.

## Limits

- The `q1` tier uses the citedness at the download date and applies it to all years.
  A journal that was weak in 2005 and strong now is counted as strong in 2005.
- OpenAlex topics are assigned by a classifier; a few articles land in odd topics.
- OpenAlex data change over time. The raw API responses are cached under
  `data/authorship_oa/raw/`, and `snapshot.json` records the download date. Keep the cache to
  reproduce the exact numbers; delete it to update them.

## Run

```bash
pip install pandas pyarrow requests
# .env in the repo root:  OPENALEX_API_KEY=...   (free at openalex.org)
cd analysis/authorship_oa
python 01_journals.py    # journals, subfield ranking, q1 collection          (~600 credits)
python 02_counts.py      # group_by counts by subfield and topic              (~1,300 credits)
python 03_tables.py      # tables -> out/authorship_oa/tables
```

A free key has 10,000 credits a day (one credit per list or group_by page). The run needs
about 2,000. Without a key OpenAlex allows 1,000 a day and does not allow collections, so the
`q1` tier needs a key. Every query is cached, so a stopped run resumes where it left off.
